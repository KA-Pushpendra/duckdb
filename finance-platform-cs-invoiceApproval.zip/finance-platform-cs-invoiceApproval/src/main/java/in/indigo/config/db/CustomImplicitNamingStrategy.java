package in.indigo.config.db;


import jakarta.enterprise.context.ApplicationScoped;
import org.eclipse.microprofile.config.ConfigProvider;
import org.hibernate.boot.model.naming.Identifier;
import org.hibernate.boot.model.naming.PhysicalNamingStrategyStandardImpl;
import org.hibernate.engine.jdbc.env.spi.JdbcEnvironment;

import in.indigo.utility.TransactionTables;


@ApplicationScoped
public class CustomImplicitNamingStrategy extends PhysicalNamingStrategyStandardImpl {

    private final String tableNameSuffix;

    public CustomImplicitNamingStrategy() {
        this.tableNameSuffix = ConfigProvider.getConfig()
                .getOptionalValue("TABLE_NAME_SUFFIX", String.class)
                .orElse("");
    }

    @Override
    public Identifier toPhysicalTableName(Identifier name, JdbcEnvironment context) {
        String suffix = tableNameSuffix.isEmpty() ? "" : "_" + tableNameSuffix.toUpperCase();
        if (TransactionTables.TABLE_NAMES.stream().anyMatch(t -> t.equals(name.getText().toUpperCase()))) {
            return new Identifier(name.getText() + suffix, name.isQuoted());
        }
        return name;
    }

}