package in.indigo.repository;

import in.indigo.entity.FileStatus;
import io.quarkus.hibernate.orm.panache.PanacheRepository;
import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class FileStatusRepository implements PanacheRepository<FileStatus> {
}