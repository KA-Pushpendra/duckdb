package in.indigo.repository;

import in.indigo.entity.AuditInvoiceDWH;
import io.quarkus.hibernate.orm.panache.PanacheRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.transaction.Transactional;

import java.util.List;

@ApplicationScoped
public class AuditInvoiceDwhRepository implements PanacheRepository<AuditInvoiceDWH> {

    @Transactional
    public void insertData(List<AuditInvoiceDWH> list) {
        persist(list);
    }

}
