package in.indigo.repository;

import in.indigo.entity.ErrorPNRRecord;
import io.quarkus.hibernate.orm.panache.PanacheRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;

@ApplicationScoped
@Slf4j
public class ErrorPNRRecordRepository implements PanacheRepository<ErrorPNRRecord> {
    @Transactional
    public void deleteErrorPnr(String id) {
        try {

           log.info("deleting record errorpnr with id-> {}",id);
            delete("from ErrorPNRRecord where id = ?1", id); // Assuming 'delete' returns the count of deleted rows
    
            log.info("deleted record errorpnr with id-> {}",id);
           
        } catch (Exception e) {
            log.error("Failed to delete ErrorPNRRecord with id: " + id, e);
            throw new RuntimeException("Failed to delete ErrorPNRRecord with id: " + id, e);
        }
    }
    
}
