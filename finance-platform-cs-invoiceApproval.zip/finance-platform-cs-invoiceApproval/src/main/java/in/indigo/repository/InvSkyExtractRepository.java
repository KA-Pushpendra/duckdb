package in.indigo.repository;

import in.indigo.entity.InvSkyExtract;
import io.quarkus.hibernate.orm.panache.PanacheRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.stream.Collectors;


@Slf4j
@ApplicationScoped
public class InvSkyExtractRepository implements PanacheRepository<InvSkyExtract> {

    @Transactional
    public List<InvSkyExtract> getDataByIdes(List<String> ids, String date) {
        // List<String> excludedCode = Arrays.asList(exchange.getIn().getHeader("excludedCode", String[].class));
        // List<String> ids = Arrays.asList(exchange.getIn().getHeader("excludedCode", String[].class));

        List<InvSkyExtract> datas = list("from InvSkyExtract where  id in (?1) and transactionDate = ?2", ids,date);
       
        // List<List<InvSkyExtract>> dataList = datas.stream()
        //         .collect(Collectors.groupingBy(InvSkyExtract::getTransactionDate)).values().stream()
        //         .collect(Collectors.toList());

        return datas;

    }
}
