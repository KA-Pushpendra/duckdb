package in.indigo.repository;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;

import in.indigo.entity.InvoiceDWH;

import java.sql.Connection;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.stream.Collectors;


import org.eclipse.microprofile.config.inject.ConfigProperty;

@Slf4j
@ApplicationScoped
public class InvoiceDwhRepository {

    @ConfigProperty(name = "MSQL_JDBC_URL")
    private String jdbcmssqlurl;

    private final String sql = "UPDATE Invoice_DWH_CS "
            + "SET  PlaceOfEmbarkation = ?, StateCode = ?, CustomerGSTIN = ?, "
            + "CustomerName = ?, EmailAddress = ?, CustomerGSTRegistrationState = ?, [6EGSTIN] = ?, [6ERegisteredAddress] = ?, NonTaxableFareComponent = ?, "
            + "TaxableComponent = ?, CGSTAmount = ?, IGSTAmount = ?, SGSTAmount = ?, UGSTAmount = ?, "
            + "CGSTRate = ?, IGSTRate = ?, SGSTUGSTRate = ?, IsProcessed = ?, "
            + "AirportCharges = ?, IsExempted = ?, IsCorrect = ?, "
            + "CreatedBy = ?, CreatedOn = GETDATE(), [Cess Amount] = ?, [Local Cess Amount] = ?, "
            + "spExemptedFlight = ?, spInternational = ?, spSez = ? "
            + "WHERE Id = ? AND TransactionDate = ? AND IsCorrect = 0 AND IsError=1 ";

    @Transactional
    public void bulkUpdate(List<InvoiceDWH> invoices) {

        try (Connection conn = DriverManager.getConnection(jdbcmssqlurl);
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            conn.setAutoCommit(false); // Start transaction

            for (InvoiceDWH invoice : invoices) {
                Calendar cal = Calendar.getInstance();
                cal.setTime(invoice.getTransactionDate());
                cal.set(Calendar.MILLISECOND, 0);

                stmt.setString(1, invoice.getPlaceOfEmbarkation());
                stmt.setString(2, invoice.getStateCode());
                stmt.setString(3, invoice.getCustomerGSTIN());
                stmt.setString(4, invoice.getCustomerName());
                stmt.setString(5, invoice.getEmailAddress());
                stmt.setString(6, invoice.getCustomerGSTRegistrationState());
                stmt.setString(7, invoice.getE6gstin());
                stmt.setString(8, invoice.getE6RegisteredAddress());
                stmt.setDouble(9, invoice.getNonTaxableFareComponent());
                stmt.setDouble(10, invoice.getTaxableComponent());
                stmt.setDouble(11, invoice.getCgstAmount());
                stmt.setDouble(12, invoice.getIgstAmount());
                stmt.setDouble(13, invoice.getSgstAmount());
                stmt.setDouble(14, invoice.getUgstAmount());
                stmt.setDouble(15, invoice.getCgstRate());
                stmt.setDouble(16, invoice.getIgstRate());
                stmt.setDouble(17, invoice.getSgstugstRate());
                stmt.setString(18, invoice.getIsProcessed());
                stmt.setDouble(19, invoice.getAirportCharges());
                stmt.setBoolean(20, invoice.isExempted());
                stmt.setInt(21, invoice.getIsCorrect());
                stmt.setString(22, invoice.getCreatedBy());
                stmt.setDouble(23, invoice.getCessAmount());
                stmt.setDouble(24, invoice.getLocalCessAmount());
                stmt.setInt(25, invoice.getSpExemptedFlight());
                stmt.setInt(26, invoice.getSpInternational());
                stmt.setInt(27, invoice.getSpSez());
                stmt.setString(28, invoice.getId()); // Use primary key for updates

                stmt.setTimestamp(29, new java.sql.Timestamp(cal.getTimeInMillis()));
                stmt.addBatch();
            }

            int[] response = stmt.executeBatch(); // Executes all updates in one batch

            List<Integer> changeToList = Arrays.stream(response) 
                    .boxed()
                    .collect(Collectors.toList());

            int countZero = Collections.frequency(changeToList, 0);
            int countOne = Collections.frequency(changeToList, 1);

            log.info("total Records updated: "+countOne + " Record not updated: "+ countZero);
            conn.commit(); // Commit transaction
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Bulk update failed", e);
        }
    }
}