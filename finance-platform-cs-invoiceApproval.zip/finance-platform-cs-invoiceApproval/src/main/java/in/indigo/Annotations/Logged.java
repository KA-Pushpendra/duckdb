// package in.indigo.Annotations;


// import jakarta.interceptor.InterceptorBinding;

// import java.lang.annotation.*;

// @InterceptorBinding
// @Retention(RetentionPolicy.RUNTIME)
// @Target({ElementType.TYPE,ElementType.CONSTRUCTOR,ElementType.METHOD})
// @Inherited
// public @interface Logged {
// }
