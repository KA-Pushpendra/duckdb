package in.indigo.exceptions;

public class InvalidDataTypeException extends RuntimeException{

    public InvalidDataTypeException(String message) {
        super(message);
    }

    public InvalidDataTypeException(String message, Throwable cause) {
        super(message, cause);
    }

}
