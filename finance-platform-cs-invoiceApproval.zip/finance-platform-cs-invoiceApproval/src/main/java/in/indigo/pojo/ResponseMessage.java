package in.indigo.pojo;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import java.io.Serializable;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
public class ResponseMessage  implements Serializable {
    private Boolean status;
    private String message;
    private Object data;
}

