package in.indigo.Aggregator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.camel.AggregationStrategy;
import org.apache.camel.Exchange;

import in.indigo.entity.AuditInvoiceDWH;
import in.indigo.repository.AuditInvoiceDwhRepository;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@ApplicationScoped
@Slf4j
@RequiredArgsConstructor
public class AuditDwhStrategy implements AggregationStrategy {
    private final AuditInvoiceDwhRepository auditInvoiceDwhRepository;

    private static int totalRecordCompleted = 0;

    @Override
    public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {
        if (oldExchange == null) {
            totalRecordCompleted=0;
            List<AuditInvoiceDWH> list = new ArrayList<>();
            newExchange.getIn().setBody(list);
            return newExchange;
        } else {
            AuditInvoiceDWH auditInvoiceDWH = newExchange.getIn().getBody(AuditInvoiceDWH.class);

            List<AuditInvoiceDWH> list = new ArrayList<>();
            list.addAll(Arrays.asList(oldExchange.getIn().getBody(AuditInvoiceDWH[].class)));
            list.add(auditInvoiceDWH);
            if (list.size() >= 100 || (boolean) newExchange.getProperty("CamelSplitComplete")) {
                totalRecordCompleted = totalRecordCompleted + list.size();
            
                auditInvoiceDwhRepository.insertData(list);
                log.info("Number of record processed to Audit Invoice DWH: " + totalRecordCompleted);
                list.clear();
            }
            newExchange.getIn().setBody(list);
            return newExchange;
        }
    }

}
