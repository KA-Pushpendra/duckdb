package in.indigo.Aggregator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.camel.AggregationStrategy;
import org.apache.camel.Exchange;

import in.indigo.entity.InvoiceDWH;
import in.indigo.repository.InvoiceDwhRepository;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@ApplicationScoped
@RequiredArgsConstructor
@Slf4j
public class DWHStrategy implements AggregationStrategy {
    private final InvoiceDwhRepository invoiceDwhRepository;

    private static int totalRecordCompleted = 0;

    @Override
    public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {
        if (oldExchange == null) {
            totalRecordCompleted=0;
            List<InvoiceDWH> list = new ArrayList<>();
            newExchange.getIn().setBody(list);
            return newExchange;
        } else {
            InvoiceDWH invoiceDWH = newExchange.getIn().getBody(InvoiceDWH.class);
            invoiceDWH.setIsCorrect(1);
            List<InvoiceDWH> list = new ArrayList<>();
            list.addAll(Arrays.asList(oldExchange.getIn().getBody(InvoiceDWH[].class)));
            list.add(invoiceDWH);
            if (list.size() >= 100 || (boolean) newExchange.getProperty("CamelSplitComplete")) {
                totalRecordCompleted = totalRecordCompleted + list.size();
                log.info("record number inside: "+totalRecordCompleted);
                invoiceDwhRepository.bulkUpdate(list);
                log.info("Number of record processed to Invoice DWH: " + totalRecordCompleted);
                list.clear();
            }
            newExchange.getIn().setBody(list);
            return newExchange;
        }
    }

}
