package in.indigo.service;

import in.indigo.entity.FileStatus;
import in.indigo.repository.FileStatusRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

import java.time.LocalDateTime;

@ApplicationScoped
@RequiredArgsConstructor
public class FileTrackingService {

    private final FileStatusRepository fileStatusRepository;

    @Transactional
    public void trackFile(String fileName, String status, String reason, String modifiedBy, String fileType, String requestId) {

        FileStatus existingRecord = fileStatusRepository.find("requestId", requestId).firstResult();

        if (existingRecord != null) {
            fileStatusRepository.update("status =?1, reason=?2, fileType=?3 where requestId = ?4",
                    status, reason, fileType, requestId);
        } else {
            FileStatus fileStatus = FileStatus.builder()
                    .requestId(requestId)
                    .fileName(fileName)
                    .status(status)
                    .reason(reason)
                    .modifiedBy(modifiedBy)
                    .modifiedAt(LocalDateTime.now())
                    .fileType(fileType)
                    .build();
            fileStatusRepository.persist(fileStatus);
        }
    }
}