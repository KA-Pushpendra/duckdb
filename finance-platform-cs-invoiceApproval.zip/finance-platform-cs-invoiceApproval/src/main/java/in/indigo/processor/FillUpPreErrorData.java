package in.indigo.processor;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.eclipse.microprofile.config.inject.ConfigProperty;

import in.indigo.entity.InvSkyExtract;
// import in.indigo.repository.ErrorPNRRecordRepository;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@ApplicationScoped
@Slf4j
@RequiredArgsConstructor
public class FillUpPreErrorData implements Processor {

    @ConfigProperty(name = "GET_DATA_BY_ID")
    private String GET_DATA_BY_ID;

    // private final ErrorPNRRecordRepository errorPNRRecordRepository;

    @ConfigProperty(name = "PRE_ERROR_INVSKYEXTRACT_FILE_PATH_FINAL_CSV")
    private String PRE_ERROR_INVSKYEXTRACT_FILE_PATH_FINAL_CSV;

    @Override
    public void process(Exchange exchange) throws Exception {

        List<InvSkyExtract> invoiceData = Arrays.asList(exchange.getIn().getBody(InvSkyExtract[].class));

        String query = GET_DATA_BY_ID.replace("0?",
                PRE_ERROR_INVSKYEXTRACT_FILE_PATH_FINAL_CSV + "/" + exchange.getProperty("blobName").toString());

        try (Connection conn = DriverManager.getConnection("jdbc:duckdb:");
                Statement stmt = conn.createStatement();) {
            System.out.println(query);

            for (InvSkyExtract invSkyExtract : invoiceData) {

                query = query.replace("1?", invSkyExtract.getId());
                ResultSet resultSet = stmt.executeQuery(query);
                if (resultSet.next()) {
                    log.info("[Reason ID]" + resultSet.getString("Reason ID"));

                    if (!("PREINV-5".equals(resultSet.getString("Reason ID"))
                            || "PREINV-6".equals(resultSet.getString("Reason ID")))) {
                        invSkyExtract.setSector(resultSet.getString("Sector"));

                        invSkyExtract.setOriginCountry(resultSet.getString("Origin Country"));
                        invSkyExtract.setItineraryOrigin(resultSet.getString("Full Itinerary Route"));

                    }

                }
            }

            stmt.close();
            conn.close();
            exchange.getIn().setBody(invoiceData);

        } catch (Exception e) {
            log.error(query, e);
        } finally {
            // deleteFilesOnly(new File(PRE_ERROR_INVSKYEXTRACT_FILE_PATH_FINAL_CSV));
        }
    }

    public static void deleteFilesOnly(File directory) {
        // Validate if the given path is a directory
        if (directory.exists() && directory.isDirectory()) {
            File[] files = directory.listFiles(); // List all files and subdirectories
            if (files != null) {
                for (File file : files) {
                    if (file.isFile()) {
                        file.delete();
                    } else if (file.isDirectory()) {
                        // Recursively delete files inside the subdirectory
                        deleteFilesOnly(file);
                    }
                }
            }
        } else {
            System.out.println("Invalid directory: " + directory.getAbsolutePath());
        }
    }

}