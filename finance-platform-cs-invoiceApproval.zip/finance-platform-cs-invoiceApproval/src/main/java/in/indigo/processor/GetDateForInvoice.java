package in.indigo.processor;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import in.indigo.repository.InvSkyExtractRepository;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class GetDateForInvoice implements Processor {

    private final InvSkyExtractRepository invSkyExtractRepository;

    @Override
    public void process(Exchange exchange) throws Exception {
        List<String> ids = Arrays.asList(exchange.getIn().getBody(String[].class));
        // String date = exchange.getProperty("transactionDate", String.class);

        // DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        // DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("MM/d/yyyy");

        // LocalDate date = LocalDate.parse(exchange.getProperty("transactionDate",
        // String.class), inputFormatter);
        // String formattedDate = date.format(outputFormatter);

        exchange.getIn().setBody(
                invSkyExtractRepository.getDataByIdes(ids, exchange.getProperty("transactionDate", String.class)));
    }

}
