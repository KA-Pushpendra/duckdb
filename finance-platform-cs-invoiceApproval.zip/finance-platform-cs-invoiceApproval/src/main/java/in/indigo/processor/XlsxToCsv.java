package in.indigo.processor;

import java.io.InputStream;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import com.monitorjbl.xlsx.StreamingReader;

import jakarta.enterprise.context.ApplicationScoped;
import lombok.extern.slf4j.Slf4j;

@ApplicationScoped
@Slf4j
public class XlsxToCsv implements Processor {

    


    @Override
    public void process(Exchange exchange) throws Exception {
        try (

                InputStream is = exchange.getIn().getBody(InputStream.class);

                Workbook workbook = StreamingReader.builder()
                        .rowCacheSize(100)
                        .bufferSize(4096)
                        .open(is)) {
            Sheet sheet = workbook.getSheetAt(0);

            StringBuilder pipeSeparatedBuilder = new StringBuilder();
            DataFormatter dataFormatter = new DataFormatter();
            for (Row row : sheet) {
                int lastCellNum = row.getLastCellNum();
                for (int cellNum = 0; cellNum < lastCellNum; cellNum++) {
                    Cell cell = row.getCell(cellNum,
                            Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);

                    String cellValue = dataFormatter.formatCellValue(cell);

                    if (cellValue.contains(",")) {
                        pipeSeparatedBuilder.append("\"")
                                .append(cellValue).append("\"")
                                .append(",");
                    } else {
                        pipeSeparatedBuilder.append(cellValue)
                                .append(",");
                    }

                }
                pipeSeparatedBuilder
                        .setLength(pipeSeparatedBuilder.length() - 1);
                pipeSeparatedBuilder.append("\n");
            }
            exchange.getIn().setBody(pipeSeparatedBuilder.toString());
        }

    }

}
