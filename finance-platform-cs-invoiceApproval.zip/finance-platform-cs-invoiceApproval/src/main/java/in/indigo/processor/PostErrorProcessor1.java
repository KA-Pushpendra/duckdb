package in.indigo.processor;


import in.indigo.entity.InvoiceDWH;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.ProducerTemplate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import java.util.stream.Collectors;

@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class PostErrorProcessor1 implements Processor {

    @Inject
    ProducerTemplate template;

    // ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());

    @Override
    public void process(Exchange exchange) throws Exception {

        log.info("Starting PostErrorProcessor process method");

        List<InvoiceDWH> list = Arrays.asList(exchange.getIn().getBody(InvoiceDWH[].class));

        List<InvoiceDWH> filteredList = list
                .stream()
                .filter(Objects::nonNull) 
                .filter(d -> d.getIsError() == 1 && d.getIsCorrect() == 1).collect(Collectors.toList());

        Map<Date, List<InvoiceDWH>> groupedInvoices = filteredList.stream()
                .collect(Collectors.groupingBy(InvoiceDWH::getTransactionDate));

        List<List<InvoiceDWH>> result = new ArrayList<>(groupedInvoices.values());

        exchange.getIn().setBody(result);

    }

    // private void processGroup(Exchange exchange, List<InvoiceDWH> group,
    // AtomicInteger invoicesLeftForCorrection,
    // int size) {
    // try {
    // Exchange kafkaExchange =
    // ExchangeBuilder.anExchange(exchange.getContext()).build();
    // kafkaExchange.getIn().setBody(group);
    // kafkaProcessor.process(kafkaExchange);
    // template.send("seda:kafka-process?blockWhenFull=true&waitForTaskToComplete=Never",
    // kafkaExchange);
    // invoiceService.batchUpdateInvoices(group);
    // int left = invoicesLeftForCorrection.addAndGet(-group.size());
    // log.info("Invoices left for correction: {} out of {}", left, size);
    // } catch (Exception e) {
    // log.error("Error Processing group: {}", group, e);
    // }
    // }
}
