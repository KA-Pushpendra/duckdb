package in.indigo.processor;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.eclipse.microprofile.config.inject.ConfigProperty;

import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class GetDistinctIds implements Processor {

    @ConfigProperty(name = "DISTINCT_ID_QUERY")
    private String DISTINCT_ID_QUERY;

    @ConfigProperty(name = "PRE_ERROR_INVSKYEXTRACT_FILE_PATH_FINAL_CSV")
    private String PRE_ERROR_INVSKYEXTRACT_FILE_PATH_FINAL_CSV;

    @Override
    public void process(Exchange exchange) throws Exception {

        List<String> pnrs = Arrays.asList(exchange.getIn().getBody(String[].class));

        String result = "(" + pnrs.stream()
                .map(pnr -> "'" + pnr + "'")
                .collect(Collectors.joining(",")) + ")";

        String query = DISTINCT_ID_QUERY.replace("0?",
                PRE_ERROR_INVSKYEXTRACT_FILE_PATH_FINAL_CSV + "/" + exchange.getProperty("blobName").toString());
        query = query.replace("1?", result);
        try (
                Connection conn = DriverManager.getConnection("jdbc:duckdb:");
                Statement stmt = conn.createStatement();) {
            System.out.println(query);
            ResultSet resultSet = stmt.executeQuery(query);

            // Store results in a Java String list
            List<String> idList = new ArrayList<>();
            while (resultSet.next()) {
                idList.add(resultSet.getString("id"));
            }

            exchange.getIn().setBody(idList);
            stmt.close();
            conn.close();

        } catch (Exception e) {
            log.error(query, e);
        }
    }

}
