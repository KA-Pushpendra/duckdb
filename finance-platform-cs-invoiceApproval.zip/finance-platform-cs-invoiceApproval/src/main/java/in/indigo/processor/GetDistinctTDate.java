package in.indigo.processor;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.eclipse.microprofile.config.inject.ConfigProperty;

import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class GetDistinctTDate implements Processor {

    @ConfigProperty(name = "DISTINCT_TD_QUERY")
    private String DISTINCT_TD_QUERY;

    @ConfigProperty(name = "PRE_ERROR_INVSKYEXTRACT_FILE_PATH_FINAL_CSV")
    private String PRE_ERROR_INVSKYEXTRACT_FILE_PATH_FINAL_CSV;

    @Override
    public void process(Exchange exchange) throws Exception {

        String query = DISTINCT_TD_QUERY.replace("0?",
                PRE_ERROR_INVSKYEXTRACT_FILE_PATH_FINAL_CSV + "/" + exchange.getProperty("blobName").toString());

        try (
                Connection conn = DriverManager.getConnection("jdbc:duckdb:");
                Statement stmt = conn.createStatement();) {
            System.out.println(query);

            ResultSet resultSet = stmt.executeQuery(query);

            // Store results in a Java String list
            List<String> tdList = new ArrayList<>();
            while (resultSet.next()) {
                tdList.add(resultSet.getString("Transaction Date"));
            }

            exchange.getIn().setBody(tdList);
            stmt.close();
            conn.close();

        } catch (Exception e) {
            log.error(query, e);
        }
    }

}
