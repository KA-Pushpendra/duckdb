package in.indigo.processor;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import in.indigo.entity.InvoiceDWH;
import in.indigo.pojo.Item;
import in.indigo.pojo.Mail;
import io.quarkus.logging.Log;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.extern.slf4j.Slf4j;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.eclipse.microprofile.config.inject.ConfigProperty;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@ApplicationScoped
@Slf4j
public class KafkaProcessor implements Processor {

    @ConfigProperty(name = "SEND_TO_KAFKA")
    private boolean sendToKafka;

    ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());

    @SuppressWarnings("unchecked")
    public void process(Exchange exchange) {
        try {
            // String date = exchange.getProperty("date", String.class);
            List<Map<String, Object>> bodyList = new ArrayList<>();
            if (!sendToKafka) {
                exchange.getIn().setBody(bodyList);
                return;
            }

            List<InvoiceDWH> list = exchange.getIn().getBody(List.class);

            list
                    .stream()
                    .filter(d -> d.getInvoiceNumber() != null && !d.getInvoiceNumber().isEmpty())
                    .collect(Collectors.groupingBy(InvoiceDWH::getIsCredit, LinkedHashMap::new, Collectors.toList()))
                    .entrySet()
                    .stream()
                    .filter(d -> d.getValue().stream().allMatch(d1 -> (d1.getIsError() == 0 || d1.getIsCorrect() == 1)))
                    .filter(d -> d.getValue().stream().allMatch(d1 -> d1.getSpInternational() == 0))
                    .peek(d -> d.setValue(d
                            .getValue()
                            .stream()
                            .sorted(Comparator.comparing(InvoiceDWH::getInvOrder))
                            .toList()))
                    .forEach(d -> {

                        Mail mail = generateJson(d.getValue());

                        if (mail != null) {

                            Map<String, Object> body = objectMapper.convertValue(mail, Map.class);

                            if (d.getKey() == (short) 1) {
                                body.put("invoicetype", "Tax Invoice");
                            } else {
                                body.put("invoicetype", "GST Credit Note");

                                Date displayDate = d.getValue().get(0).getDisplayDate();

                                SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");

                                body.put("originalinvoicenumber", d.getValue().get(0).getIsProcessed());
                                body.put("originalinvoicedate", formatter.format(displayDate));
                            }

                            bodyList.add(body);

                        }
                    });

            Log.info(objectMapper.writeValueAsString("----------->" + bodyList));

            exchange.getIn().setBody(bodyList);
            // Log.info("Message Received: " + response);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw new RuntimeException("Exception during execution", e);
        }

    }

    public Mail generateJson(List<InvoiceDWH> list) {
        if (list.isEmpty()) {
            return null;
        }

        ZonedDateTime indiaDateTime = ZonedDateTime.now(ZoneId.of("Asia/Kolkata"));
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
        String formattedDateTime = indiaDateTime.format(formatter);

        InvoiceDWH obj = list.get(0);

        Mail mail = Mail
                .builder()
                .flightNo("6E-" + (int) obj.getFlightNumber())
                .from(obj.getDep() == null ? "" : obj.getDep())
                .to(obj.getArr() == null ? "" : obj.getArr())
                .pnr(obj.getPnr() == null ? "" : obj.getPnr())
                .placeofsupply(obj.getPlaceOfEmbarkation() == null ? "" : obj.getPlaceOfEmbarkation())
                .customergstin(obj.getCustomerGSTIN() == null ? "" : obj.getCustomerGSTIN())
                .customername(obj.getCustomerName() == null ? "" : obj.getCustomerName())
                .customeremail(obj.getEmailAddress() == null ? "" : obj.getEmailAddress())
                .invoicenumber(obj.getInvoiceNumber() == null ? "" : obj.getInvoiceNumber())
                .invoicedate(formattedDateTime)
                .paxname(obj.getPassengerName() == null ? "" : obj.getPassengerName())
                .registeredaddress(obj.getE6RegisteredAddress() == null ? "" : obj.getE6RegisteredAddress())
                .registeredgstin(obj.getE6gstin() == null ? "" : obj.getE6gstin())
                .build();

        List<Item> items = new ArrayList<>();

        DecimalFormat df = new DecimalFormat("0.00");

        double gttaxablevalue = 0;
        double gtnontaxablevalue = 0;
        double gttotal = 0;
        double gtigst = 0;
        double gtcgst = 0;
        double gtsugst = 0;
        double gtcess = 0;

        for (InvoiceDWH d : list) {

            Item item = new Item();

            item.setItem(d.getGoodsServicesType() == null ? "" : d.getGoodsServicesType());
            item.setSaccode(String.valueOf((int) d.getSac()));

            item.setTaxablevalue(df.format(d.getTaxableComponent()).replace("-", ""));
            gttaxablevalue += d.getTaxableComponent();

            item.setNontaxablevalue(df.format(d.getNonTaxableFareComponent()).replace("-", ""));
            gtnontaxablevalue += d.getNonTaxableFareComponent();

            item.setTotal(df.format(d.getTaxableComponent() + d.getNonTaxableFareComponent()).replace("-", ""));

            gttotal += d.getTaxableComponent() + d.getNonTaxableFareComponent();

            item.setIgstperct(df.format(d.getIgstRate()).replace("-", ""));
            item.setIgstamnt(df.format(d.getIgstAmount()).replace("-", ""));
            gtigst += d.getIgstAmount();

            item.setCgstperct(df.format(d.getCgstRate()).replace("-", ""));
            item.setCgstamnt(df.format(d.getCgstAmount()).replace("-", ""));
            gtcgst += d.getCgstAmount();

            item.setSugstperct(df.format(d.getSgstugstRate()).replace("-", ""));

            double sugstamnt = 0;

            if (d.getSgstAmount() == 0 && d.getUgstAmount() != 0) {
                sugstamnt = d.getUgstAmount();
            } else if (d.getUgstAmount() == 0 && d.getSgstAmount() != 0) {
                sugstamnt = d.getSgstAmount();
            }

            item.setSugstamnt(df.format(sugstamnt).replace("-", ""));
            gtsugst += sugstamnt;

            item.setCessamnt(df.format(d.getCessAmount()).replace("-", ""));
            gtcess += d.getCessAmount();

            item.setCessperct(df.format(0.00));

            item.setTotaltax(df.format(d.getTaxableComponent() + d.getNonTaxableFareComponent() + d.getCgstAmount()
                    + d.getIgstAmount() + sugstamnt + d.getCessAmount()).replace("-", ""));

            items.add(item);

        }

        mail.setGttaxablevalue(df.format(gttaxablevalue).replace("-", ""));
        mail.setGtnontaxablevalue(df.format(gtnontaxablevalue).replace("-", ""));
        mail.setGttotal(df.format(gttotal).replace("-", ""));
        mail.setGtigst(df.format(gtigst).replace("-", ""));
        mail.setGtcgst(df.format(gtcgst).replace("-", ""));
        mail.setGtsugst(df.format(gtsugst).replace("-", ""));
        mail.setGtcess(df.format(gtcess).replace("-", ""));

        mail.setGttotaltax(df.format(gttotal + gtigst + gtcgst + gtsugst + gtcess).replace("-", ""));

        mail.setItems(items);

        return mail;

    }
}
