package in.indigo.processor;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Arrays;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.eclipse.microprofile.config.inject.ConfigProperty;

import jakarta.enterprise.context.ApplicationScoped;
import lombok.extern.slf4j.Slf4j;

@ApplicationScoped
@Slf4j
public class PreErrorProcessor implements Processor {

    @ConfigProperty(name = "PRE_ERROR_SQL_JOIN_QUERY")
    private String PRE_ERROR_SQL_JOIN_QUERY;

    @ConfigProperty(name = "RECORD_UPLOADED_QUERY")
    private String RECORD_UPLOADED_QUERY;

    @ConfigProperty(name = "PRE_ERROR_FILE_PATH_UPDATED_CSV")
    private String PRE_ERROR_FILE_PATH_UPDATED_CSV;

    @ConfigProperty(name = "PRE_ERROR_FOLDER_CSV")
    private String PRE_ERROR_FOLDER_CSV;

    @ConfigProperty(name = "PRE_ERROR_INVSKYEXTRACT_FILE_PATH_FINAL_CSV")
    private String PRE_ERROR_INVSKYEXTRACT_FILE_PATH_FINAL_CSV;

    @ConfigProperty(name = "CSV_DELIMITER")
    private String CSV_DELIMITER;

    @Override
    public void process(Exchange exchange) throws Exception {

        File folder = new File(PRE_ERROR_INVSKYEXTRACT_FILE_PATH_FINAL_CSV);

        if (!folder.exists()) {

            folder.mkdirs();
        } else {
            deleteFilesOnly(folder);
        }
        String totalRecordQuery = RECORD_UPLOADED_QUERY.replace("0?",
                PRE_ERROR_FILE_PATH_UPDATED_CSV + "/" + exchange.getProperty("blobName").toString());

        String totalRecordToBeCorrectedQuery = RECORD_UPLOADED_QUERY.replace("0?",
                PRE_ERROR_INVSKYEXTRACT_FILE_PATH_FINAL_CSV + "/" + exchange.getProperty("blobName").toString());

        String invSkyExQuery = PRE_ERROR_SQL_JOIN_QUERY.replace("1?",
                PRE_ERROR_FILE_PATH_UPDATED_CSV + "/" + exchange.getProperty("blobName").toString());

        invSkyExQuery = invSkyExQuery.replace("2?",
                PRE_ERROR_FOLDER_CSV + "/" + exchange.getProperty("blobName").toString());

        invSkyExQuery = invSkyExQuery.replace("4?", CSV_DELIMITER);

        invSkyExQuery = invSkyExQuery.replace("3?",
                PRE_ERROR_INVSKYEXTRACT_FILE_PATH_FINAL_CSV + "/" + exchange.getProperty("blobName").toString());

        invSkyExQuery = invSkyExQuery.replace("0?", "a");

        try (
                Connection conn = DriverManager.getConnection("jdbc:duckdb:");
                Statement stmt = conn.createStatement();) {
            System.out.println(invSkyExQuery);

            ResultSet totalRecord = stmt.executeQuery(totalRecordQuery);

            if (totalRecord.next()) {
                System.out.println("Total Rows: " + totalRecord.getInt(1));
                exchange.setProperty("totalRecordUploaded", totalRecord.getInt(1));
            }

            // Execute the EXPORT query
            stmt.execute(invSkyExQuery);

            System.out.println(
                    "Results successfully exported to " + PRE_ERROR_INVSKYEXTRACT_FILE_PATH_FINAL_CSV
                            + "/final_result.csv");

            ResultSet recordToBeUpdate = stmt.executeQuery(totalRecordToBeCorrectedQuery);

            if (recordToBeUpdate.next()) {
                exchange.setProperty("totalRecordUpdated", recordToBeUpdate.getInt(1));
                System.out.println("Total Rows: " + recordToBeUpdate.getInt(1));
            }

            // Cleanup
            stmt.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            String filePathAudit = PRE_ERROR_FILE_PATH_UPDATED_CSV + "/"
                    + exchange.getProperty("blobName").toString();
            String filePathDwh = PRE_ERROR_FOLDER_CSV + "/" + exchange.getProperty("blobName").toString();

            // Create a File object
            List<String> paths = Arrays.asList(filePathAudit, filePathDwh);

            for (String path : paths) {
                File file = new File(path);

                // Check if the file exists and delete it
                if (file.exists()) {
                    boolean deleted = file.delete();
                    if (deleted) {
                        System.out.println("File deleted successfully: " + path);
                    } else {
                        System.out.println("Failed to delete the file: " + path);
                    }
                } else {
                    System.out.println("File does not exist: " + path);
                }
            }
        }
    }

    private static void deleteFilesOnly(File directory) {
        // Validate if the given path is a directory
        if (directory.exists() && directory.isDirectory()) {
            File[] files = directory.listFiles(); // List all files and subdirectories
            if (files != null) {
                for (File file : files) {
                    if (file.isFile()) {
                        file.delete();
                    } else if (file.isDirectory()) {
                        // Recursively delete files inside the subdirectory
                        deleteFilesOnly(file);
                    }
                }
            }
        } else {
            System.out.println("Invalid directory: " + directory.getAbsolutePath());
        }
    }
}
