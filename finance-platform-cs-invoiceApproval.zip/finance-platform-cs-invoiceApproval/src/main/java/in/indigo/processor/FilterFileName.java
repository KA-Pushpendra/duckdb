package in.indigo.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import jakarta.enterprise.context.ApplicationScoped;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ApplicationScoped
public class FilterFileName implements Processor {

    @Override
    public void process(Exchange exchange) throws Exception {
        String blobName = exchange.getIn().getHeader("blobName", String.class);
        log.info("------------------->" + blobName);

        if (blobName != null && !blobName.isEmpty()) {
         
           

            String updatedFileName = blobName.replaceAll("\\(.*?\\)\\.xlsx", "").replaceAll("\\.xlsx", "");
            log.info("exact file name: " + updatedFileName);
            exchange.setProperty("blobName", updatedFileName.trim() + ".csv");
            exchange.setProperty("ErrorFile", updatedFileName.trim() + ".xlsx");
            exchange.getIn().setHeader("CamelAzureStorageBlobBlobName",updatedFileName.trim() + ".xlsx");
        } else {
            log.error("Header 'blobName' is null or empty.");
        }
    }

}
