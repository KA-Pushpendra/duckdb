package in.indigo.processor;

import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Arrays;
import java.util.List;

@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class PostErrorProcessor implements Processor {

    @ConfigProperty(name = "POST_ERROR_SQL_JOIN_QUERY")
    private String POST_ERROR_SQL_JOIN_QUERY;

    @ConfigProperty(name = "POST_ERROR_FILE_PATH_UPDATED_CSV")
    private String POST_ERROR_FILE_PATH_UPDATED_CSV;

    @ConfigProperty(name = "POST_ERROR_FOLDER_CSV")
    private String POST_ERROR_FOLDER_CSV;

    @ConfigProperty(name = "POST_ERROR_DWH_FILE_PATH_FINAL_CSV")
    private String POST_ERROR_DWH_FILE_PATH_FINAL_CSV;

    @ConfigProperty(name = "POST_ERROR_AUDIT_FILE_PATH_FINAL_CSV")
    private String POST_ERROR_AUDIT_FILE_PATH_FINAL_CSV;
    @ConfigProperty(name = "CSV_DELIMITER")
    private String CSV_DELIMITER;

    @Override
    public void process(Exchange exchange) throws Exception {

        File folder = new File(POST_ERROR_DWH_FILE_PATH_FINAL_CSV);
        File folder1 = new File(POST_ERROR_AUDIT_FILE_PATH_FINAL_CSV);

        if (!folder.exists()) {

            folder.mkdirs();
        }
        if (!folder1.exists()) {

            folder1.mkdirs();
        }

        String query = POST_ERROR_SQL_JOIN_QUERY.replace("1?",
                POST_ERROR_FOLDER_CSV + "/" + exchange.getProperty("blobName").toString());

        query = query.replace("2?",
                POST_ERROR_FILE_PATH_UPDATED_CSV + "/" + exchange.getProperty("blobName").toString());

        query = query.replace("4?", CSV_DELIMITER);

        String dwhQuery = query.replace("3?",
                POST_ERROR_DWH_FILE_PATH_FINAL_CSV + "/" + exchange.getProperty("blobName").toString());

        dwhQuery = dwhQuery.replace("0?", "a");

        String auditQuery = query.replace("3?",
                POST_ERROR_AUDIT_FILE_PATH_FINAL_CSV + "/" + exchange.getProperty("blobName").toString());

        auditQuery = auditQuery.replace("0?", "b");
        try (
                Connection conn = DriverManager.getConnection("jdbc:duckdb:");
                Statement stmt = conn.createStatement();) {
            System.out.println(dwhQuery);
            System.out.println(auditQuery);

            // Execute the EXPORT query
            stmt.execute(dwhQuery);
            stmt.execute(auditQuery);

            System.out.println(
                    "Results successfully exported to " + POST_ERROR_FILE_PATH_UPDATED_CSV + "/final_result.csv");

            // Cleanup
            stmt.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            String filePathAudit = POST_ERROR_FOLDER_CSV + "/"
                    + exchange.getProperty("blobName").toString();
            String filePathDwh = POST_ERROR_FILE_PATH_UPDATED_CSV + "/" + exchange.getProperty("blobName").toString();

            // Create a File object
            List<String> paths = Arrays.asList(filePathAudit, filePathDwh);

            for (String path : paths) {
                File file = new File(path);

                // Check if the file exists and delete it
                if (file.exists()) {
                    boolean deleted = file.delete();
                    if (deleted) {
                        System.out.println("File deleted successfully: " + path);
                    } else {
                        System.out.println("Failed to delete the file: " + path);
                    }
                } else {
                    System.out.println("File does not exist: " + path);
                }
            }
        }
    }

}
