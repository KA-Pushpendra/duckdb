package in.indigo.route;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.stream.Collectors;

import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.jackson.JacksonDataFormat;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import in.indigo.entity.InvoiceDWH;
import in.indigo.processor.KafkaProcessor;
import in.indigo.processor.PostErrorProcessor1;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@ApplicationScoped
public class MailSendRoute extends RouteBuilder {

        private final KafkaProcessor kafkaProcessor;

        private final PostErrorProcessor1 postErrorProcessor1;
        ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule())
                        .setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
        JacksonDataFormat jacksonDataFormat = new JacksonDataFormat(Object.class);

        @Override
        public void configure() throws Exception {
                jacksonDataFormat.setObjectMapper(objectMapper);
                onException(Exception.class)
                                .log(LoggingLevel.ERROR,
                                                "exception occur while processing: ${exception.message}\nStack Trace: ${exception.stacktrace}")
                                .handled(true)

                                .end();

                from("seda:mailsend")
                                .id("direct:mailsend")
                                .process(postErrorProcessor1)
                                .split().body().parallelProcessing()
                                .process(exchange -> {
                                        List<InvoiceDWH> body = Arrays
                                                        .asList(exchange.getIn().getBody(InvoiceDWH[].class));
                                        Map<String, List<InvoiceDWH>> groupedInvoices = body.stream()
                                                        .collect(Collectors.groupingBy(InvoiceDWH::getPnr));

                                        List<List<InvoiceDWH>> result = new ArrayList<>(groupedInvoices.values());
                                        exchange.getIn().setBody(result);
                                })
                                .split().body().parallelProcessing()
                                .process(kafkaProcessor)
                                .split().body().parallelProcessing()
                                // .marshal().json(JsonLibrary.Jackson)
                                .marshal(jacksonDataFormat)
                                .log(LoggingLevel.INFO, "sending message to kafka.")
                                .setHeader("camelFileName",constant("test.json"))
                                // .to("file://json")

                                .toD("kafka:{{KAFKA_TOPIC_NAME}}?brokers={{KAFKA_BOOTSTRAP_SERVER}}&lingerMs=5")
                                .log("body after kafka send: ${body}")
                                .end()
                                .end()
                                .end()
                                .end();
        }

}
