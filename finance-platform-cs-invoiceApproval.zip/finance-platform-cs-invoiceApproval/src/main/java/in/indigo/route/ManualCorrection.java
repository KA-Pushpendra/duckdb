package in.indigo.route;

import com.azure.identity.ClientSecretCredential;
import com.azure.identity.ClientSecretCredentialBuilder;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import in.indigo.processor.XlsxToCsv;
import in.indigo.Aggregator.AuditDwhStrategy;
import in.indigo.Aggregator.DWHStrategy;
import in.indigo.entity.FileStatus;
import in.indigo.entity.InvSkyExtract;
import in.indigo.entity.InvoiceDWH;
import in.indigo.processor.FillUpPreErrorData;
import in.indigo.processor.FilterFileName;
import in.indigo.processor.GetDateForInvoice;
import in.indigo.processor.GetDistinctIds;
import in.indigo.processor.GetDistinctPnr;
import in.indigo.processor.GetDistinctTDate;
import in.indigo.processor.PostErrorProcessor;
import in.indigo.processor.PreErrorProcessor;
import in.indigo.service.FileTrackingService;
import in.indigo.utility.AuditDwhValidator;
import in.indigo.utility.DWHValidator;
import in.indigo.utility.FileStatusEnum;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.http.HttpMethods;
import org.apache.camel.component.jackson.JacksonDataFormat;
import org.apache.camel.dataformat.csv.CsvDataFormat;
import org.eclipse.microprofile.config.inject.ConfigProperty;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class ManualCorrection extends RouteBuilder {

        @ConfigProperty(name = "BLOB_URL")
        private String blobUrl;
        @ConfigProperty(name = "BLOB_ACCOUNT_NAME")
        private String accountName;
        @ConfigProperty(name = "BLOB_PROCESSING_CONTAINER")
        private String processingContainer;
        @ConfigProperty(name = "BLOB_CONTAINER_NAME")
        private String blobContainerName;
        @ConfigProperty(name = "BLOB_ERROR_CONTAINER")
        private String blobErrorContainer;
        @ConfigProperty(name = "BLOB_ARCHIVE_CONTAINER")
        private String blobArchiveContainer;
        @ConfigProperty(name = "CLIENT_ID")
        private String clientId;
        @ConfigProperty(name = "CLIENT_SECRET")
        private String clientSecret;
        @ConfigProperty(name = "TENANT_ID")
        private String tenantId;

        @ConfigProperty(name = "CSV_DELIMITER")
        private Character CSV_DELIMITER;
        private final XlsxToCsv xlsxToCsv;

        private final AuditDwhStrategy auditDwhStrategy;
        private final AuditDwhValidator auditDwhValidator;

        private final GetDistinctTDate getDistinctTDate;

        private final FileTrackingService fileTrackingService;

        private final PostErrorProcessor postErrorProcessor;

        private final PreErrorProcessor preErrorProcessor;

        private final FilterFileName filterFileName;
        private final GetDistinctPnr getDistinctPnr;

        private final GetDistinctIds GetDistinctIds;

        private final GetDateForInvoice getDateForInvoice;
        private final FillUpPreErrorData fillUpPreErrorData;

        private final DWHStrategy dwhStrategy;
        private final DWHValidator dwhValidator;
        List<String> idList = new ArrayList<>();

        Pattern postErrorFilePattern = Pattern.compile("(?i)^post.*");
        Pattern preErrorFilePattern = Pattern.compile("(?i)^pre.*");

        ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule())
                        .setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));

        JacksonDataFormat jacksonDataFormat = new JacksonDataFormat(Object.class);

        private static List<InvoiceDWH> mailSendBody = new ArrayList<>();

        @Override
        public void configure() throws Exception {

                jacksonDataFormat.setObjectMapper(objectMapper);

                CsvDataFormat csv = new CsvDataFormat();
                csv.setDelimiter(CSV_DELIMITER);
                csv.setUseMaps(false);
                String uri = String.format(blobUrl, accountName);

                ClientSecretCredential credential = new ClientSecretCredentialBuilder()
                                .clientId(clientId)
                                .clientSecret(clientSecret)
                                .tenantId(tenantId)
                                .build();

                BlobServiceClient client = new BlobServiceClientBuilder()
                                .endpoint(uri)
                                .credential(credential)
                                .buildClient();

                getContext().getRegistry().bind("client", client);

                onException(Exception.class)
                                .log(LoggingLevel.ERROR,
                                                "exception occur while processing: ${exception.message}\nStack Trace: ${exception.stacktrace}")
                                .handled(true)

                                .process(exchange -> {

                                        String fileName = exchange.getProperty("fileName", String.class);
                                        String uploadedBy = exchange.getIn().getHeader("uploadedBy", String.class);
                                        String fileType = exchange.getProperty("fileType", String.class);
                                        String requestId = exchange.getProperty("requestId", String.class);
                                        fileTrackingService.trackFile(fileName, FileStatusEnum.FAILED.getStatus(),
                                                        "File processing failed. Kindly revisit, download, and correct the errors.",
                                                        uploadedBy,
                                                        fileType, requestId);
                                })
                                .setBody(simple(null))
                                .removeHeaders("*")
                                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"))
                                .setHeader(Exchange.HTTP_METHOD, constant(HttpMethods.GET))
                                .toD("{{DB_POSTING}}/api/v1/cs/error?date=${exchangeProperty.transactionDate}&user=${exchangeProperty.uploadedBy}")

                                .end();

                from("azure-storage-blob://sagstinvoicedev/" + blobContainerName
                                + "?operation=listBlobs&serviceClient=#client")
                                .routeId("list-blob-route")
                                .log("list blob : ${header.CamelAzureStorageBlobBlobName}")
                                .setProperty("fileType", constant("Manual Error Correction"))
                                .process(exchange -> {
                                        mailSendBody.clear();
                                        String blobName = exchange.getIn().getHeader("CamelAzureStorageBlobBlobName",
                                                        String.class);
                                        exchange.getIn().setHeader("blobName", blobName);
                                        exchange.setProperty("fileName", exchange.getIn().getHeader("blobName"));
                                        BlobServiceClient blobServiceClient = exchange.getContext().getRegistry()
                                                        .lookupByNameAndType("client", BlobServiceClient.class);

                                        var blobClient = blobServiceClient.getBlobContainerClient(blobContainerName)
                                                        .getBlobClient(blobName);
                                        var metadata = blobClient.getProperties().getMetadata();

                                        String uploadedBy = metadata.getOrDefault("uploadedBy", "Unknown");
                                        exchange.getIn().setHeader("uploadedBy", uploadedBy);
                                        exchange.setProperty("uploadedBy", uploadedBy);
                                        String fileType = exchange.getProperty("fileType", String.class);
                                        String requestId = UUID.randomUUID().toString();
                                        exchange.setProperty("requestId", requestId);
                                        fileTrackingService.trackFile(blobName, FileStatusEnum.IN_PROGRESS.getStatus(),
                                                        "File is being processed", uploadedBy, fileType, requestId);
                                        log.info("Processing blob: {}", blobName);
                                })
                                .toD("azure-storage-blob://sagstinvoicedev/" + blobContainerName
                                                + "?blobName=${header.CamelAzureStorageBlobBlobName}&operation=getBlob&serviceClient=#client")
                                .setHeader("fileName", simple("${header.CamelAzureStorageBlobBlobName}"))
                                .process(exchange -> {

                                        client.getBlobContainerClient(blobContainerName)
                                                        .getBlobClient(exchange.getIn().getHeader("fileName",
                                                                        String.class))
                                                        .delete();

                                })
                                .choice()
                                .when(exchange -> postErrorFilePattern
                                                .matcher(exchange.getIn().getHeader("blobName", String.class))
                                                .matches())
                                .log("processing post error report file.")

                                .to("direct:post-error")
                                .endChoice()
                                .when(exchange -> preErrorFilePattern
                                                .matcher(exchange.getIn().getHeader("blobName", String.class))
                                                .matches())
                                .log("processing pre error report.")
                                .to("direct:pre-error")
                                .endChoice()
                                .otherwise()
                                .log(LoggingLevel.ERROR, "Not a valid file! FileName----->${header.fileName}")
                                .end();

                from("direct:pre-error")
                                .routeId("pre-error-route")
                                .process(filterFileName)

                                .process(xlsxToCsv)
                                .to("file://{{PRE_ERROR_FILE_PATH_UPDATED_CSV}}?fileName=${exchangeProperty.blobName}")
                                .setBody(simple(null))
                                .log("get file from blob----->${exchangeProperty.ErrorFile}")
                                .toD("azure-storage-blob://{{BLOB_ACCOUNT_NAME}}/{{PRE_POST_ERROR_BLOB}}?blobName=${exchangeProperty.ErrorFile}&operation=getBlob&serviceClient=#client")
                                .log("file from blob------> ${exchangeProperty.ErrorFile}")
                                .process(xlsxToCsv)
                                .to("file://{{PRE_ERROR_FOLDER_CSV}}?fileName=${exchangeProperty.blobName}")
                                .process(preErrorProcessor)
                                .to("direct:perform-pre-error-correct")
                                // .process(exchange -> {
                                // String fileName = exchange.getProperty("fileName", String.class);
                                // String fileType = exchange.getProperty("fileType", String.class);
                                // String requestId = exchange.getProperty("requestId", String.class);
                                // String totalRecordUploaded = exchange.getProperty("totalRecordUploaded",
                                // String.class);
                                // String totalRecordUpdated = exchange.getProperty("totalRecordUpdated",
                                // String.class);

                                // FileStatus fileStatus = new FileStatus();
                                // fileStatus.setFileName(fileName);
                                // fileStatus.setStatus(FileStatusEnum.COMPLETED.getStatus());
                                // fileStatus.setReason("All records updated successfully.");
                                // fileStatus.setModifiedBy(
                                // exchange.getIn().getHeader("uploadedBy", String.class));
                                // fileStatus.setFileType(fileType);
                                // fileStatus.setRequestId(requestId);

                                // if (totalRecordUpdated.equals(totalRecordUploaded)) {
                                // // fileTrackingService.trackFile(fileName,
                                // // FileStatusEnum.COMPLETED.getStatus(),
                                // // "All records updated successfully.",
                                // // exchange.getIn().getHeader("uploadedBy", String.class),
                                // // fileType, requestId);
                                // fileStatus.setReason("All records updated successfully.");

                                // } else {
                                // // fileTrackingService.trackFile(fileName,
                                // // FileStatusEnum.COMPLETED.getStatus(),
                                // // "Records Uploaded: " + totalRecordUploaded
                                // // + " Records Updated: "
                                // // + totalRecordUpdated
                                // // + ", Please download and reupload remaining unsuccessful records.",
                                // // exchange.getIn().getHeader("uploadedBy", String.class),
                                // // fileType, requestId);
                                // fileStatus.setReason("Records Uploaded: " + totalRecordUploaded
                                // + " Records Updated: "
                                // + totalRecordUpdated
                                // + ", Please download and reupload remaining unsuccessful records.");
                                // }
                                // exchange.setProperty("fileStatus",fileStatus);
                                // })

                                .setBody(simple(null))
                                .log("deleting file from blob")
                                .toD("azure-storage-blob://{{BLOB_ACCOUNT_NAME}}/{{PRE_POST_ERROR_BLOB}}?blobName=${exchangeProperty.ErrorFile}&operation=deleteBlob&serviceClient=#client")

                                .log("Pre Error completed")
                                .end();

                from("direct:perform-pre-error-correct")
                                .routeId("perform-pre-error-correct")
                                .process(getDistinctTDate)
                                // .split().body().stopOnException()

                                .setProperty("originalTransactionDate", simple("${body}"))
                                .process(exchange -> {
                                        idList.clear();
                                        List<String> formatedDateList = new ArrayList<>();
                                        List<String> traDateList = Arrays
                                                        .asList(exchange.getIn().getBody(String[].class));
                                        DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                                        DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
                                        for (String strDate : traDateList) {
                                                log.info("------------->"+strDate);
                                                LocalDate date = LocalDate.parse(strDate, inputFormatter);
                                                String formattedDate = date.format(outputFormatter);
                                                formatedDateList.add(formattedDate);
                                        }
                                        if (!(formatedDateList.size() > 0)) {
                                                exchange.getIn().setBody("no data");
                                                return;
                                        }
                                        exchange.setProperty("formatedDateList", formatedDateList);
                                        exchange.getIn().setBody(formatedDateList);
                                })
                                .marshal(jacksonDataFormat)
                                .removeHeaders("*")
                                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"))
                                .setHeader(Exchange.HTTP_METHOD, constant(HttpMethods.POST))
                                .toD("{{DB_POSTING}}/api/v1/cs/pre-error-series?user=${exchangeProperty.uploadedBy}&requestType=PRE_ERROR")

                                .process(exchange -> {
                                        String body = exchange.getIn().getBody(String.class);
                                        if ("Process Already Running".equalsIgnoreCase(body)) {
                                                String fileName = exchange.getProperty("fileName", String.class);
                                                String uploadedBy = exchange.getIn().getHeader("uploadedBy",
                                                                String.class);
                                                String fileType = exchange.getProperty("fileType", String.class);
                                                String requestId = exchange.getProperty("requestId", String.class);
                                                fileTrackingService.trackFile(fileName,
                                                                FileStatusEnum.FAILED.getStatus(),
                                                                "File processing failed. Kindly revisit, download, and correct the errors.",
                                                                uploadedBy,
                                                                fileType, requestId);
                                                exchange.setRouteStop(true);
                                                return;
                                        }
                                })
                                .setBody(simple("${exchangeProperty.originalTransactionDate}"))
                                .split().body().stopOnException()
                                .process(exchange -> {
                                        DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                                        DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");

                                        LocalDate date = LocalDate.parse(
                                                        exchange.getIn().getBody(String.class),
                                                        inputFormatter);
                                        String formattedDate = date.format(outputFormatter);
                                        exchange.setProperty("transactionDate", formattedDate);

                                })

                                .process(getDistinctPnr)
                                .split(body()).parallelProcessing().streaming().stopOnException()
                                .log("--------pnr-----------?>${body}")
                                .process(GetDistinctIds)
                                .log("----------ides---------?>${body}")
                                .process(exchange -> {
                                        idList.addAll(Arrays.asList(exchange.getIn().getBody(String[].class)));
                                })
                                .process(getDateForInvoice)
                                .process(exchange -> {
                                        List<InvSkyExtract> list = Arrays
                                                        .asList(exchange.getIn().getBody(InvSkyExtract[].class));
                                        List<List<InvSkyExtract>> dataList = list.stream()
                                                        .collect(Collectors.groupingBy(InvSkyExtract::getPnr)).values()
                                                        .stream()
                                                        .collect(Collectors.toList());
                                        exchange.getIn().setBody(dataList);

                                })
                                .split(body()).parallelProcessing().streaming().stopOnException()
                                .process(fillUpPreErrorData)
                                .marshal(jacksonDataFormat)
                                .removeHeaders("*")
                                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"))
                                .setHeader(Exchange.HTTP_METHOD, constant(HttpMethods.POST))
                                .toD("{{INVOICE_ORCHESTRATION}}/api/v1/cs/run-pre-error?date=${exchangeProperty.transactionDate}&user=${exchangeProperty.uploadedBy}&splitNumber=${exchangeProperty.CamelSplitIndex}")
                                .end()
                                .end()
                                .end()
                                .process(exchange -> {
                                        String totalRecordUploaded = exchange.getProperty("totalRecordUploaded",
                                                        String.class);
                                        String totalRecordUpdated = exchange.getProperty("totalRecordUpdated",
                                                        String.class);

                                        if (totalRecordUpdated.equals(totalRecordUploaded)) {

                                                exchange.setProperty("reason", "All records updated successfully.");

                                        } else {

                                                exchange.setProperty("reason", "Records Uploaded: "
                                                                + totalRecordUploaded
                                                                + " Records Updated: "
                                                                + totalRecordUpdated
                                                                + ", Please download and reupload remaining unsuccessful records.");
                                        }
                                        exchange.getIn().setBody(idList);

                                })
                                .marshal(jacksonDataFormat)
                                .removeHeaders("*")
                                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"))
                                .setHeader(Exchange.HTTP_METHOD, constant(HttpMethods.POST))
                                .toD("{{DB_POSTING}}/api/v1/cs/pre-error-postCompletion?requestId=${exchangeProperty.requestId}&reason=${exchangeProperty.reason}")
                                .process(exchange -> {
                                        idList.clear();
                                })
                                .setBody(simple("Data transfer complete"))
                                .log("Data transfer complete")
                                // .end()
                                .log("pre error complete");

                from("direct:post-error")
                                .routeId("post-error-route")
                                .process(filterFileName)

                                .process(xlsxToCsv)
                                .to("file://{{POST_ERROR_FILE_PATH_UPDATED_CSV}}?fileName=${exchangeProperty.blobName}")
                                .setBody(simple(null))
                                .log("get file from blob->${exchangeProperty.ErrorFile}")
                                .log("get file from blob->${headers}")
                                .toD("azure-storage-blob://{{BLOB_ACCOUNT_NAME}}/{{PRE_POST_ERROR_BLOB}}?blobName=${exchangeProperty.ErrorFile}&operation=getBlob&serviceClient=#client")

                                .process(xlsxToCsv)
                                .to("file://{{POST_ERROR_FOLDER_CSV}}?fileName=${exchangeProperty.blobName}")

                                .process(postErrorProcessor)

                                .setBody(simple(null))
                                .multicast().parallelProcessing()
                                .to("direct:insertaudit")
                                .to("direct:dwhupdate")
                                .end()

                                .process(exchange -> {
                                        String fileName = exchange.getProperty("fileName", String.class);
                                        String fileType = exchange.getProperty("fileType", String.class);
                                        String requestId = exchange.getProperty("requestId", String.class);
                                        fileTrackingService.trackFile(fileName, FileStatusEnum.COMPLETED.getStatus(),
                                                        "Post Errors has been corrected",
                                                        exchange.getIn().getHeader("uploadedBy", String.class),
                                                        fileType, requestId);
                                })
                                .setBody(simple(null))
                                .log("deleting file from blob")
                                .toD("azure-storage-blob://{{BLOB_ACCOUNT_NAME}}/{{PRE_POST_ERROR_BLOB}}?blobName=${exchangeProperty.ErrorFile}&operation=deleteBlob&serviceClient=#client")

                                .log("Post Error Process completed");

                from("direct:insertaudit")
                                .id("direct:insertaudit")
                                .log("dwh update started")
                                .setHeader(Exchange.FILE_NAME, simple("${exchangeProperty.blobName}"))
                                .pollEnrich("file://{{POST_ERROR_AUDIT_FILE_PATH_FINAL_CSV}}/?delete=true&readLock=changed")
                                .unmarshal(csv)
                                .split(body(), auditDwhStrategy).streaming().stopOnException()

                                .process(auditDwhValidator)
                                .end()
                                .end();

                from("direct:dwhupdate")
                                .id("direct:dwhupdate")
                                .log("dwh update started")
                                .setHeader(Exchange.FILE_NAME, simple("${exchangeProperty.blobName}"))
                                .pollEnrich("file://{{POST_ERROR_DWH_FILE_PATH_FINAL_CSV}}/?delete=false&readLock=changed")

                                .unmarshal(csv)
                                .split(body(), dwhStrategy).streaming().stopOnException()
                                .process(dwhValidator)
                                .process(exchange -> {
                                        mailSendBody.add(exchange.getIn().getBody(InvoiceDWH.class));
                                })
                                .end()
                                .setBody(constant(mailSendBody))
                                .log("calling for mail send")
                                .to("seda:mailsend?waitForTaskToComplete=Never")
                                // .log("message send-------------------------")
                                .end();

        }
}
