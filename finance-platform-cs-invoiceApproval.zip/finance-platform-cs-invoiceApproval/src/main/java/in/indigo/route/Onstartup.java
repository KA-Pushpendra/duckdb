package in.indigo.route;

import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.http.HttpMethods;

import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;

@ApplicationScoped
public class Onstartup extends RouteBuilder {

    @Override
    public void configure() throws Exception {
        from("timer://startup?repeatCount=1")
                .routeId("startup-process")
                .setBody(simple(null))
                .removeHeaders("*")
                .setHeader(Exchange.CONTENT_TYPE, constant("application/json"))
                .setHeader(Exchange.HTTP_METHOD, constant(HttpMethods.GET))
                .toD("{{DB_POSTING}}/api/v1/cs/pre-error-startup")

                .end();
    }
}