package in.indigo.route;

import com.azure.identity.ClientSecretCredential;
import com.azure.identity.ClientSecretCredentialBuilder;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.google.gson.Gson;
import in.indigo.entity.InvSkyExtract;
import in.indigo.entity.InvoiceDWH;
import in.indigo.pojo.ResponseMessage;
import in.indigo.service.FileTrackingService;
import in.indigo.utility.MapToObj;
import in.indigo.utility.UserUtil;
import io.quarkus.security.identity.SecurityIdentity;
import io.quarkus.vertx.http.runtime.security.QuarkusHttpUser;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.core.MediaType;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.attachment.AttachmentMessage;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.platform.http.vertx.VertxPlatformHttpConstants;
import org.apache.camel.model.rest.RestBindingMode;
import org.apache.camel.util.IOHelper;
import org.eclipse.microprofile.config.inject.ConfigProperty;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;

@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class UploadBlob extends RouteBuilder {

    @ConfigProperty(name = "BLOB_ACCOUNT_NAME")
    private String accountName;
    @ConfigProperty(name = "BLOB_PROCESSING_CONTAINER")
    private String processingContainer;
    @ConfigProperty(name = "BLOB_CONTAINER_NAME")
    private String blobContainerName;
    @ConfigProperty(name = "BLOB_ERROR_CONTAINER")
    private String blobErrorContainer;
    @ConfigProperty(name = "BLOB_ARCHIVE_CONTAINER")
    private String blobArchiveContainer;
    @ConfigProperty(name = "CLIENT_ID")
    private String clientId;
    @ConfigProperty(name = "CLIENT_SECRET")
    private String clientSecret;
    @ConfigProperty(name = "TENANT_ID")
    private String tenantId;
    @ConfigProperty(name = "BLOB_URL")
    private String blobUrl;
    @Inject
    UserUtil userUtil;
    @Inject
    MapToObj mapToObj;

    @Inject
    EntityManager entityManager;

    ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());
    private final FileTrackingService trackingService;

    Pattern postErrorFilePattern = Pattern.compile("(?i)^post.*");
    Pattern preErrorFilePattern = Pattern.compile("(?i)^pre.*");

    @Override
    public void configure() throws Exception {
        String uri = String.format(blobUrl, accountName);

        ClientSecretCredential credential = new ClientSecretCredentialBuilder()
                .clientId(clientId)
                .clientSecret(clientSecret)
                .tenantId(tenantId)
                .build();

        BlobServiceClient client = new BlobServiceClientBuilder()
                .endpoint(uri)
                .credential(credential)
                .buildClient();

        getContext().getRegistry().bind("client", client);

        restConfiguration()
                .component("platform-http")
                .bindingMode(RestBindingMode.auto);

        rest("/api/v1/cs/upload-error")
                .post()
                .produces(MediaType.APPLICATION_JSON)
                .to("direct:process-file");

        from("direct:process-file")
                .routeId("process-file-route")
                .log("process-file-route")
                .process(exchange -> {
                    AttachmentMessage am = exchange.getMessage(AttachmentMessage.class);

                    QuarkusHttpUser user = exchange.getMessage()
                            .getHeader(VertxPlatformHttpConstants.AUTHENTICATED_USER, QuarkusHttpUser.class);
                    SecurityIdentity identity = user.getSecurityIdentity();
                    String currentUser = userUtil.getCurrentUser(identity);
                    exchange.setVariable("global:currentUser", currentUser);

                    if (am == null || !am.hasAttachments()) {
                        exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, 400);

                        exchange
                                .getIn()
                                .setBody(ResponseMessage
                                        .builder()
                                        .status(false)
                                        .message("No any attachment added!")
                                        .build());
                        log.error("No any attachment added!");

                        exchange.getIn().setHeader("error", "No any attachment added");
                    } else {
                        am.getAttachmentObjects()
                                .entrySet().stream().findAny().ifPresent(entry -> {

                                    log.info("fileName---->{}", entry.getKey());

                                    exchange.getIn().setHeader("fileName", entry.getKey());

                                    try {
                                        exchange.getIn().setBody(entry.getValue().getDataHandler().getInputStream());
                                    } catch (IOException e) {
                                        throw new RuntimeException(e);
                                    }
                                });
                    }
                })
                .choice()
                .when(exchange -> checkInvoiceStatusAndFileStatus())
                    .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(400)) 
                    .setBody(constant("Invoice OR Pre-Error in progress. Please upload file after some time!")) // Set response message
                    .stop() // Prevent further execution
                .otherwise()
                .to("direct:validate-file")
                .to("direct:upload-to-blob")
                .process(exchange -> {
                    Object body = exchange.getIn().getBody();

                    Gson gson = new Gson();

                    String jsonRes = gson.toJson(body);

                    log.info("res--------->{}", jsonRes);

                    exchange.getIn().setBody(jsonRes);
                })
                // .marshal().json(JsonLibrary.Jackson)
                .end();

        from("direct:validate-file")
                .routeId("validate-file-route")
                .process(exchange -> {
                    if (exchange.getIn().getHeader("error", String.class) != null) {

                    } else if (postErrorFilePattern.matcher(exchange.getIn().getHeader("fileName", String.class))
                            .matches()) {
                        InputStream is = exchange.getIn().getBody(InputStream.class);

                        try {
                            mapToObj.convertToClass(is, InvoiceDWH.class);
                            log.info("File validated successfully.");
                        } catch (Exception e) {
                            // exchange.getIn().setBody(e.getMessage());
                            exchange
                                    .getIn()
                                    .setBody(ResponseMessage
                                            .builder()
                                            .status(false)
                                            .message(e.getMessage())
                                            .build());
                            exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, 400);

                            exchange.getIn().setHeader("error", e.getMessage());

                            log.error("error occurred while validating posterror file--->", e);
                        }
                    } else if (preErrorFilePattern.matcher(exchange.getIn().getHeader("fileName", String.class))
                            .matches()) {
                        InputStream is = exchange.getIn().getBody(InputStream.class);

                        try {
                            mapToObj.convertToClass(is, InvSkyExtract.class);
                            log.info("File validated successfully.");
                        } catch (Exception e) {
                            // exchange.getIn().setBody(e.getMessage());
                            exchange
                                    .getIn()
                                    .setBody(ResponseMessage
                                            .builder()
                                            .status(false)
                                            .message(e.getMessage())
                                            .build());
                            exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, 400);

                            exchange.getIn().setHeader("error", e.getMessage());

                            log.error("error occurred while validating preerror file--->", e);
                        }
                    } else {
                        exchange.getIn().setHeader("error", "Not a valid fileName!");
                        exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, 400);

                        exchange
                                .getIn()
                                .setBody(ResponseMessage
                                        .builder()
                                        .status(false)
                                        .message("FileName not valid : "
                                                + exchange.getIn().getHeader("fileName", String.class))
                                        .build());

                        log.error("Not a valid fileName!---->{}", exchange.getIn().getHeader("fileName", String.class));
                    }
                })
                .choice()
                .when(exchange -> exchange.getIn().getBody() instanceof ResponseMessage)
                .process(exchange -> {
                    String fileName = exchange.getIn().getHeader("fileName", String.class);
                    String uploadedBy = exchange.getVariable("global:currentUser", String.class);
                    String requestId = UUID.randomUUID().toString();
                    exchange.setProperty("requestId", requestId);
                    trackingService.trackFile(fileName, "FAILED", "Invalid file detected", uploadedBy,
                            "Manual Error Correction", requestId);
                })
                .end();

        from("direct:upload-to-blob")
                .routeId("upload-to-blob-route")
                .choice().when(header("error").isNull())
                .process(exchange -> {
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();

                    IOHelper.copyAndCloseInput(exchange.getIn().getBody(InputStream.class), baos);

                    exchange.getIn().setBody(baos);

                    Map<String, String> metaData = new HashMap<>();

                    String currentUser = exchange.getVariable("global:currentUser", String.class);
                    metaData.put("uploadedBy",
                            (currentUser != null && !currentUser.isBlank()) ? currentUser : "System");

                    exchange.getIn().setHeader("CamelAzureStorageBlobMetadata", metaData);

                })
                .doTry()
                .toD("azure-storage-blob://sagstinvoicedev/{{BLOB_CONTAINER_NAME}}?operation=uploadBlockBlob&blobName=${header.fileName}&serviceClient=#client")
                .process(exchange -> {

                    // exchange.getIn().setBody("File uploaded successfully");

                    exchange
                            .getIn()
                            .setBody(ResponseMessage
                                    .builder()
                                    .status(true)
                                    .message("File uploaded successfully")
                                    .build());

                    log.info("File uploaded successfully");
                })
                // .marshal().json(JsonLibrary.Jackson)
                .doCatch(Exception.class)
                .log(LoggingLevel.ERROR, "exception occured while uploading to blob-->${exception.message}")
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(400))
                .setBody().simple("${exception.message}")
                .process(exchange -> exchange
                        .getIn()
                        .setBody(ResponseMessage
                                .builder()
                                .status(false)
                                .message(exchange
                                        .getIn()
                                        .getBody(String.class))
                                .build()))
                .end();

    }

    @Transactional
    public Boolean checkInvoiceStatusAndFileStatus() {

        String query0 = "SELECT count(*) FROM FileStatus_CS WHERE Status = 'IN PROGRESS'";
        String query1 = "SELECT count(*) FROM MstInvoiceTransactionDetails_CS WHERE InvoiceStatus = 'Invoice Processing'";
        int count0 = (int) entityManager
                .createNativeQuery(query0).getSingleResult();
        int count1 = (int) entityManager
                .createNativeQuery(query1).getSingleResult();

        if (count0 > 0 || count1 > 0) {
            return true;
        }
        return false;
    }
}
