package in.indigo.utility;

import java.util.Map;

import io.smallrye.config.ConfigMapping;
import jakarta.enterprise.context.ApplicationScoped;

@ConfigMapping(prefix = "dwh.csv")
@ApplicationScoped
public interface DwhCsvMappingConfig {
    Map<String, String> mapping();

}
