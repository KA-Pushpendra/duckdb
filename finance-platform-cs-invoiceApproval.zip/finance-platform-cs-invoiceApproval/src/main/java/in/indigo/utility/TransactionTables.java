package in.indigo.utility;

import java.util.List;
import java.util.stream.Stream;

public class TransactionTables {

    public static final List<String> TABLE_NAMES = Stream.of("PkgAudit", "MstInvStatus",
            "MstInvoiceTransactionDetails", "FileStatus", "Inv_SkyExtract", "Invoice_DWH", "ErrorPNRRecords",
            "ErrorInvoiceDetails", "Inv_SkyExtract_Ac", "Audit_invoice_DWH", "Inv_series", "Template", "Report",
            "Report_status", "Inv_GLExtractdwh", "MstGLStatus", "MstGLTransactionDetails").map(String::toUpperCase)
            .toList();

    private TransactionTables() {
    }

}