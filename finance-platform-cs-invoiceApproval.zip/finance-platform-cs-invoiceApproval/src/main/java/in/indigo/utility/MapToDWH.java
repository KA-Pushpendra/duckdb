package in.indigo.utility;

import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import in.indigo.entity.InvoiceDWH;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import lombok.val;
import lombok.extern.slf4j.Slf4j;

@ApplicationScoped
@Slf4j
@RequiredArgsConstructor
public class MapToDWH {

    private final DwhCsvMappingConfig csvMappingConfig;

    public InvoiceDWH process(List<String> csvRow, Map<String, Integer> strPosMap) throws Exception {

        InvoiceDWH invoiceDWH = new InvoiceDWH();

        Map<String, String> columnToFieldMap = csvMappingConfig.mapping();

        for (Map.Entry<String, String> entry : columnToFieldMap.entrySet()) {
            String fieldName = entry.getKey(); // InvSkyExtract field
            String headerValue = entry.getValue(); // The CSV header
            int indexNumber = strPosMap.getOrDefault(headerValue, -1);

            if (indexNumber != -1) {
                String value = csvRow.get(indexNumber);
                Field field = InvoiceDWH.class.getDeclaredField(fieldName);
                field.setAccessible(true); // Allow access to private fields

                if (field.getType() == int.class) {
                    value = (value == null || value.isEmpty()) ? "0" : value;
                    field.setInt(invoiceDWH, Integer.parseInt(value));
                } else if (field.getType() == double.class) {
                    value = (value == null || value.isEmpty()) ? "0.0" : value;
                    field.setDouble(invoiceDWH, Double.parseDouble(value));
                } else if (field.getType() == Boolean.class) {
                    value = (value == null || value.isEmpty() || value.equalsIgnoreCase("0")
                            || value.equalsIgnoreCase("false")) ? "false" : "true";
                    field.set(invoiceDWH, Boolean.valueOf(value));
                } else if (field.getType() == boolean.class) {

                    value = (value == null || value.isEmpty() || value.equals("0")) ? "false" : "true";
                    field.setBoolean(invoiceDWH, Boolean.parseBoolean(value));
                } else if (field.getType() == long.class) {
                    value = (value == null || value.isEmpty()) ? "0" : value;
                    field.setLong(invoiceDWH, Long.parseLong(value));
                } else if (field.getType() == float.class) {
                    value = (value == null || value.isEmpty()) ? "0.0f" : value;
                    field.setFloat(invoiceDWH, Float.parseFloat(value));

                } else if (field.getType() == Set.class) {
                    if (value == null || value.isEmpty()) {
                        field.set(invoiceDWH, Collections.emptySet());
                    } else {
                        Set<String> valueSet = new HashSet<>(Arrays.asList(value.split(",")));
                        field.set(invoiceDWH, valueSet);
                    }
                } else if (field.getType() == Date.class) {

                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    SimpleDateFormat outDateFormat = new SimpleDateFormat("MM/d/yyyy");
                    try {
                        Date parsedDate = value == null || value.isEmpty() ? null
                                : outDateFormat.parse(outDateFormat.format(dateFormat.parse(value)));
                        field.set(invoiceDWH, parsedDate);
                    } catch (Exception e) {
                        throw new IllegalArgumentException("Invalid date format for field: " + field.getName());
                    }
                } else if (field.getType() == char.class) {

                    value = (value == null || value.isEmpty()) ? "\u0000" : value;
                    field.setChar(invoiceDWH, value.charAt(0));
                } else if (field.getType() == short.class) {
                    value = (value == null || value.isEmpty()) ? "0" : value;
                    field.setShort(invoiceDWH, Short.parseShort(value));
                } else if (field.getType() == Character.class) {
                    // Handle Character wrapper class
                    value = (value == null || value.isEmpty()) ? null : String.valueOf(value.charAt(0));
                    field.set(invoiceDWH, value != null ? value.charAt(0) : null);
                } else if (field.getType() == String.class) {
                    value = (value == null || value.isEmpty()) ? null : value;
                    field.set(invoiceDWH, value);
                } else {
                    // Handle other data types or custom objects if necessary
                    throw new IllegalArgumentException("Unsupported field type: " + field.getType());
                }

            } else {
                throw new IllegalArgumentException("column missing: " + headerValue);
            }
        }
        return invoiceDWH;
    }

}
