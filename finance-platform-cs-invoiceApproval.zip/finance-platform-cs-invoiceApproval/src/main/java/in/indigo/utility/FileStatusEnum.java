package in.indigo.utility;

public enum FileStatusEnum {

    FAILED("FAILED"),
    IN_PROGRESS("IN PROGRESS"),
    COMPLETED("COMPLETED");

    private final String status;

    FileStatusEnum(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

}