package in.indigo.utility;

import java.util.stream.IntStream;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import in.indigo.entity.AuditInvoiceDWH;
import in.indigo.entity.InvoiceDWH;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@ApplicationScoped
@Slf4j
@RequiredArgsConstructor
public class AuditDwhValidator implements Processor {

    private static Map<String, Integer> strPosMap = new HashMap<>();
    private final MapToDWH mapToAuditDwh;

    ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());

    @Override
    public void process(Exchange exchange) throws Exception {
        @SuppressWarnings("unchecked")

        List<String> csvRow = exchange.getIn().getBody(List.class);
        Integer rowNumber = (Integer) exchange.getProperty("CamelSplitIndex") + 1;

        if (rowNumber == 1) {

            strPosMap = IntStream.range(0, csvRow.size()).boxed().collect(
                    Collectors.toMap(i -> csvRow.get(i).trim().toLowerCase().replace(" ", ""), i -> i));

            exchange.getIn().setBody(1);

        } else {

           InvoiceDWH invoiceDWH = mapToAuditDwh.process(csvRow, strPosMap);
           String str = objectMapper.writeValueAsString(invoiceDWH);
            AuditInvoiceDWH auditInvoiceDWH = objectMapper
                    .readValue(str, AuditInvoiceDWH.class);
            LocalDateTime now = LocalDateTime.now(ZoneId.of("Asia/Kolkata"));
            auditInvoiceDWH.setCreatedDate(now);
            auditInvoiceDWH.setCreatedBy(exchange.getProperty("uploadedBy", String.class));
            exchange.getIn().setBody(auditInvoiceDWH);
        }

    }

}
