package in.indigo.utility;

import in.indigo.Annotations.ExcelColumn;
import in.indigo.Annotations.ExcelToObj;
import io.quarkus.runtime.StartupEvent;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.event.Observes;
import jakarta.ws.rs.BadRequestException;
import lombok.extern.slf4j.Slf4j;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.reflections.Reflections;

import com.monitorjbl.xlsx.StreamingReader;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

@Slf4j
@ApplicationScoped
public class MapToObj {

    Map<Class<?>, Map<Field, String>> classMap;

    void init(@Observes StartupEvent ev) {

        Reflections reflections = new Reflections("in.indigo");

        Set<Class<?>> clazzSet = reflections.getTypesAnnotatedWith(ExcelToObj.class);

        // log.info("clazzSet----->{}",clazzSet);

        classMap = new HashMap<>();

        clazzSet.forEach(clazz -> {
            classMap.put(clazz, new HashMap<>());

            for (Field field : clazz.getDeclaredFields()) {

                // log.info("annotation
                // present--->{}",field.isAnnotationPresent(ExcelColumn.class));

                if (field.isAnnotationPresent(ExcelColumn.class)) {
                    ExcelColumn annotation = field.getAnnotation(ExcelColumn.class);

                    String columnName = annotation.name().isEmpty() ? field.getName() : annotation.name();

                    columnName = columnName.trim().toLowerCase().replace(" ", "");
                    classMap.get(clazz).put(field, columnName);

                }
            }
        });

    }

    public List<Object> convertToClass(InputStream is, Class<?> clazz) throws IOException {

        if (!classMap.containsKey(clazz)) {
            throw new RuntimeException("Class " + clazz.getSimpleName() + " does not marked with annotation "
                    + ExcelToObj.class.getSimpleName());
        }

        List<Object> dataList = new ArrayList<>();

        convertToMap(is)
                .forEach(d -> {
                    Object obj = convertToClass(d, clazz);

                    dataList.add(obj);
                });

        return dataList;

    }

    public List<Map<String, Object>> convertToMap(InputStream is) {

        try (Workbook workbook = StreamingReader.builder()
                .rowCacheSize(100)
                .bufferSize(4096)
                .open(is)) {

            Sheet sheet = workbook.getSheetAt(0);
            List<String> headers = new ArrayList<>();
            List<Map<String, Object>> dataList = new ArrayList<>();
            // Row headersRow = sheet.getRow(0);
            for (Row row : sheet) {
                int lastCellNum = row.getLastCellNum();
                if (row.getRowNum() == 0) {

                    for (int cellNum = 0; cellNum < lastCellNum; cellNum++) {
                        Cell cell = row.getCell(cellNum,
                                Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);

                        String header = "";

                        if (!cell.getCellType().equals(CellType.BLANK)) {
                            header = cell.getStringCellValue().trim().toLowerCase().replace(" ", "");
                        }

                        headers.add(header);

                    }
                } else {

                    Map<String, Object> data = new HashMap<>();
                    for (int cellNum = 0; cellNum < lastCellNum; cellNum++) {

                        Object value = null;

                        Cell cell = row.getCell(cellNum);

                        if (cell != null) {
                            switch (cell.getCellType()) {
                                case STRING:
                                    value = cell.getStringCellValue();
                                    break;
                                case NUMERIC:
                                    if (DateUtil.isCellDateFormatted(cell)) {
                                        value = cell.getDateCellValue();
                                    } else {
                                        value = cell.getNumericCellValue();
                                    }
                                    break;
                                case BOOLEAN:
                                    value = cell.getBooleanCellValue();
                                    break;
                                case BLANK:
                                    break;
                                default:
                                    log.info("Not a valid cell type!");
                            }
                        }

                        if (value instanceof String str && str.isEmpty()) {
                            value = null;
                        }

                        if (!headers.get(cellNum).isEmpty()) {
                            data.put(headers.get(cellNum), value);
                        }

                    }

                    dataList.add(data);
                }
                break;
            }

            return dataList;
        } catch (EncryptedDocumentException | IOException e) {
            // TODO Auto-generated catch block
            throw new BadRequestException("Unsupported file type.");
        }

    }

    public List<Object> convertToClass(List<Map<String, Object>> list, Class<?> clazz) {
        List<Object> dataList = new ArrayList<>();

        list.forEach(d -> {
            Object obj = convertToClass(d, clazz);

            dataList.add(obj);
        });

        return dataList;
    }

    public Object convertToClass(Map<String, Object> dataMap, Class<?> clazz) {

        Map<Field, String> fields = classMap.get(clazz);

        try {

            Object obj = clazz.getConstructor().newInstance();

            fields.forEach((field, column) -> {
                field.setAccessible(true);

                ExcelColumn excelColumn = field.getAnnotation(ExcelColumn.class);

                if (excelColumn.required() && (!dataMap.containsKey(column) || dataMap.get(column) == null)) {
                    throw new RuntimeException(column + " value is required in file!");
                }

                if (dataMap.get(column) != null) {
                    Object value = dataMap.get(column);
                    Class<?> fieldType = field.getType();

                    try {
                        if (fieldType == int.class || fieldType == Integer.class) {

                            if (value instanceof String str) {
                                field.setInt(obj, Integer.parseInt(str));
                            } else {
                                field.setInt(obj, ((Double) value).intValue());
                            }

                        } else if (fieldType == double.class || fieldType == Double.class) {
                            if (value instanceof String str) {
                                field.setDouble(obj, Double.parseDouble(str));
                            } else {
                                field.setDouble(obj, (Double) value);
                            }

                        } else if (fieldType == long.class || fieldType == Long.class) {
                            if (value instanceof String str) {
                                field.setLong(obj, Long.parseLong(str));
                            } else {
                                field.setLong(obj, ((Double) value).longValue());
                            }

                        } else if (fieldType == short.class || fieldType == Short.class) {
                            if (value instanceof String str) {
                                field.setShort(obj, Short.parseShort(str));
                            } else {
                                field.setShort(obj, ((Double) value).shortValue());
                            }

                        } else if (fieldType == char.class) {
                            field.set(obj, value.toString().charAt(0));
                        } else if (fieldType == String.class) {
                            field.set(obj, value.toString());
                        } else if (fieldType == boolean.class || fieldType == Boolean.class) {
                            if (value instanceof String str) {
                                field.set(obj, Boolean.valueOf(str));
                            } else {
                                field.set(obj, value);
                            }

                        } else if (fieldType == java.util.Date.class || fieldType == java.sql.Date.class
                                || fieldType == LocalDate.class || fieldType == LocalDateTime.class) {

                            LocalDateTime localDateTime = null;

                            if (value instanceof String str) {
                                String pattern = field.getAnnotation(ExcelColumn.class).datePattern();

                                localDateTime = parseToLocalDateTime(pattern, str);
                            } else {
                                Date date = (java.util.Date) value;

                                localDateTime = date
                                        .toInstant()
                                        .atZone(ZoneId.of("Asia/Kolkata"))
                                        .toLocalDateTime();
                            }

                            if (fieldType == java.util.Date.class) {
                                field.set(obj, java.util.Date
                                        .from(localDateTime.atZone(ZoneId.of("Asia/Kolkata")).toInstant()));
                            } else if (fieldType == java.sql.Date.class) {
                                field.set(obj, java.sql.Date.valueOf(localDateTime.toLocalDate()));
                            } else if (fieldType == LocalDate.class) {
                                field.set(obj, localDateTime.toLocalDate());
                            } else {
                                field.set(obj, localDateTime);
                            }
                        } else if (fieldType == List.class) {
                            field.set(obj, new ArrayList<>());
                        } else if (fieldType == Set.class) {
                            field.set(obj, new HashSet<>());
                        }

                    } catch (IllegalAccessException e) {
                        throw new RuntimeException(e);
                    }

                }

            });

            return obj;

        } catch (InstantiationException | IllegalAccessException | InvocationTargetException
                | NoSuchMethodException e) {
            throw new RuntimeException(e);
        }
    }

    private LocalDateTime parseToLocalDateTime(String pattern, String str) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);

        try {
            return LocalDateTime
                    .parse(str, formatter);
        } catch (Exception e) {
            try {
                return LocalDate
                        .parse(str, formatter)
                        // .atStartOfDay(ZoneId.of("Asia/Kolkata"))
                        .atStartOfDay();
                // .toLocalDateTime();
            } catch (Exception ex) {
                throw new IllegalArgumentException("Invalid date format! Format: " + pattern + " date: " + str);
            }
        }
    }
}
