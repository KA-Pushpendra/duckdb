package in.indigo.utility;

import io.quarkus.security.identity.SecurityIdentity;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ApplicationScoped
public class UserUtil {

    public String getCurrentUser(SecurityIdentity identity) {
        String userEmail = identity.getPrincipal().getName();

        // Remove domain part (e.g., "@goindigo.in")
        String localPart = userEmail.split("@")[0];

        // Split the local part by dots
        String[] parts = localPart.split("\\.");

        // Ensure only the first and last parts are used, ignoring any middle parts
        String firstName = capitalize(parts[0]);
        String lastName = parts.length > 1 ? capitalize(parts[parts.length - 1]) : "";

        String name = firstName + " " + lastName;
        return name;
    }

    private static String capitalize(String str) {
        if (str == null || str.isEmpty())
            return str;
        return str.substring(0, 1).toUpperCase() + str.substring(1).toLowerCase();
    }
}
