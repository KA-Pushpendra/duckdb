package in.indigo.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name = "Inv_SkyExtract_Ac")
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@ToString
public class InvSkyExtractAc {

    @Id
    @Column(name = "Id")
    private String id;

    @Column(name = "TransactionDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/d/yyyy", timezone = "Asia/Kolkata")
    private Date transactionDate;

    @Column(name = "FileDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/d/yyyy", timezone = "Asia/Kolkata")
    private Date fileDate;

    @Column(name = "DisplayDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/d/yyyy", timezone = "Asia/Kolkata")
    private Date displayDate;

    @Column(name = "FlightNumber")

    private int flightNumber;

    @Column(name = "GoodsServicesType")
    private String goodsServicesType;

    @Column(name = "SAC")
    private int sac;

    @Column(name = "PNR")
    private String pnr;

    @Column(name = "Dep")
    private String dep;

    @Column(name = "Arr")
    private String arr;

    @Column(name = "PlaceOfEmbarkation")
    private String placeOfEmbarkation;

    @Column(name = "StateCode")
    private String stateCode;

    @Column(name = "CustomerGSTIN")
    private String customerGSTIN;

    @Column(name = "CustomerName")
    private String customerName;

    @Column(name = "EmailAddress")
    private String emailAddress;

    @Column(name = "CustomerGSTRegistrationState")
    private String customerGSTRegistrationState;

    @Column(name = "PassengerName")
    private String passengerName;

    @Column(name = "PassengerEmail")
    private String passengerEmail;

    @Column(name = "6EGSTIN")
    private String e6gstin;

    @Column(name = "6ERegisteredAddress")
    private String e6RegisteredAddress;

    @Column(name = "NonTaxableFareComponent")
    private double nonTaxableFareComponent;

    @Column(name = "TaxableComponent")
    private double taxableComponent;

    @Column(name = "CGSTAmount")
    private double cgstAmount;

    @Column(name = "IGSTAmount")
    private double igstAmount;

    @Column(name = "SGSTAmount")
    private double sgstAmount;

    @Column(name = "UGSTAmount")
    private double ugstAmount;

    @Column(name = "AirportCharges")
    private double airportCharges;

    @Column(name = "OriginCountry")
    private String originCountry;

    @Column(name = "IsExempted")
    private boolean isExempted;

    @Column(name = "Cess Amount")
    private double cessAmount;

    @Column(name = "Local Cess Amount")
    private double localCessAmount;

    @Column(name = "AutoCorrectionId")
    private String autoCorrectionIds;

    @Column(name = "IsAutoCorrected")
    private String isAutoCorrected;

    @Column(name = "spExemptedFlight")
    private int spExemptedFlight;

    @Column(name = "spInternational")
    private int spInternational;

    @Column(name = "Agent Code")
    private String agentCode;

}
