package in.indigo.entity;

import java.io.Serializable;
import java.time.LocalDateTime;
import in.indigo.Annotations.ExcelColumn;
import in.indigo.Annotations.ExcelToObj;
import lombok.*;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import jakarta.persistence.*;

@ExcelToObj
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Entity
@Table(name = "Inv_SkyExtract")
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class InvSkyExtract extends PanacheEntityBase implements Serializable {

    @ExcelColumn
    @Id
    @Column(name = "Id")
    public String id;

    @ExcelColumn(required = false)
    @Column(name = "Original Booking Date", length = 255)
    private String originalBookingDate;

    @ExcelColumn
    @Column(name = "Transaction Date")
    private String transactionDate;

    @ExcelColumn(required = false)
    @Column(name = "Reference Date")
    public String referenceDate;

    @ExcelColumn(required = false)
    @Column(name = "Flight Date")
    private String flightDate;

    @ExcelColumn(required = false)
    @Column(name = "Flight Number")
    private int flightNumber;

    @ExcelColumn
    @Column(name = "Description of Goods/Services", length = 255)
    private String descriptionOfGoodsServices;

    @ExcelColumn(required = false)
    @Column(name = "SAC")
    private double sac;

    @ExcelColumn
    @Column(name = "PNR", length = 255)
    private String pnr;

    @ExcelColumn(required = false)
    @Column(name = "Full Itinerary Route", length = 255)
    private String itineraryOrigin;

    @ExcelColumn
    @Column(name = "Sector", length = 255)
    private String sector;

    @ExcelColumn(required = false)
    @Column(name = "Place of Embarkation", length = 255)
    private String placeOfEmbarkation;

    @ExcelColumn(required = false)
    @Column(name = "Customer GSTIN", length = 255)
    private String customerGSTIN;

    @ExcelColumn(required = false)
    @Column(name = "Customer Name", length = 255)
    private String customerName;

    @ExcelColumn(required = false)
    @Column(name = "Email Address", length = 255)
    private String passengerEmail;

    @ExcelColumn(required = false)
    @Column(name = "GST Holder Name", length = 255)
    private String gstHolderName;

    @ExcelColumn(required = false)
    @Column(name = "GST Email Address", length = 255)
    private String gstEmailAddress;

    @ExcelColumn(required = false)
    @Column(name = "Customer GST Registration State", length = 255)
    private String customerGSTRegistrationState;

    @ExcelColumn(required = false)
    @Column(name = "6E GSTIN", length = 255)
    private String e6gstin;

    @ExcelColumn(required = false)
    @Column(name = "6E RegisteredAddress", length = 255)
    private String e6RegisteredAddress;

    @ExcelColumn(required = false)
    @Column(name = "Base Fare")
    private double baseFare;

    @ExcelColumn(required = false)
    @Column(name = "Taxable Fare Component")
    private double taxableFareComponent;

    @ExcelColumn(required = false)
    @Column(name = "Non-Taxable Fare Component")
    private double nonTaxableFareComponent;

    @ExcelColumn(required = false)
    @Column(name = "SSR Fee Code", length = 255)
    private String ssrFeeCode;

    @ExcelColumn(required = false)
    @Column(name = "SSR Component")
    private double ssrComponent;

    @ExcelColumn(required = false)
    @Column(name = "Taxable Component")
    private double taxableComponent;

    @ExcelColumn(required = false)
    @Column(name = "CGST Amount")
    private double cgstAmount;

    @ExcelColumn(required = false)
    @Column(name = "IGST Amount")
    private double igstAmount;

    @ExcelColumn(required = false)
    @Column(name = "SGST Amount")
    private double sgstAmount;

    @ExcelColumn(required = false)
    @Column(name = "UGST Amount")
    private double ugstAmount;

    @ExcelColumn(required = false)
    @Column(name = "GST Amount")
    private double gstAmount;

    @ExcelColumn(required = false)
    @Column(name = "Cess Amount")
    private double cessAmount;

    @ExcelColumn(required = false)
    @Column(name = "Local Currency", length = 255)
    private String localCurrency;

    @ExcelColumn(required = false)
    @Column(name = "Local Base Fare")
    private double localBaseFare;

    @ExcelColumn(required = false)
    @Column(name = "Local Taxable Fare Component")
    private double localTaxableFareComponent;

    @ExcelColumn(required = false)
    @Column(name = "Local Non-Taxable Fare Component")
    private double localNonTaxableFareComponent;

    @ExcelColumn(required = false)
    @Column(name = "Local SSR Component")
    private double localSSRComponent;

    @ExcelColumn(required = false)
    @Column(name = "Local Taxable Component")
    private double localTaxableComponent;

    @ExcelColumn(required = false)
    @Column(name = "Local CGST Amount")
    private double localCGSTAmount;

    @ExcelColumn(required = false)
    @Column(name = "Local IGST Amount")
    private double localIGSTAmount;

    @ExcelColumn(required = false)
    @Column(name = "Local SGST Amount")
    private double localSGSTAmount;

    @ExcelColumn(required = false)
    @Column(name = "Local UGST Amount")
    private double localUGSTAmount;

    @ExcelColumn(required = false)
    @Column(name = "Local GST Amount")
    private double localGSTAmount;

    @ExcelColumn(required = false)
    @Column(name = "Local Cess Amount")
    private double localCessAmount;

    @ExcelColumn(required = false)
    @Column(name = "AirportCharges")
    private double airportCharges;

    @ExcelColumn(required = false)
    @Column(name = "LocalAirportCharges")
    private double localAirportCharges;

    @ExcelColumn
    @Column(name = "OriginCountry", length = 255)
    private String originCountry;

    @ExcelColumn(required = false)
    @JsonProperty("isExempted")
    @Column(name = "IsExempted")
    private boolean isExempted;

    @Column(name = "Agent Code")
    private String agentCode;

    @ExcelColumn(required = false)
    @Column(name = "NumberType", length = 3)
    public String numberType;

    @ExcelColumn(required = false)
    @Column(name = "Status", length = 50)
    public String status;

    @ExcelColumn(required = false)
    @Column(name = "CreatedBy", length = 50)
    public String createdBy = "System";

    @Column(name = "CreatedDate")
    public LocalDateTime createdDate = LocalDateTime.now();

    @ExcelColumn(required = false)
    @Column(name = "FileName", length = 100)
    public String fileName;

    @Column(name = "Path", length = 500)
    public String path;

}
