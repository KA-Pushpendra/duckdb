package in.indigo.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import in.indigo.Annotations.ExcelColumn;
import in.indigo.Annotations.ExcelToObj;
import jakarta.persistence.*;
import lombok.*;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;

@ExcelToObj
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name = "Invoice_DWH")
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@ToString
public class InvoiceDWH implements Serializable {

    @Id
    @Column(name = "Id")
    @ExcelColumn
    private String id;

    @ExcelColumn
    @Column(name = "TransactionDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/d/yyyy", timezone = "Asia/Kolkata")
    private Date transactionDate;

    @ExcelColumn(required = false)
    @Column(name = "FileDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/d/yyyy", timezone = "Asia/Kolkata")
    private Date fileDate;

    @ExcelColumn(required = false)
    @Column(name = "DisplayDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/d/yyyy", timezone = "Asia/Kolkata")
    private Date displayDate;

    @Column(name = "FlightNumber")
    @ExcelColumn(required = false)
    private int flightNumber;

    @ExcelColumn(required = false)
    @Column(name = "GoodsServicesType")
    private String goodsServicesType;

    @ExcelColumn(required = false)
    @Column(name = "SAC")
    private int sac;

    @ExcelColumn(required = false)
    @Column(name = "InvoiceNumber")
    private String invoiceNumber;

    @ExcelColumn(required = false)
    @Column(name = "SequenceNo")
    private int sequenceNo;

    @ExcelColumn
    @Column(name = "PNR")
    private String pnr;

    @ExcelColumn(required = false)
    @Column(name = "Dep")
    private String dep;

    @ExcelColumn(required = false)
    @Column(name = "Arr")
    private String arr;

    @ExcelColumn(required = false)
    @Column(name = "PlaceOfEmbarkation")
    private String placeOfEmbarkation;

    @ExcelColumn(required = false)
    @Column(name = "StateCode")
    private String stateCode;

    @ExcelColumn(required = false)
    @Column(name = "CustomerGSTIN")
    private String customerGSTIN;

    @ExcelColumn(required = false)
    @Column(name = "CustomerName")
    private String customerName;

    @ExcelColumn(required = false)
    @Column(name = "EmailAddress")
    private String emailAddress;

    @ExcelColumn(required = false)
    @Column(name = "CustomerGSTRegistrationState")
    private String customerGSTRegistrationState;

    @ExcelColumn(required = false)
    @Column(name = "PassengerName")
    private String passengerName;

    @ExcelColumn(required = false)
    @Column(name = "PassengerEmail")
    private String passengerEmail;

    @ExcelColumn(required = false)
    @Column(name = "6EGSTIN")
    private String e6gstin;

    @ExcelColumn(required = false)
    @Column(name = "6ERegisteredAddress")
    private String e6RegisteredAddress;

    @ExcelColumn(required = false)
    @Column(name = "NonTaxableFareComponent")
    private double nonTaxableFareComponent;

    @ExcelColumn(required = false)
    @Column(name = "TaxableComponent")
    private double taxableComponent;

    @ExcelColumn(required = false)
    @Column(name = "CGSTAmount")
    private double cgstAmount;

    @ExcelColumn(required = false)
    @Column(name = "IGSTAmount")
    private double igstAmount;

    @ExcelColumn(required = false)
    @Column(name = "SGSTAmount")
    private double sgstAmount;

    @ExcelColumn(required = false)
    @Column(name = "UGSTAmount")
    private double ugstAmount;

    @ExcelColumn(required = false)
    @Column(name = "CGSTRate")
    private double cgstRate;

    @ExcelColumn(required = false)
    @Column(name = "IGSTRate")
    private double igstRate;

    @ExcelColumn(required = false)
    @Column(name = "SGSTUGSTRate")
    private double sgstugstRate;

    @ExcelColumn(required = false)
    @Column(name = "IsProcessed")
    private String isProcessed;

    @ExcelColumn(required = false)
    @Column(name = "InvOrder")
    private short invOrder;

    @ExcelColumn(required = false)
    @Column(name = "IsCredit")
    private short isCredit;

    @ExcelColumn(required = false)
    @Column(name = "ServiceNo")
    private short serviceNo;

    @ExcelColumn(required = false)
    @Column(name = "Mailsend")
    private int mailSend;

    @ExcelColumn(required = false)
    @Column(name = "AirportCharges")
    private double airportCharges;

    @ExcelColumn(required = false)
    @Column(name = "OriginCountry")
    private String originCountry;

    @ExcelColumn(required = false)
    @Column(name = "IsExempted")
    private boolean isExempted;

    @ExcelColumn(required = false)
    @Column(name = "Cess Amount")
    private double cessAmount;

    @ExcelColumn(required = false)
    @Column(name = "Local Cess Amount")
    private double localCessAmount;

    @ExcelColumn(required = false)
    @Column(name = "IsError")
    private int isError;

    @ExcelColumn(required = false)
    @Column(name = "IsCorrect")
    private int IsCorrect;

    @Column(name = "CreatedBy")
    public String createdBy;

    @Column(name = "CreatedOn")
    public LocalDateTime createdOn;

    @ExcelColumn(required = false)
    @Column(name = "errorIds")
    private String errorIds;

    @Column(name = "ErrorDescription")
    private String errorDescription;

    @Column(name = "ReasonIDs")
    private String reasonIds;

    @Column(name = "AutoCorrectionId")
    private String autoCorrectionIds;

    @Column(name = "IsAutoCorrected")
    private String isAutoCorrected;

    @ExcelColumn(required = false)
    @Column(name = "spExemptedFlight")
    private int spExemptedFlight;

    @ExcelColumn(required = false)
    @Column(name = "spInternational")
    private int spInternational;

    @ExcelColumn(required = false)
    @Column(name = "spSez")
    private int spSez;

    @ExcelColumn(required = false)
    @Column(name = "isSapBiError")
    private String isSapBiError;

    @ExcelColumn(required = false)
    @Column(name = "sapBiErrorIds")
    private String sapBiErrorIds;

    @ExcelColumn(required = false)
    @Column(name = "sapBiDescription")
    private String sapBiDescription;

    @Column(name = "Agent Code")
    private String agentCode;

}
