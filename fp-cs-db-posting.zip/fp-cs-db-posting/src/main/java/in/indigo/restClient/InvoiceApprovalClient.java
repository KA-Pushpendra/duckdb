// package in.indigo.restClient;

// import jakarta.ws.rs.GET;
// import jakarta.ws.rs.Path;
// import jakarta.ws.rs.QueryParam;
// import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

// @RegisterRestClient(configKey = "inv-orchestration")
// public interface InvoiceApprovalClient {

//     // @Path("api/v1/cs/run")
//     // @GET
//     // public String invoiceRun(@QueryParam("date") String date, @QueryParam("user") String user);

  
//     // @Path("api/v1/cs/mark-complete")
//     // @GET
//     // public String markComplete(@QueryParam("date") String date, @QueryParam("user") String user);
// }
