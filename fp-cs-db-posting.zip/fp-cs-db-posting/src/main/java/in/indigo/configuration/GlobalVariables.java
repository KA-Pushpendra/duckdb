package in.indigo.configuration;

public class GlobalVariables {

    public static String appState = "INACTIVE";

    public static String requestType = "NONE";

    private GlobalVariables() {
        throw new IllegalStateException("Utility class");
    }

    public static void setAppState(String state) {
        appState = state;
    }

    public static String getAppState() {
        return appState;
    }

    public static String getRequestType() {
        return requestType;
    }

    public static void setRequestType(String state) {
        requestType = state;
    }
}
