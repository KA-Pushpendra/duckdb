package in.indigo.configuration;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.eclipse.microprofile.config.inject.ConfigProperty;

import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class DbConnecton {

    @ConfigProperty(name = "DUCKDB_JDBC_URL")
    private String jdbduckcurl;

    @ConfigProperty(name = "MSQL_JDBC_URL")
    private String jdbcmssqlurl;

    // Method to return MSSQL connection
    public Connection getMssqlConnection() throws SQLException {
        Connection con = DriverManager.getConnection(jdbcmssqlurl);
        con.setNetworkTimeout(null, 10 * 60 * 1000);
        return con;

    }

    // Method to return DuckDB connection
    public Connection getDuckDbConnection() throws SQLException {
        Connection con = DriverManager.getConnection(jdbduckcurl);
        return con;

    }
}
