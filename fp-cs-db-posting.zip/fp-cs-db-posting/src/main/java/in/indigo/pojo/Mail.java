// package in.indigo.pojo;


// import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
// import lombok.AllArgsConstructor;
// import lombok.Builder;
// import lombok.Getter;
// import lombok.NoArgsConstructor;
// import lombok.Setter;

// import java.util.List;



// @Builder
// @Getter
// @Setter
// @JsonIgnoreProperties(ignoreUnknown = true)
// @NoArgsConstructor
// @AllArgsConstructor
// public class Mail {

//     private String flightNo;
//     private String from;
//     private String to;
//     private String pnr;
//     private String placeofsupply;
//     private String customergstin;
//     private String customername;
//     private String customeremail;
//     private String invoicenumber;
//     private String invoicedate;
//     private String paxname;
//     private String registeredaddress;
//     private String registeredgstin;
//     private String gttaxablevalue;
//     private String gtnontaxablevalue;
//     private String gttotal;
//     private String gtigst;
//     private String gtcgst;
//     private String gtsugst;
//     private String gtcess;
//     private String gttotaltax;
//     private String invoicetype;
//     private List<Item> items;



// }
