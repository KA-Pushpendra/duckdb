// package in.indigo.pojo;


// import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

// import lombok.AllArgsConstructor;
// import lombok.Builder;
// import lombok.Getter;
// import lombok.NoArgsConstructor;
// import lombok.Setter;


// @Builder
// @Getter
// @Setter
// @JsonIgnoreProperties(ignoreUnknown = true)
// @AllArgsConstructor
// @NoArgsConstructor
// public class Item {

//     private String item;
//     private String saccode;
//     private String taxablevalue;
//     private String nontaxablevalue;
//     private String total;
//     private String igstperct;
//     private String igstamnt;
//     private String cgstperct;
//     private String cgstamnt;
//     private String sugstperct;
//     private String sugstamnt;
//     private String totaltax;
//     private String cessamnt;
//     private String cessperct;


// }
