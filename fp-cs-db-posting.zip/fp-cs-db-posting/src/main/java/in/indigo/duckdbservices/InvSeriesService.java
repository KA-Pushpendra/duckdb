package in.indigo.duckdbservices;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

import in.indigo.duckdbEntity.InvSeries;
import io.quarkus.hibernate.orm.panache.PanacheRepository;

@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class InvSeriesService implements PanacheRepository<InvSeries> {

    @PersistenceContext(unitName = "duckdb")
    @Inject
    EntityManager entityManager;

    @Transactional
    public List<InvSeries> getInvSeriesList(int financialYear) {
        try {
            // Perform the query
            return find("active = 1 AND financialYear = ?1 AND invoiceType in ('I','C')", financialYear).list();
        } catch (Exception e) {
            // Log the exception and rethrow it
            log.error("Error while fetching InvSeries for financialYear: " + financialYear, e);
            throw new RuntimeException("Failed to fetch InvSeries for financialYear: " + financialYear, e);
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional
    public List<Object[]> getStateSeriesList() {
        try {
            return entityManager.createNativeQuery(
                    "SELECT Month || StateCode || CAST(FinancialYear AS VARCHAR) AS stateSeries, InvoiceType " +
                            "FROM Inv_Series_CS WHERE InvoiceType in ('I','C')")
                    .getResultList();
        } catch (Exception e) {
            log.error("Error while fetching state series list", e);
            // Rethrow the exception to propagate it to the caller
            throw new RuntimeException("Failed to fetch state series list", e);
        }
    }

    @Transactional
    public int getMaxId() {
        Integer maxId = null;
        try {
            Object result = getEntityManager()
                    .createQuery("SELECT MAX(id) FROM InvSeries")
                    .getSingleResult();

            // Safely handle the result type
            if (result != null) {
                if (result instanceof Integer) {
                    maxId = (Integer) result; // Cast result to Integer
                } else if (result instanceof Long) {
                    maxId = ((Long) result).intValue(); // Convert Long to Integer
                }
            }

        } catch (Exception e) {
            // Log the exception and throw a runtime exception
            log.error("Error while fetching max id", e);
            throw new RuntimeException("Failed to fetch max id from InvSeries", e);
        }

        // Return maxId + 1 if a value exists, otherwise return 1
        return (maxId != null) ? maxId + 1 : 1;
    }

    @Transactional
    public void insertInvoiceSeries(InvSeries invSeries) {
        try {
            log.info("Attempting to insert series");

            // Fetch the next available ID
            int abc = (int) getMaxId();
            log.info("Generated new ID for insertion: {}", abc);

            // Set the ID and persist the entity
            invSeries.setId(abc);
            invSeries.setIsNew(true);
            invSeries.persist();

            log.info("Successfully inserted series with ID: {}", abc);
        } catch (Exception e) {
            log.error("Error while inserting series: {}", invSeries, e);
            throw new RuntimeException("Failed to insert series", e);
        }
    }

    @Transactional
    public void updateInvoiceSeries(InvSeries invSeries) {
        try {
            // Perform the update
            update(
                    "currentValue = ?1, active = ?2, invoiceType = ?3 WHERE month = ?4 AND stateCode = ?5 AND financialYear = ?6 AND invoiceType = ?7",
                    invSeries.getCurrentValue(),
                    invSeries.getActive(),
                    invSeries.getInvoiceType(),
                    invSeries.getMonth(),
                    invSeries.getStateCode(),
                    invSeries.getFinancialYear(),
                    invSeries.getInvoiceType());
            

            // Log the outcome

        } catch (Exception e) {
            // Handle and log the exception
            log.error("Error updating invoice series for series: {}, stateCode: {}, financialYear: {}",
                    invSeries.getMonth(), invSeries.getStateCode(), invSeries.getFinancialYear(), e);
            throw new RuntimeException("Failed to update invoice series", e);
        }
    }

}
