package in.indigo.duckdbservices;

import in.indigo.duckRepository.InvSkyExtractDuckDBRepository;
import in.indigo.duckdbEntity.InvSkyExtract;
import in.indigo.pojo.GetDataRequest;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.eclipse.microprofile.config.inject.ConfigProperty;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
public class InvSkyExtractService {
    private final InvSkyExtractDuckDBRepository invSkyExtractDuckDBRepository;

    @ConfigProperty(name = "CHUNK_SIZE")
    private int chunkSize;

    ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());

    public List<List<InvSkyExtract>> getDataByDateAndPnr(GetDataRequest getDataRequest) {
        // String date = getDataRequest.getDate();

        List<String> pnrchunk = getDataRequest.getPnrChunk();
        int batchSize = 2000;
        List<InvSkyExtract> list = new ArrayList<>();
        for (int i = 0; i < pnrchunk.size(); i += 2000) {
            List<String> batch = pnrchunk.subList(i, Math.min(i + batchSize, pnrchunk.size()));
            list.addAll(invSkyExtractDuckDBRepository.getDataByDateAndPnr(batch));
        }

        // List<in.indigo.mssqlEntity.InvSkyExtract> invSkyExtracts =
        // objectMapper.convertValue(list,
        // new TypeReference<List<in.indigo.mssqlEntity.InvSkyExtract>>() {
        // });

        List<List<InvSkyExtract>> dataList = list.stream()
                .collect(Collectors.groupingBy(InvSkyExtract::getPnr))
                .values().stream().collect(Collectors.toList());

        return dataList;
    }

    public List<List<String>> getDistinctPNRByDate() {
      
        List<String> myList = invSkyExtractDuckDBRepository.getDistinctPNRByDate();
        log.info("numberOfPnr-->{}", myList.size());
        List<List<String>> chunkedList = chunkList(myList, chunkSize);
        return chunkedList;
    }

    public static <T> List<List<T>> chunkList(List<T> list, int chunkSize) {
        return IntStream.range(0, (list.size() + chunkSize - 1) / chunkSize)
                .mapToObj(i -> list.subList(i * chunkSize, Math.min((i + 1) * chunkSize, list.size())))
                .collect(Collectors.toList());
    }
}
