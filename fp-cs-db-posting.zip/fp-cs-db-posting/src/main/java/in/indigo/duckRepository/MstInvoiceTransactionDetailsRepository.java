// package in.indigo.duckRepository;

// import io.quarkus.hibernate.orm.panache.PanacheRepository;
// import jakarta.enterprise.context.ApplicationScoped;
// import jakarta.transaction.Transactional;

// import java.time.LocalDate;
// import java.util.List;

// import in.indigo.mssqlEntity.MstInvoiceTransactionDetails;

// @ApplicationScoped
// public class MstInvoiceTransactionDetailsRepository implements PanacheRepository<MstInvoiceTransactionDetails> {

//     public List<MstInvoiceTransactionDetails> listAllDetails() {
//         return listAll();
//     }

//     @Transactional
//     public List<MstInvoiceTransactionDetails> findByTransactionDate(LocalDate transactionDate) {
//         return list("transactionDate", transactionDate);
//     }

//     public List<MstInvoiceTransactionDetails> findByStatusAndDateRange(String status, LocalDate startDate,
//             LocalDate endDate) {
//         if ("All".equalsIgnoreCase(status)) {
//             return find("transactionDate between ?1 and ?2", startDate, endDate).list();
//         } else {
//             return find("invoiceStatus = ?1 and transactionDate between ?2 and ?3", status, startDate, endDate).list();
//         }
//     }

// }
