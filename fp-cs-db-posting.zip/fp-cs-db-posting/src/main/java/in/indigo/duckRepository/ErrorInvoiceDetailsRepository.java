package in.indigo.duckRepository;

import in.indigo.duckdbEntity.ErrorInvoiceDetails;
import io.quarkus.hibernate.orm.panache.PanacheRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.context.Dependent;

@ApplicationScoped
public class ErrorInvoiceDetailsRepository implements PanacheRepository<ErrorInvoiceDetails> {

 
}
