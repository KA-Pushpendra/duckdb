package in.indigo.duckRepository;

import in.indigo.duckdbEntity.ErrorPNRRecord;
import io.quarkus.hibernate.orm.panache.PanacheRepository;
import jakarta.enterprise.context.ApplicationScoped;


@ApplicationScoped
public class ErrorPNRRecordRepository implements PanacheRepository<ErrorPNRRecord> {

  
}
