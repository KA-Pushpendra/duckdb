package in.indigo.duckRepository;

import io.quarkus.hibernate.orm.panache.PanacheRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.context.Dependent;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

import in.indigo.duckdbEntity.InvSkyExtract;

@Slf4j
@ApplicationScoped
public class InvSkyExtractDuckDBRepository implements PanacheRepository<InvSkyExtract> {


    @Transactional
    public List<InvSkyExtract> getDataByDateAndPnr(List<String> pnr) {
        return list("from InvSkyExtract where  pnr in (?1)", pnr);
    }

    @Transactional
    public List<String> getDistinctPNRByDate() {
        return find("SELECT DISTINCT inv.pnr FROM InvSkyExtract inv")
                .project(String.class).list();
    }

    @Transactional
    public long getNumberOfRecord(String date) {

        return count("transactionDate = ?1", date);
    }

}
