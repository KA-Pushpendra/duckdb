package in.indigo.duckRepository;

import io.quarkus.hibernate.orm.panache.PanacheRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;

import java.util.Date;
import java.util.List;

import in.indigo.duckdbEntity.InvoiceDWH;

@Slf4j
@ApplicationScoped
public class InvoiceDwhRepository implements PanacheRepository<InvoiceDWH> {
        @Inject
        @PersistenceContext(unitName = "duckdb")
        EntityManager entityManager;

        @Transactional
        public void updateServerNo(String query) {

                log.info("update query----------->" + query);

                entityManager
                                .createNativeQuery(query)
                                .executeUpdate();

        }

        @SuppressWarnings("unchecked")
        @Transactional
        public List<Object[]> getDataForCreditNoteByPnrAndStateCodeB2C(String pnr, String stateCode,
                        java.util.Date transactionDate) {
                return entityManager
                                .createNativeQuery(
                                                "SELECT InvoiceNumber, TransactionDate FROM Invoice_DWH_CS " +
                                                                "WHERE PNR = ? AND StateCode = ? AND COALESCE(InvoiceNumber, '') <> '' "
                                                                +
                                                                "AND TransactionDate = ? AND IsCredit = 1 " +
                                                                "GROUP BY InvoiceNumber, PNR, StateCode, TransactionDate, CustomerGSTIN")
                                .setParameter(1, pnr)
                                .setParameter(2, stateCode)
                                .setParameter(3, transactionDate)
                                .getResultList();
        }

        @SuppressWarnings("unchecked")
        @Transactional
        public List<Object[]> getDataForCreditNoteByStateCodeB2C(String stateCode, Date transactionDate) {
                return entityManager
                                .createNativeQuery(
                                                "SELECT InvoiceNumber, TransactionDate " +
                                                                "FROM Invoice_DWH_CS " +
                                                                "WHERE StateCode = ? AND COALESCE(InvoiceNumber, '') <> '' "
                                                                +
                                                                "AND TransactionDate = ? AND IsCredit = 1 " +
                                                                "GROUP BY InvoiceNumber, PNR, StateCode, TransactionDate, CustomerGSTIN")
                                .setParameter(1, stateCode)
                                .setParameter(2, transactionDate)
                                .getResultList();
        }

        @SuppressWarnings("unchecked")
        @Transactional
        public List<Object[]> getDataForCreditNoteByPnrStateCodeAndGstB2B(String pnr, String stateCode,
                        String customerGSTIN, java.util.Date transactionDate) {
                return entityManager
                                .createNativeQuery(
                                                "SELECT InvoiceNumber, TransactionDate " +
                                                                "FROM Invoice_DWH_CS " +
                                                                "WHERE PNR = ? AND CustomerGSTIN = ? AND StateCode = ? "
                                                                +
                                                                "AND COALESCE(InvoiceNumber, '') <> '' " +
                                                                "AND TransactionDate = ? AND IsCredit = 1 " +
                                                                "GROUP BY InvoiceNumber, PNR, StateCode, TransactionDate, CustomerGSTIN")
                                .setParameter(1, pnr)
                                .setParameter(2, customerGSTIN)
                                .setParameter(3, stateCode)
                                .setParameter(4, transactionDate)
                                .getResultList();
        }

        @SuppressWarnings("unchecked")
        @Transactional
        public List<Object[]> getDataForCreditNoteByStateCodeAndGstB2B(String stateCode, String customerGSTIN,
                        java.util.Date transactionDate) {
                return entityManager
                                .createNativeQuery(
                                                "SELECT InvoiceNumber, TransactionDate " +
                                                                "FROM Invoice_DWH_CS " +
                                                                "WHERE CustomerGSTIN = ? AND StateCode = ? " +
                                                                "AND COALESCE(InvoiceNumber, '') <> '' " +
                                                                "AND TransactionDate = ? AND IsCredit = 1 " +
                                                                "GROUP BY InvoiceNumber, PNR, StateCode, TransactionDate, CustomerGSTIN")
                                .setParameter(1, customerGSTIN)
                                .setParameter(2, stateCode)
                                .setParameter(3, transactionDate)
                                .getResultList();
        }

        @SuppressWarnings("unchecked")
        @Transactional
        public List<Object[]> getAllDataForCreditNoteByStateCodeAndGstB2B(String stateCode, String customerGSTIN,
                        java.util.Date transactionDate) {
                return entityManager
                                .createNativeQuery(
                                                "SELECT InvoiceNumber, TransactionDate " +
                                                                "FROM Invoice_DWH_CS " +
                                                                "WHERE CustomerGSTIN = ? AND StateCode = ? " +
                                                                "AND COALESCE(InvoiceNumber, '') <> '' " +
                                                                "AND TransactionDate = ? AND IsCredit = 1 " +
                                                                "GROUP BY InvoiceNumber, PNR, StateCode, TransactionDate, CustomerGSTIN")
                                .setParameter(1, customerGSTIN)
                                .setParameter(2, stateCode)
                                .setParameter(3, transactionDate)
                                .getResultList();
        }

}
