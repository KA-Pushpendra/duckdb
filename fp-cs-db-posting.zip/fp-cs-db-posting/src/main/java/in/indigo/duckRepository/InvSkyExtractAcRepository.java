package in.indigo.duckRepository;

import io.quarkus.hibernate.orm.panache.PanacheRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.context.Dependent;
import in.indigo.duckdbEntity.InvSkyExtractAc;

@ApplicationScoped
public class InvSkyExtractAcRepository implements PanacheRepository<InvSkyExtractAc> {

}
