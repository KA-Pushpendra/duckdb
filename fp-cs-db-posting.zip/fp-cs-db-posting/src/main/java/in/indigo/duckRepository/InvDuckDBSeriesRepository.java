package in.indigo.duckRepository;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.context.Dependent;
import in.indigo.duckdbEntity.InvSeries;
import io.quarkus.hibernate.orm.panache.PanacheRepository;

@ApplicationScoped
public class InvDuckDBSeriesRepository implements PanacheRepository<InvSeries> {

}
