package in.indigo.mssqlRepository;

import in.indigo.mssqlEntity.FileStatus;
import io.quarkus.hibernate.orm.panache.PanacheRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;

@ApplicationScoped
@Slf4j
public class FileStatusRepository implements PanacheRepository<FileStatus> {

    @Transactional
    public void trackFile(String reason, String requestId, String status) {

        FileStatus existingRecord = find("requestId", requestId).firstResult();

        if (existingRecord != null) {
            update("status =?1, reason=?2 where requestId = ?3",
                    status, reason, requestId);
        } else {
            log.error("File status not found for request id: " + requestId);
        }
    }
}