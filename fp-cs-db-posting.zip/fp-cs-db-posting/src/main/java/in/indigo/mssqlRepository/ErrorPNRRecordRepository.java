package in.indigo.mssqlRepository;

import java.util.List;

import in.indigo.mssqlEntity.ErrorPNRRecord;
import io.quarkus.hibernate.orm.panache.PanacheRepository;
import io.quarkus.logging.Log;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;

@ApplicationScoped
@Slf4j
public class ErrorPNRRecordRepository implements PanacheRepository<ErrorPNRRecord> {

    // @Transactional
    // public void deleteError(List<String> ids) {
    //     for (String str : ids) {
    //         log.info("--------------------->{}",str);
    //         delete("FROM ErrorPNRRecord WHERE id = ?1", str);
    //     }
    // }

    // @Transactional
    // public void updateError(List<ErrorPNRRecord> datas) {

    //     persist(datas);
    // }
}
