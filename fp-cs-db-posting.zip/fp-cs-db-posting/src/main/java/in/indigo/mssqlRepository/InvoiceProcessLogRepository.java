package in.indigo.mssqlRepository;

import io.quarkus.hibernate.orm.panache.PanacheRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.transaction.Transactional;

import java.sql.Date;
import java.util.List;

import in.indigo.mssqlEntity.InvoiceProcessLog;

@ApplicationScoped
public class InvoiceProcessLogRepository implements PanacheRepository<InvoiceProcessLog> {

    @Transactional
    public List<InvoiceProcessLog> getInvoiceStatusByDateRange(Date startDate, Date endDate, String status) {
        return list("transactionDate between ?1 and ?2 and processStatus = ?3", startDate, endDate, status);
    }

}