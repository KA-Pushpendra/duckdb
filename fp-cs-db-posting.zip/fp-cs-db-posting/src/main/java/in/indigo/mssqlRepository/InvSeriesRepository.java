package in.indigo.mssqlRepository;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.transaction.Transactional;

import in.indigo.mssqlEntity.InvSeries;
import io.quarkus.hibernate.orm.panache.PanacheRepository;

@ApplicationScoped
public class InvSeriesRepository implements PanacheRepository<InvSeries> {

    public InvSeries findRecord(int id) {
        return find("id =?1",(long)id).firstResult();
    }
}
