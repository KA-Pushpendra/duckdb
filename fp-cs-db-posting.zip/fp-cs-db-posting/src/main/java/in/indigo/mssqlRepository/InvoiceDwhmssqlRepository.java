package in.indigo.mssqlRepository;

import java.util.Date;
import java.util.List;

import org.eclipse.microprofile.config.inject.ConfigProperty;

import in.indigo.mssqlEntity.InvoiceDWH;
import io.quarkus.hibernate.orm.panache.PanacheRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ApplicationScoped
public class InvoiceDwhmssqlRepository implements PanacheRepository<InvoiceDWH> {
        @Inject
        @PersistenceContext(unitName = "mssql")
        EntityManager entityManager;
        @ConfigProperty(name = "ERROR1_BACK_MONTH")
        private int error1BackMonth;

        @Transactional
        public void updateServerNo(String query) {

                log.info("update query----------->" + query);

                entityManager
                                .createNativeQuery(query)
                                .executeUpdate();

        }

        @Transactional
        public boolean updateRecord(String invoiceNumber, Date transactionDate) {
            int updatedRows = entityManager.createNativeQuery(
                    "UPDATE Invoice_DWH_CS SET Mailsend = 1 WHERE InvoiceNumber = :inv AND TransactionDate = :tran AND StateCode != 'ZZ'")
                    .setParameter("inv", invoiceNumber) // Bind InvoiceNumber
                    .setParameter("tran", transactionDate) // Bind TransactionDate
                    .executeUpdate(); // Returns affected row count
        
            if (updatedRows > 0) {
                System.out.println("Record updated successfully!");
                return true;
            } else {
                System.out.println("No record updated, check input values.");
                return false;
            }
        }
        @SuppressWarnings("unchecked")
        @Transactional
        public List<Object[]> getDataForCreditNoteByPnrAndStateCodeB2C(String pnr, String stateCode,
                        Date transactionDate) {
                return entityManager
                                .createNativeQuery(
                                                "SELECT InvoiceNumber,TransactionDate FROM Invoice_DWH_CS WHERE PNR = ?1 AND StateCode = ?2 and isnull(InvoiceNumber,'') <> '' and TransactionDate >= DATEADD(month, ?4, ?3) AND TransactionDate <= ?3 AND IsCredit=1 \n"
                                                                +
                                                                "GROUP BY Invoicenumber,PNR,StateCode,TransactionDate,CustomerGSTIN;")
                                .setParameter(1, pnr)
                                .setParameter(2, stateCode)
                                .setParameter(3, transactionDate)
                                .setParameter(4, error1BackMonth * -1)
                                .getResultList();
        }

        @SuppressWarnings("unchecked")
        @Transactional
        public List<Object[]> getDataForCreditNoteByStateCodeB2C(String stateCode, Date transactionDate) {
                return entityManager
                                .createNativeQuery(
                                                "SELECT InvoiceNumber,TransactionDate FROM Invoice_DWH_CS WHERE StateCode = ?1 and isnull(InvoiceNumber,'') <> '' and TransactionDate >= DATEADD(month, -2, ?2) AND TransactionDate <= ?2 AND IsCredit=1 \n"
                                                                +
                                                                "GROUP BY Invoicenumber,PNR,StateCode,TransactionDate,CustomerGSTIN;")
                                .setParameter(1, stateCode)
                                .setParameter(2, transactionDate)
                                .getResultList();
        }

        @SuppressWarnings("unchecked")
        @Transactional
        public List<Object[]> getDataForCreditNoteByPnrStateCodeAndGstB2B(String pnr, String stateCode,
                        String customerGSTIN, Date transactionDate) {
                return entityManager
                                .createNativeQuery(
                                                "SELECT InvoiceNumber,TransactionDate FROM Invoice_DWH_CS WHERE PNR = ?1 AND CustomerGSTIN = ?2 and StateCode = ?3 and isnull(InvoiceNumber,'') <> '' and TransactionDate >= DATEADD(month, -2, ?4) AND TransactionDate <= ?4 AND IsCredit=1 \n"
                                                                +
                                                                "GROUP BY Invoicenumber,PNR,StateCode,TransactionDate,CustomerGSTIN;")
                                .setParameter(1, pnr)
                                .setParameter(2, customerGSTIN)
                                .setParameter(3, stateCode)
                                .setParameter(4, transactionDate)
                                .getResultList();
        }

        @SuppressWarnings("unchecked")
        @Transactional
        public List<Object[]> getDataForCreditNoteByStateCodeAndGstB2B(String stateCode, String customerGSTIN,
                        Date transactionDate) {
                return entityManager
                                .createNativeQuery(
                                                "SELECT InvoiceNumber,TransactionDate FROM Invoice_DWH_CS WHERE CustomerGSTIN = ?1 and StateCode = ?2 and isnull(InvoiceNumber,'') <> '' and TransactionDate >= DATEADD(month, -2, ?3) AND TransactionDate <= ?3 AND IsCredit=1 \n"
                                                                +
                                                                "GROUP BY Invoicenumber,PNR,StateCode,TransactionDate,CustomerGSTIN;")
                                .setParameter(1, customerGSTIN)
                                .setParameter(2, stateCode)
                                .setParameter(3, transactionDate)
                                .getResultList();
        }

        @SuppressWarnings("unchecked")
        @Transactional
        public List<Object[]> getAllDataForCreditNoteByStateCodeAndGstB2B(String stateCode, String customerGSTIN,
                        Date transactionDate) {
                return entityManager
                                .createNativeQuery(
                                                "SELECT InvoiceNumber,TransactionDate FROM Invoice_DWH_CS WHERE CustomerGSTIN = ?1 and StateCode = ?2 and isnull(InvoiceNumber,'') <> '' and TransactionDate <= ?3 and IsCredit=1 \n"
                                                                +
                                                                "GROUP BY Invoicenumber,PNR,StateCode,TransactionDate,CustomerGSTIN;")
                                .setParameter(1, customerGSTIN)
                                .setParameter(2, stateCode)
                                .setParameter(3, transactionDate)
                                .getResultList();
        }

}
