package in.indigo.mssqlRepository;

import java.util.concurrent.CompletableFuture;

import in.indigo.mssqlEntity.ProgressTracker;
import io.quarkus.hibernate.orm.panache.PanacheRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.context.control.ActivateRequestContext;
import jakarta.transaction.Transactional;

@ApplicationScoped
public class ProgressTrackerRepository implements PanacheRepository<ProgressTracker> {

    @ActivateRequestContext
    public void updateTrackerAsync(String stringHash, double percentage) {
        CompletableFuture.runAsync(() -> {
            updateTracker(stringHash, percentage);
        });
    }

    @Transactional
    public void updateTracker(String stringHash, double percentage) {
        update("progressPercentage = ?1 WHERE requestId = ?2 ",
               (int) Math.ceil(percentage) > 100 ? 100 : (int) Math.ceil(percentage),
               stringHash);
    }

   @ActivateRequestContext
    public void createAsync(ProgressTracker pt) {
        CompletableFuture.runAsync(() -> {
            create(pt);
        });
    }

    @Transactional
    public void create(ProgressTracker pt) {
        persist(pt);
    }

}
