package in.indigo.mssqlRepository;

import io.quarkus.hibernate.orm.panache.PanacheRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.transaction.Transactional;

import java.time.LocalDate;
import java.util.List;

import in.indigo.mssqlEntity.MstInvoiceTransactionDetails;

@ApplicationScoped
public class MstInvoiceTransactionDetailsRepository implements PanacheRepository<MstInvoiceTransactionDetails> {

    @Transactional
    public List<MstInvoiceTransactionDetails> findByDateRange(LocalDate startDate, LocalDate endDate) {
        return find("transactionDate between ?1 and ?2", startDate, endDate).list();
    }

}
