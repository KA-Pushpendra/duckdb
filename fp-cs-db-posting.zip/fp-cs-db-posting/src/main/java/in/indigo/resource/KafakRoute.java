package in.indigo.resource;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.model.rest.RestBindingMode;

import in.indigo.configuration.Constants;
import in.indigo.configuration.DbConnecton;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@ApplicationScoped
@Slf4j
public class KafakRoute extends RouteBuilder {

    private final DbConnecton dbConnecton;

    int BATCH_SIZE = 500;

    List<String> invoiceNumberList = new ArrayList<>();
    List<Date> transactionDateList = new ArrayList<>();

    @Override
    public void configure() throws Exception {
        onException(Exception.class)
                .log("=========================>${exception.message}")
                .setHeader("exception", simple("${exception.message}"))

                .handled(true)
                .stop();

        restConfiguration()
                .component("platform-http")

                .bindingMode(RestBindingMode.json);

        rest("api/v1/cs")
                .post("/kafkaMessage")
                .consumes("application/json")
                .to("direct:kafka-processing");

        from("direct:kafka-processing")
                .routeId("kafka-process-route")
                .split().body().streaming().parallelProcessing()
                .process(exchange -> {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> body = exchange.getIn().getBody(Map.class);

                    String transactionDate = exchange.getIn().getHeader(Constants.TRANSACTION_PROPERTY, String.class);
                    DateTimeFormatter inputFormat = DateTimeFormatter.ofPattern("MM/dd/yyyy");
                    DateTimeFormatter outputFormat = DateTimeFormatter.ofPattern("dd_MM_yyyy");

                    LocalDate date = LocalDate.parse(transactionDate, inputFormat);
                    String formattedDate = date.format(outputFormat);
                    exchange.getIn().setHeader("folderName", formattedDate);
                    exchange.getIn().setHeader("InvoiceNumber", body.get("invoicenumber").toString());
                })
                .marshal().json(JsonLibrary.Jackson) // Convert the body into JSON format
                .log("Starting Validation for the JSON message Received...")
                .to("json-validator:kafka.json")
                .toD("file:${header.folderName}?fileName=${header.InvoiceNumber}.json&charset=utf-8") // Write to JSON
                                                                                                      // file
                .setBody(simple("JSON file created and sent to Kafka"))
                .end();

        from("file://{{MAIL_SEND_FOLDER}}?delete=true")
                .id("MAIL_SEND_FOLDER")
                .convertBodyTo(String.class) // Ensure body is a JSON string before processing
                .log("Reading file: ${header.CamelFileName}")

                .unmarshal().json(JsonLibrary.Jackson)

                .process(exchange -> {
                    String fileName = exchange.getIn().getHeader("CamelFileName", String.class);

                    if (fileName != null && fileName.contains("~")) {
                        fileNameCheck(exchange, fileName);
                    } else {
                        System.err.println("Filename does not contain '~': " + fileName);
                    }
                })
                .marshal().json(JsonLibrary.Jackson)
                .log(LoggingLevel.INFO, "sending message to kafka.")
                .toD("kafka:{{KAFKA_TOPIC_NAME}}?brokers={{KAFKA_BOOTSTRAP_SERVER}}&lingerMs=5")
                .log("body after kafka send: ${body}")
                .process(exchange -> {
                    String invoiceNumber = exchange.getProperty("invoiceNumber", String.class);
                    Date transactionDate = exchange.getProperty(Constants.TRANSACTION_PROPERTY, Date.class);

                    boolean batchCompleted = exchange.getProperty("CamelBatchComplete", boolean.class);

                    transactionDateList.add(transactionDate);
                    invoiceNumberList.add(invoiceNumber);
                    if (invoiceNumberList.size() >= BATCH_SIZE && transactionDateList.size() >= BATCH_SIZE
                            || batchCompleted) {
                        updateDWHMailSend(invoiceNumberList, transactionDateList);
                        transactionDateList.clear();
                        invoiceNumberList.clear();
                    }

                });

    }

    public void updateDWHMailSend(List<String> invoiceNumbers, List<Date> transactionDates) throws Exception {

        String updateQuery = "UPDATE Invoice_DWH_CS SET Mailsend = 1 WHERE InvoiceNumber = ? AND TransactionDate = ? AND StateCode != 'ZZ'";

        try (Connection con = dbConnecton.getMssqlConnection();
                PreparedStatement updateStmt = con.prepareStatement(updateQuery);) {
            for (int i = 0; i < invoiceNumbers.size(); i++) {
                updateStmt.setString(1, invoiceNumbers.get(i));

                java.sql.Date sqlDate = new java.sql.Date(transactionDates.get(i).getTime());

                updateStmt.setDate(2, sqlDate);
                updateStmt.addBatch();
            }
            int[] update = updateStmt.executeBatch();
            log.info("record updated" + update.length);
            updateStmt.close();
            con.close();

        } catch (SQLException sqlEx) {

            log.error("SQL error occurred during mailSendUpdate update: {}", sqlEx.getMessage(), sqlEx);
            throw sqlEx; // Re-throw SQL exceptions

        } catch (Exception ex) {
            log.error("Unexpected error during mailSendUpdate update: {}", ex.getMessage(), ex);

        } finally {
            log.info("mailSendUpdate update process finished.");
        }
    }

    private void fileNameCheck(Exchange exchange, String fileName) {
        SimpleDateFormat formatter = new SimpleDateFormat("dd_MM_yyyy");

        String[] fileNameSplit = fileName.split("~");

        if (fileNameSplit.length > 1 && fileNameSplit[1].contains(".")) {
            try {
                Date transactionDate = formatter.parse(fileNameSplit[0]); // Convert String to Date
                exchange.setProperty(Constants.TRANSACTION_PROPERTY, transactionDate);
                System.out.println("Converted Date: " + transactionDate);
            } catch (ParseException e) {
                System.err.println("Error parsing date: " + e.getMessage());
            }
            String invoiceNumber = fileNameSplit[1].substring(0, fileNameSplit[1].lastIndexOf("."));
            exchange.setProperty("invoiceNumber", invoiceNumber);
            System.out.println("Extracted inputDate1: " + invoiceNumber);
        } else {
            System.err.println("Filename format is incorrect: " + fileName);
        }
    }

}
