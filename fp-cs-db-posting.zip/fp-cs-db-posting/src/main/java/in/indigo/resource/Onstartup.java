package in.indigo.resource;

import org.apache.camel.builder.RouteBuilder;

import in.indigo.utility.StateManagement;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;

@ApplicationScoped
@RequiredArgsConstructor
public class Onstartup extends RouteBuilder {

    private final StateManagement stateManagement;

    @Override
    public void configure() throws Exception {
        from("timer://startup?repeatCount=1")
                .routeId("startup-process")
                .process(exchange -> {
                    System.out.println("Executing process on application startup");
                    stateManagement.updateInvoiceStatusOnStartup(exchange);

                });
    }
}