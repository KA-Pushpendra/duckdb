package in.indigo.resource;

import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
// import java.util.concurrent.CompletableFuture;

import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
// import org.apache.camel.component.http.HttpMethods;
import org.apache.camel.model.rest.RestBindingMode;
import org.apache.camel.model.rest.RestParamType;
// import org.eclipse.microprofile.rest.client.inject.RestClient;
// import org.jboss.logging.MDC;
import org.apache.camel.component.http.HttpMethods;
import in.indigo.configuration.Constants;
import in.indigo.configuration.GlobalVariables;
// import in.indigo.restClient.InvoiceApprovalClient;
import in.indigo.utility.MssqlToDuckDBTransfer;
import in.indigo.utility.StateManagement;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@ApplicationScoped
@Slf4j
public class InvocePosting extends RouteBuilder {
    private final StateManagement stateManagement;
    private final MssqlToDuckDBTransfer mssqlToDuckDBTransfer;
    // @RestClient
    // InvoiceApprovalClient invoiceApprovalClient;

    @Override
    public void configure() throws Exception {

        onException(Exception.class)
                .log("=========================>${exception.message}")
                .setHeader("exception", simple("${exception.message}"))
                .process(exchange -> {
                    String exce = exchange.getIn().getHeader("exception").toString();
                    if (!exce.contains("Read timed out")) {
                        stateManagement.markErrorInInvoiceTransaction();
                        GlobalVariables.setRequestType("NONE");
                    } else {

                    }
                })
                .handled(true)
                .stop();

        restConfiguration()
                .component("platform-http")

                .bindingMode(RestBindingMode.json);

        rest("api/v1/cs")
                .get("/approval")
                .param().type(RestParamType.query).dataType(Constants.STRING).name("month").endParam()
                .param().type(RestParamType.query).dataType(Constants.STRING).name("user").endParam()
                .to("direct:start-processing");

        from("direct:start-processing")
                .routeId("start-processing-route")

                .log("Start processing")

                .setBody().constant(null)
                .process(exchange -> {
                    List<String> dateList = new ArrayList<>();
                    String monthYear = exchange.getIn().getHeader("month", String.class);
                    String[] parts = monthYear.split("/"); // Splitting month and year

                    int month = Integer.parseInt(parts[0]);
                    int year = Integer.parseInt(parts[1]);

                    YearMonth yearMonth = YearMonth.of(year, month);
                    LocalDate startDate = yearMonth.atDay(1);
                    LocalDate endDate = yearMonth.atEndOfMonth();

                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");

                    System.out.println("Start date: " + startDate.format(formatter));
                    System.out.println("End date: " + endDate.format(formatter));

                    dateList.add(startDate.format(formatter));
                    dateList.add(endDate.format(formatter));
                    exchange.getIn().setHeader("dateList", dateList);
                    String user = exchange.getIn().getHeader("user", String.class);
                    // String requestType = "INVOICE_APPROVAL";
                    if ("NONE".equals(GlobalVariables.requestType)) {
                        log.info("User: {}, Date: {}, Request Type: {}", user, monthYear, Constants.INVOICE_APPROVAL);

                        // String message = null;
                        // if (date == null || date.isEmpty()) {
                        // message = "Date is required!";

                        // } else if (user == null || user.isEmpty()) {
                        // message = "User is required!";
                        // }

                        // exchange.getIn().setBody(message);
                        GlobalVariables.setRequestType(Constants.INVOICE_APPROVAL);
                    } else {
                        log.info("Process Already Running for: " + GlobalVariables.requestType);
                        exchange.getIn().setBody("Process Already Running for: " + GlobalVariables.requestType);
                        exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, 200);
                        exchange.setRouteStop(true);
                        return;

                    }
                    log.info("Running request type: " + GlobalVariables.requestType);
                })
                .choice()
                .when(body().isNotNull())
                .log(LoggingLevel.ERROR, "Cannot process: ${body}")
                .stop()
                .endChoice()
                .otherwise()
                .setVariable("global:start", System::nanoTime)
                .setBody(constant(null))
                .setProperty("dateList", simple("${header.dateList}"))
                .setProperty("month", simple("${header.month}"))
                .setProperty("user", simple("${header.user}"))
                .setProperty("requestType", simple("${header.requestType}"))
                .bean(stateManagement, "initiateProcess")
                .choice()
                .when(body().isNotNull())
                .log(LoggingLevel.ERROR, "Cannot process: ${body}")
                .endChoice()
                .otherwise()

                .setBody(constant(null))
                .to("seda:db-processing?waitForTaskToComplete=Never")
                .endChoice()
                .end()
                .end()
                .process(exchange -> {
                    Object body = exchange.getIn().getBody();
                    if (body == null) {
                        exchange.getIn().setBody("Initiated");
                    }
                });

        from("seda:db-processing")
                .routeId("db-processing-route")
                .setBody(simple("${header.dateList}"))
                .log("-----------> Inside DB Processing")
                .process(mssqlToDuckDBTransfer)
                .removeHeaders("*")
                .setBody(constant(null))
                .setHeader(Exchange.HTTP_METHOD, constant(HttpMethods.GET))
                .toD("{{INVOICE_ORCHESTRATION}}/api/v1/cs/run?month=${exchangeProperty.month}&user=${exchangeProperty.user}")
                .log("Completed invoices")
                .end();
    }

}
