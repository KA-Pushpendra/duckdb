package in.indigo.resource;

import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;

import in.indigo.configuration.Constants;
import in.indigo.configuration.GlobalVariables;
import in.indigo.utility.StateManagement;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@ApplicationScoped
public class HelthCheckOrchestration extends RouteBuilder {
    private final StateManagement stateManagement;

    @Override
    public void configure() throws Exception {

   onException(Exception.class)
                .log(LoggingLevel.ERROR,"${exception.message}")
                 .process(exchange -> {
                    GlobalVariables.setAppState("INACTIVE");
                    if (!Constants.PRE_ERROR.equals(GlobalVariables.requestType)) {
                        stateManagement.markErrorInInvoiceTransaction();
                    }
                    GlobalVariables.setRequestType("NONE");
                    log.info(GlobalVariables.requestType);
                })
                .handled(true)
                .stop();


        from("timer:healthCheck?period=500") // Runs every 1 second (1000ms)
                .routeId("health-check-route")
                .to("http://{{INVOICE_ORCHESTRATION}}/q/health")
               
                .end();
    }
}