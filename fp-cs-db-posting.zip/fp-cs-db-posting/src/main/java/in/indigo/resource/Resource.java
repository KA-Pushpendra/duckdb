package in.indigo.resource;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import in.indigo.configuration.Constants;
import in.indigo.configuration.GlobalVariables;
import in.indigo.duckdbEntity.InvSeries;
import in.indigo.duckdbservices.InvSeriesService;
import in.indigo.duckdbservices.InvSkyExtractService;
import in.indigo.mssqlRepository.FileStatusRepository;
import in.indigo.pojo.CreditNoteRequest;
import in.indigo.pojo.GetDataRequest;
import in.indigo.pojo.Request;
import in.indigo.utility.CreditNote;
import in.indigo.utility.CustomObjectMapper;
import in.indigo.utility.DumpToDb;
import in.indigo.utility.PostInvoiceCompletion;
// import in.indigo.utility.PreErrorCompletion;
import in.indigo.utility.StateManagement;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Path("/api/v1/cs")
@Slf4j
@RequiredArgsConstructor
public class Resource {

    private final StateManagement stateManagement;

    private final FileStatusRepository fileStatusRepository;

    private final InvSkyExtractService invSkyExtractService;

    // private final MoveFilesAndDeleteFolder moveFilesAndDeleteFolder;

    private final PostInvoiceCompletion postInvoiceCompletion;

    private final InvSeriesService invSeriesService;

    private final CreditNote creditNote;

    private final ObjectMapper objectMapper = CustomObjectMapper.createObjectMapper();

    private final DumpToDb dumpToDb;

    private boolean isApplicationActive() {
        return "ACTIVE".equals(GlobalVariables.appState);
    }

    @POST
    @Path("/posting")
    @Produces(MediaType.TEXT_PLAIN)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response posting(Request request) throws JsonProcessingException {
        String body = null;
        try {
            body = objectMapper.writeValueAsString(request.getBody());
            if (isApplicationActive()) {
                dumpToDb.process(body, request.getEntityName());
                return Response.ok("Data processed successfully").build();
            } else {
                log.error("Application not active: EntityName:- {}, RequestBody:- {} ", request.getEntityName(), body);
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                        .entity(Constants.APPLICATION_NOT_ACTIVE)
                        .build();
            }
        } catch (Exception e) {
            log.error("Error during data insertion: EntityName:- {}, RequestBody:- {} ", request.getEntityName(), body);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Failed to process data")
                    .build();
        }
    }

    @POST
    @Path("/dataByDateAndPnr")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response getRecordPnrBasis(GetDataRequest request) {
        String body = null;
        try {
            body = objectMapper.writeValueAsString(request);
            if (isApplicationActive()) {
                return Response.ok(invSkyExtractService.getDataByDateAndPnr(request)).build();
            } else {
                log.error("Application not active:RequestBody:- {} ", body);
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                        .entity(Constants.APPLICATION_NOT_ACTIVE)
                        .build();
            }

        } catch (Exception e) {
            e.printStackTrace();
            log.error("Error during data insertion: RequestBody:- {} ", body);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Failed to process data")
                    .build();
        }
    }

    @GET
    @Path("/distinctPNRByDate")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getRecordPnrBasis() {
        try {

            if (isApplicationActive()) {
                return Response.ok(invSkyExtractService.getDistinctPNRByDate()).build();
            } else {
                log.error(Constants.APPLICATION_STATUS);
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                        .entity(Constants.APPLICATION_NOT_ACTIVE)
                        .build();
            }

        } catch (Exception e) {
            log.error("Error during fetching records: {}", e.getMessage());
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Failed to process data")
                    .build();
        }
    }

    @GET
    @Path("/error")
    public void error(@QueryParam("date") String date, @QueryParam("user") String user) {
        log.error("Running error while processing: date: {}, user: {}", date, user);
        GlobalVariables.setAppState("INACTIVE");
        if (!Constants.PRE_ERROR.equals(GlobalVariables.requestType)) {
            stateManagement.markErrorInInvoiceTransaction();
        }
        GlobalVariables.setRequestType("NONE");
        log.info(GlobalVariables.requestType);

    }

    @GET
    @Path("/pre-error-startup")
    public void preErrorStartupService() {
        log.error("Running pre error startup");

        if (Constants.PRE_ERROR.equals(GlobalVariables.requestType)) {
            GlobalVariables.setRequestType("NONE");
            GlobalVariables.setAppState("INACTIVE");
        }

    }

    @POST
    @Path("/pre-error-postCompletion")
    public Response postCompletion(List<String> listIdes, @QueryParam("requestId") String requestId,
            @QueryParam("reason") String reason) {
        log.info(GlobalVariables.requestType);
        log.info("Request received for pre error Completion - requestId: {}, reason: {}", requestId, reason);

        // Create ExecutorService with a fixed thread pool
        ExecutorService executor = Executors.newSingleThreadExecutor();

        // Execute async task
        executor.submit(() -> {
            try {
                if (isApplicationActive()) {
                    postInvoiceCompletion.preErrorpostCompletion(listIdes, reason, requestId);

                } else {
                    fileStatusRepository.trackFile(
                            "File processing failed. Kindly revisit, download, and correct the errors.", requestId,
                            "FAILED");
                    log.error("Application not active: {}", GlobalVariables.requestType);

                }

            } catch (Exception e) {
                log.error("Error during completing pre error records: {}", e.getMessage());

            } finally {
                GlobalVariables.setRequestType("NONE");
                executor.shutdown();
            }
        });

        return Response.status(Response.Status.OK)
                .entity("PROCESSING_STARTED")
                .build();
    }

    @GET
    @Path("/postCompletion")
    public void postCompletion(@QueryParam("month") String month, @QueryParam("user") String user) {

        log.info("Request received for post invoice Completion - month: {}, user: {}", month, user);

        // Create ExecutorService with a fixed thread pool
        ExecutorService executor = Executors.newSingleThreadExecutor();

        // Execute async task
        executor.submit(() -> {
            try {
                if (isApplicationActive()) {

                    postInvoiceCompletion.postCompletion(month);

                    stateManagement.markCompleteInInvoiceTransaction();

                } else {
                    log.error(Constants.APPLICATION_STATUS);
                    // throw new RuntimeException(Constants.APPLICATION_NOT_ACTIVE);

                }

            } catch (Exception e) {
                log.error("Error during invoice completion: {}", e.getMessage());
                stateManagement.markErrorInInvoiceTransaction();
            } finally {
                GlobalVariables.setRequestType("NONE");
            }
        });
    }

    @GET
    @Path("/inv-series")
    public Response getInvSeriesList(@QueryParam("financialYear") int financialYear) {
        try {
            if (isApplicationActive()) {
                return Response.ok(invSeriesService.getInvSeriesList(financialYear)).build();
            } else {
                log.error(Constants.APPLICATION_STATUS);
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                        .entity(Constants.APPLICATION_NOT_ACTIVE)
                        .build();
            }

        } catch (Exception e) {
            log.error("Failed to retrive data from inv series table: {}", e.getMessage());
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Failed to process data")
                    .build();
        }
    }

    @GET
    @Path("/state-series")
    public Response getStateSeriesList() {
        try {

            if (isApplicationActive()) {
                return Response.ok(invSeriesService.getStateSeriesList()).build();
            } else {
                log.error(Constants.APPLICATION_STATUS);
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                        .entity(Constants.APPLICATION_NOT_ACTIVE)
                        .build();
            }

        } catch (Exception e) {
            log.error("Failed to retrive data from state series table: {}", e.getMessage());
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Failed to process data")
                    .build();
        }
    }

    @POST
    @Path("/insert-series")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response insertInvoiceSeries(InvSeries invSeries) {
        try {
            if (isApplicationActive()) {
                invSeriesService.insertInvoiceSeries(invSeries);
                return Response.ok("Data processed successfully").build();
            } else {
                log.error(Constants.APPLICATION_STATUS);
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                        .entity(Constants.APPLICATION_NOT_ACTIVE)
                        .build();
            }

        } catch (Exception e) {
            log.error("Failed to insert data into inv series table: {}", e.getMessage());
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Failed to process data")
                    .build();
        }
    }

    @PUT
    @Path("/update-series")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response updateInvoiceSeries(InvSeries invSeries) {
        try {

            if (isApplicationActive()) {
                invSeriesService.updateInvoiceSeries(invSeries);
                return Response.ok("Data processed successfully").build();
            } else {
                log.error(Constants.APPLICATION_STATUS);
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                        .entity(Constants.APPLICATION_NOT_ACTIVE)
                        .build();
            }

        } catch (Exception e) {
            log.error("Failed to update data into inv series table: {}", e.getMessage());
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Failed to process data")
                    .build();
        }
    }

    @POST
    @Path("/dataForCreditNoteByStateCodeB2C")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response dataForCreditNoteByStateCodeB2C(CreditNoteRequest request) {
        try {
            if (isApplicationActive()) {
                return Response.ok(
                        creditNote.dataForCreditNoteByStateCodeB2C(request.getStateCode(),
                                request.getTransactionDate()))
                        .build();
            } else {
                log.error(Constants.APPLICATION_STATUS);
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                        .entity(Constants.APPLICATION_NOT_ACTIVE)
                        .build();
            }

        } catch (Exception e) {
            log.error("Failed to retrive data for dataForCreditNoteByStateCodeB2C: {}", e.getMessage());
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Failed to process data")
                    .build();
        }
    }

    @POST
    @Path("/dataForCreditNoteByPnrAndStateCodeB2C")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response dataForCreditNoteByPnrAndStateCodeB2C(CreditNoteRequest request) {
        try {

            if (isApplicationActive()) {

                return Response
                        .ok(creditNote.dataForCreditNoteByPnrAndStateCodeB2C(request.getPnr(), request.getStateCode(),
                                request.getTransactionDate()))
                        .build();
            } else {
                log.error(Constants.APPLICATION_STATUS);
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                        .entity(Constants.APPLICATION_NOT_ACTIVE)
                        .build();
            }

        } catch (Exception e) {
            log.error("Failed to retrive data for dataForCreditNoteByPnrAndStateCodeB2C: {}", e.getMessage());
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Failed to process data")
                    .build();
        }
    }

    @POST
    @Path("/dataForCreditNoteByPnrStateCodeAndGstB2B")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response dataForCreditNoteByPnrStateCodeAndGstB2B(CreditNoteRequest request) {
        try {

            if (isApplicationActive()) {
                return Response
                        .ok(creditNote.dataForCreditNoteByPnrStateCodeAndGstB2B(request.getPnr(),
                                request.getStateCode(),
                                request.getCustomerGSTIN(), request.getTransactionDate()))
                        .build();
            } else {
                log.error(Constants.APPLICATION_STATUS);
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                        .entity(Constants.APPLICATION_NOT_ACTIVE)
                        .build();
            }

        } catch (Exception e) {
            log.error("Failed to retrive data for dataForCreditNoteByPnrStateCodeAndGstB2B: {}", e.getMessage());
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Failed to process data")
                    .build();
        }
    }

    @POST
    @Path("/dataForCreditNoteByStateCodeAndGstB2B")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response dataForCreditNoteByStateCodeAndGstB2B(CreditNoteRequest request) {
        try {

            if (isApplicationActive()) {
                return Response.ok(
                        creditNote.dataForCreditNoteByStateCodeAndGstB2B(request.getStateCode(),
                                request.getCustomerGSTIN(),
                                request.getTransactionDate()))
                        .build();
            } else {
                log.error(Constants.APPLICATION_STATUS);
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                        .entity(Constants.APPLICATION_NOT_ACTIVE)
                        .build();
            }

        } catch (Exception e) {
            log.error("Failed to retrive data for dataForCreditNoteByStateCodeAndGstB2B: {}", e.getMessage());
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Failed to process data")
                    .build();
        }
    }

    @POST
    @Path("/allDataForCreditNoteByStateCodeAndGstB2B")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response allDataForCreditNoteByStateCodeAndGstB2B(CreditNoteRequest request) {
        try {

            if (isApplicationActive()) {

                return Response.ok(creditNote.allDataForCreditNoteByStateCodeAndGstB2B(request.getStateCode(),
                        request.getCustomerGSTIN(),
                        request.getTransactionDate())).build();
            } else {
                log.error(Constants.APPLICATION_STATUS);
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                        .entity(Constants.APPLICATION_NOT_ACTIVE)
                        .build();
            }

        } catch (Exception e) {
            log.error("Failed to retrive data for dataForCreditNoteByStateCodeAndGstB2B: {}", e.getMessage());

            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("Failed to process data")
                    .build();
        }
    }

}
