package in.indigo.resource;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import in.indigo.configuration.Constants;

import org.apache.camel.Exchange;
// import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
// import org.apache.camel.component.jackson.JacksonDataFormat;
// import org.apache.camel.model.dataformat.JsonLibrary;
// import org.apache.camel.model.rest.RestBindingMode;
import org.apache.camel.model.rest.RestParamType;
// import org.eclipse.microprofile.rest.client.inject.RestClient;

import in.indigo.configuration.GlobalVariables;
// import in.indigo.restClient.InvoiceApprovalClient;
import in.indigo.utility.MssqlToDuckDBTransfer;
// import in.indigo.utility.StateManagement;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@ApplicationScoped
@Slf4j
public class PreErrorInvoice extends RouteBuilder {
    // private final StateManagement stateManagement;
    private final MssqlToDuckDBTransfer mssqlToDuckDBTransfer;
    // @RestClient
    // InvoiceApprovalClient invoiceApprovalClient;

    // JacksonDataFormat jacksonDataFormat = new JacksonDataFormat(List.class);

    @Override
    public void configure() throws Exception {

        onException(Exception.class)
                .log("=========================>${exception.message}")
                .setHeader("exception", simple("${exception.message}"))
                
                .handled(true)
                .stop();

        restConfiguration()
                .component("platform-http");

                // .bindingMode(RestBindingMode.json);

        rest("api/v1/cs")
                .post("/pre-error-series")
                
                .param().type(RestParamType.query).dataType(Constants.STRING).name("user").endParam()
                .param().type(RestParamType.query).dataType(Constants.STRING).name("requestType").endParam()
                .to("direct:start-pre-error-processing");

        from("direct:start-pre-error-processing")
                .routeId("start-pre-error-processing")
                .log("start-pre-error-processing${body}")
                // .unmarshal(jacksonDataFormat)
                .log("start-pre-error-processing------------------${body}")
                .process(exchange -> {

                    List<String> date = Arrays.asList(exchange.getIn().getBody(String[].class));
                    String user = exchange.getIn().getHeader("user", String.class);
                    String requestType = exchange.getIn().getHeader("requestType", String.class);
                    log.info("date--> {}: , User-------> {}:,requestType----------->{} ", date, user, requestType);
                    if ("NONE".equals(GlobalVariables.requestType)) {
                        log.info("User: {}, Date: {}, Request Type: {}", user, date, requestType);
                        GlobalVariables.setRequestType(requestType);
                    } else  {
                        log.info("Process Already Running for");
                        exchange.getIn().setBody("Process Already Running");
                        exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, 200);
                        exchange.setRouteStop(true);
                        return;

                    }
                    log.info("Running request type: " + GlobalVariables.requestType);
                })
                .process(mssqlToDuckDBTransfer)
                .setBody(simple("Series transfered from mssql to duck db"))
                .log("Series transfered from mssql to duck db")
                .end();

    }

}
