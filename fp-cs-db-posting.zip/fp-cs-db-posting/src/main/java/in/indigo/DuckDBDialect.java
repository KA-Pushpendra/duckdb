package in.indigo;

import org.hibernate.boot.model.FunctionContributions;
import org.hibernate.dialect.DatabaseVersion;
import org.hibernate.dialect.Dialect;
import org.hibernate.type.StandardBasicTypes;

public class DuckDBDialect extends Dialect {

    public DuckDBDialect() {
        super();
    }

    @Override
    public void contributeFunctions(FunctionContributions functionContributions) {
        super.contributeFunctions(functionContributions);
        var functionRegistry = functionContributions.getFunctionRegistry();
        functionRegistry.registerPattern("lower", "lower(?1)",
                functionContributions.getTypeConfiguration().getBasicTypeRegistry().resolve(StandardBasicTypes.STRING));
        functionRegistry.registerPattern("upper", "upper(?1)",
                functionContributions.getTypeConfiguration().getBasicTypeRegistry().resolve(StandardBasicTypes.STRING));
    }

    @Override
    public int getDefaultStatementBatchSize() {
        return 1000;
    }

    @Override
    public DatabaseVersion getVersion() {
        return DatabaseVersion.make(1);
    }
}