package in.indigo.mssqlEntity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@ToString
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name = "Inv_Series_CS")
public class InvSeries extends PanacheEntityBase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-generate IDs
    @Column(name = "ID", nullable = false)
    private Integer id;

    @Column(name = "Month")
    private String month;

    @Column(name = "StateCode", length = 5)
    private String stateCode;

    @Column(name = "CurrentValue")
    private Integer currentValue;

    @Column(name = "MaxValue")
    private Integer maxValue;

    @Column(name = "Active")
    private Integer active;

    @Column(name = "FinancialYear")
    private Integer financialYear;

    @Column(name = "InvoiceType", length = 10)
    private String invoiceType;
    @Transient
    @Column(name = "isNew")
    private Boolean isNew;
}
