
package in.indigo.mssqlEntity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@ToString
@Table(name = "ErrorInvoiceDetails_CS")
public class ErrorInvoiceDetails extends PanacheEntityBase {

    @Id
    @Column(name = "ID")
    private String id;

    @Column(name="Pnr")
    private String pnr;

    @Column(name = "Invoicenumber")
    private String invoiceNumber;

    @Column(name= "GoodsServicesType")
    private String goodsServicesType;

    @Column(name = "ErrorID")
    private int errorId;

    @Column(name = "Local Currency")
    private String localCurrency;

    @Column(name = "TransactionDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/d/yyyy")
    private Date transactionDate;

    @Column(name = "IsCorrect")
    private int isCorrect;

    @Transient
    @Column(name = "reasonIds")
    private String reasonIds;

    @Transient
    @Column(name = "errorDescription")
    private String errorDescription;

    @Transient
    @Column(name="tranType")
    private String tranType;
}
