package in.indigo.mssqlEntity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name = "FileStatus_CS")
@Builder
public class FileStatus {

    @Id
    @Column(name = "Id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "Request_ID")
    private String requestId;

    @Column(name = "File Name")
    private String fileName;

    @Column(name = "Status", length = 100)
    private String status;

    @Column(name = "Reason", length = 150)
    private String reason;

    @Column(name = "Modified By", length = 200)
    private String modifiedBy;

    @Column(name = "Modified At")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "Asia/Kolkata")
    private LocalDateTime modifiedAt;

    @Column(name = "File Type")
    private String fileType;

}