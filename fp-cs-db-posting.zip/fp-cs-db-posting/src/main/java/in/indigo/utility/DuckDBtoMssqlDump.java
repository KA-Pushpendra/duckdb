package in.indigo.utility;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

import org.eclipse.microprofile.faulttolerance.Retry;

import in.indigo.mssqlEntity.AuditInvoiceDWH;
import in.indigo.mssqlEntity.ErrorInvoiceDetails;
import in.indigo.mssqlEntity.ErrorPNRRecord;
import in.indigo.mssqlEntity.InvSkyExtractAc;
import in.indigo.mssqlEntity.InvoiceDWH;
import in.indigo.mssqlRepository.AuditInvoiceDwhRepository;
import in.indigo.mssqlRepository.ErrorInvoiceDetailsRepository;
import in.indigo.mssqlRepository.ErrorPNRRecordRepository;
import in.indigo.mssqlRepository.InvSkyExtractAcRepository;
import in.indigo.mssqlRepository.InvoiceDwhmssqlRepository;

@SuppressWarnings("unchecked")
@Slf4j
@ApplicationScoped
@Getter
@RequiredArgsConstructor
public class DuckDBtoMssqlDump {

    private final InvSkyExtractAcRepository invSkyExtractAcRepository;
    private final AuditInvoiceDwhRepository auditInvoiceDwhRepository;
    private final ErrorInvoiceDetailsRepository errorInvoiceDetailsRepository;
    private final ErrorPNRRecordRepository errorPNRRecordRepository;

    private final InvoiceDwhmssqlRepository invoiceDwhRepository;

    @Transactional
    public void process(List<?> list) {
        if (list.isEmpty()) {
            return;
        }

        Object obj = list.get(0);

        try {
            if (obj instanceof InvSkyExtractAc) {

                List<InvSkyExtractAc> dataList = List.copyOf((List<InvSkyExtractAc>) list);
                processInvSkyExtractAc(dataList);

            } else if (obj instanceof AuditInvoiceDWH) {

                List<AuditInvoiceDWH> dataList = List.copyOf((List<AuditInvoiceDWH>) list);
                processAuditInvoiceDWH(dataList);

            } else if (obj instanceof ErrorInvoiceDetails) {

                List<ErrorInvoiceDetails> dataList = List.copyOf((List<ErrorInvoiceDetails>) list);
                dataList.forEach(d -> processErrorInvoiceDetails(d));

            } else if (obj instanceof ErrorPNRRecord) {

                List<ErrorPNRRecord> dataList = List.copyOf((List<ErrorPNRRecord>) list);
                processErrorPNRRecords(dataList);

            } else if (obj instanceof InvoiceDWH) {

                List<InvoiceDWH> dataList = List.copyOf((List<InvoiceDWH>) list);
                processInvoiceDWH(dataList);

            } else {
                throw new RuntimeException("Invalid data type");
            }
        } catch (Exception e) {
            throw new RuntimeException("Unable to persist");
        }
    }

    @Transactional
    public void processInvSkyExtractAc(List<InvSkyExtractAc> dataList) {
        retryPersist(() -> invSkyExtractAcRepository.persist(dataList));
    }

    @Transactional
    public void processAuditInvoiceDWH(List<AuditInvoiceDWH> dataList) {
        retryPersist(() -> auditInvoiceDwhRepository.persist(dataList));
    }

    @Transactional
    public void processErrorInvoiceDetails(ErrorInvoiceDetails detail) {
        retryPersist(() -> {
            try {
                errorInvoiceDetailsRepository.persist(detail);
            } catch (Exception ex) {
                log.error("Error in errorInvoiceDetails -----> {}", detail, ex);
                throw new RuntimeException(ex);
            }
        });
    }

    @Transactional
    public void processErrorPNRRecords(List<ErrorPNRRecord> errorPNRRecordList) {
        retryPersist(() -> errorPNRRecordRepository.persist(errorPNRRecordList));
    }

    @Transactional
    public void processInvoiceDWH(List<InvoiceDWH> invoiceDWHList) {
        retryPersist(() -> invoiceDwhRepository.persist(invoiceDWHList));
    }

    @Retry(maxRetries = 3, delay = 1000)
    public void retryPersist(Runnable runnable) {
        runnable.run();
    }

}
