package in.indigo.utility;

import java.util.Date;
import java.util.List;

import in.indigo.duckRepository.InvoiceDwhRepository;
import in.indigo.mssqlRepository.InvoiceDwhmssqlRepository;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@Slf4j
@ApplicationScoped
public class CreditNote {
    private final InvoiceDwhmssqlRepository invoiceDwhmssqlRepository;

    private final InvoiceDwhRepository invoiceDwhduckRepository;

    public List<Object[]> allDataForCreditNoteByStateCodeAndGstB2B(String stateCode, String customerGSTIN,
            Date transactionDate) {

        try {
            // Fetch data from MSSQL repository
            List<Object[]> mssql = invoiceDwhmssqlRepository.getAllDataForCreditNoteByStateCodeAndGstB2B(stateCode,
                    customerGSTIN,
                    transactionDate);

            // If MSSQL repository returns empty, fetch data from DuckDB repository
            if (mssql.isEmpty()) {

                List<Object[]> duckdb = invoiceDwhduckRepository.getAllDataForCreditNoteByStateCodeAndGstB2B(stateCode,
                        customerGSTIN,
                        transactionDate);

                return duckdb;
            }

            return mssql;

        } catch (Exception e) {
            // Log the exception with context details
            log.error("Error fetching data for Credit Note by customerGSTIN: {}, StateCode: {}, TransactionDate: {}",
                    customerGSTIN, stateCode, transactionDate, e);

            // Rethrow the exception as a runtime exception
            throw new RuntimeException(
                    "Failed to fetch data for Credit Note by customerGSTIN, StateCode, and TransactionDate",
                    e);
        }

    }

    public List<Object[]> dataForCreditNoteByStateCodeAndGstB2B(String stateCode, String customerGSTIN,
            Date transactionDate) {

        try {
            // Fetch data from MSSQL repository
            List<Object[]> mssql = invoiceDwhmssqlRepository.getDataForCreditNoteByStateCodeAndGstB2B(stateCode,
                    customerGSTIN,
                    transactionDate);

            // If MSSQL repository returns empty, fetch data from DuckDB repository
            if (mssql.isEmpty()) {

                List<Object[]> duckdb = invoiceDwhduckRepository.getDataForCreditNoteByStateCodeAndGstB2B(stateCode,
                        customerGSTIN,
                        transactionDate);

                return duckdb;
            }

            return mssql;

        } catch (Exception e) {
            // Log the exception with context details
            log.error("Error fetching data for Credit Note by customerGSTIN: {}, StateCode: {}, TransactionDate: {}",
                    customerGSTIN, stateCode, transactionDate, e);

            // Rethrow the exception as a runtime exception
            throw new RuntimeException(
                    "Failed to fetch data for Credit Note by customerGSTIN, StateCode, and TransactionDate",
                    e);
        }

    }

    public List<Object[]> dataForCreditNoteByPnrStateCodeAndGstB2B(String pnr, String stateCode,
            String customerGSTIN, Date transactionDate) {
        try {
            // Fetch data from MSSQL repository
            List<Object[]> mssql = invoiceDwhmssqlRepository.getDataForCreditNoteByPnrStateCodeAndGstB2B(pnr, stateCode,
                    customerGSTIN, transactionDate);

            // If MSSQL repository returns empty, fetch data from DuckDB repository
            if (mssql.isEmpty()) {

                List<Object[]> duckdb = invoiceDwhduckRepository.getDataForCreditNoteByPnrStateCodeAndGstB2B(pnr,
                        stateCode,
                        customerGSTIN, transactionDate);

                return duckdb;
            }

            return mssql;

        } catch (Exception e) {
            // Log the exception with context details
            log.error(
                    "Error fetching data for Credit Note by pnr: {}, customerGSTIN: {}, StateCode: {}, TransactionDate: {}",
                    pnr, customerGSTIN, stateCode, transactionDate, e);

            // Rethrow the exception as a runtime exception
            throw new RuntimeException(
                    "Failed to fetch data for Credit Note by pnr, customerGSTIN, StateCode, and TransactionDate",
                    e);
        }
    }

    public List<Object[]> dataForCreditNoteByPnrAndStateCodeB2C(String pnr, String stateCode,
            Date transactionDate) {
        try {
        //     Fetch data from MSSQL repository
            List<Object[]> mssql = invoiceDwhmssqlRepository.getDataForCreditNoteByPnrAndStateCodeB2C(pnr, stateCode,
                    transactionDate);

        //     If MSSQL repository returns empty, fetch data from DuckDB repository
            if (mssql.isEmpty()) {

                List<Object[]> duckdb = invoiceDwhduckRepository.getDataForCreditNoteByPnrAndStateCodeB2C(pnr,
                        stateCode,
                        transactionDate);

                return duckdb;
            }

            return mssql;

        } catch (Exception e) {
            // Log the exception with context details
            log.error("Error fetching data for Credit Note by PNR: {}, StateCode: {}, TransactionDate: {}",
                    pnr, stateCode, transactionDate, e);

            // Rethrow the exception as a runtime exception
            throw new RuntimeException("Failed to fetch data for Credit Note by PNR, StateCode, and TransactionDate",
                    e);
        }
    }

    public List<Object[]> dataForCreditNoteByStateCodeB2C(String stateCode, Date transactionDate) {
        try {
            // Fetch data from MSSQL repository
            List<Object[]> mssql = invoiceDwhmssqlRepository.getDataForCreditNoteByStateCodeB2C(stateCode,
                    transactionDate);

            // If MSSQL repository returns empty, fetch data from DuckDB repository
            if (mssql.isEmpty()) {

                List<Object[]> duckdb = invoiceDwhduckRepository.getDataForCreditNoteByStateCodeB2C(
                        stateCode,
                        transactionDate);

                return duckdb;
            }

            return mssql;

        } catch (Exception e) {
            // Log the exception with context details
            log.error("Error fetching data for Credit Note by PNR: {}, StateCode: {}, TransactionDate: {}",
                    stateCode, transactionDate, e);

            // Rethrow the exception as a runtime exception
            throw new RuntimeException("Failed to fetch data for Credit Note by PNR, StateCode, and TransactionDate",
                    e);
        }
    }

}
