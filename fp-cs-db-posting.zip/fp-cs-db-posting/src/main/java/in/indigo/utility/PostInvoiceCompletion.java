package in.indigo.utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.SocketTimeoutException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLRecoverableException;
import java.sql.SQLTimeoutException;
import java.sql.SQLTransientConnectionException;
import java.sql.SQLTransientException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.eclipse.microprofile.faulttolerance.Retry;

import com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord;
import com.microsoft.sqlserver.jdbc.SQLServerBulkCopy;
import com.microsoft.sqlserver.jdbc.SQLServerBulkCopyOptions;

import in.indigo.configuration.Constants;
import in.indigo.configuration.DbConnecton;
import in.indigo.configuration.GlobalVariables;
import in.indigo.duckdbEntity.InvSeries;
import in.indigo.mssqlEntity.ProgressTracker;
import in.indigo.mssqlRepository.FileStatusRepository;
import in.indigo.mssqlRepository.ProgressTrackerRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@ApplicationScoped
@Slf4j

@RequiredArgsConstructor
public class PostInvoiceCompletion {

    private final MoveFilesAndDeleteFolder moveFilesAndDeleteFolder;
    private final ProgressTrackerRepository progressTrackerRepository;
    private final DbConnecton dbConnecton;

    private final FileStatusRepository fileStatusRepository;

    private final String ERROR_PNR_OUT_FOLDER = "output/ErrorPNRRecord";

    @ConfigProperty(name = "Inv_SkyExtract_Ac_CS_view")
    private String inv_SkyExtract_Ac_CS_view;

    @ConfigProperty(name = "Audit_invoice_DWH_CS_view")
    private String audit_invoice_DWH_CS_view;

    @ConfigProperty(name = "ErrorInvoiceDetails_CS_view")
    private String errorInvoiceDetails_CS_view;

    @ConfigProperty(name = "ErrorPNRRecords_CS_view")
    private String errorPNRRecords_CS_view;

    @ConfigProperty(name = "Invoice_DWH_CS_view")
    private String invoice_DWH_CS_view;

    private static final int BATCH_SIZE = 20000;

    public void postCompletion(String monthYear) throws Exception {
        try {

            String[] parts = monthYear.split("/");

            int month = Integer.parseInt(parts[0]) - 1;
            int year = Integer.parseInt(parts[1]);

            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.YEAR, year);
            calendar.set(Calendar.MONTH, month);

            SimpleDateFormat sdfm = new SimpleDateFormat("MMMM yyyy");
            String monthName = sdfm.format(calendar.getTime());

            Date current = new Date(System.currentTimeMillis());
            Instant timestamp = Instant.now();
            long epochMillis = timestamp.toEpochMilli();
            String requestId = epochMillis + "_Data Persistance";
            ProgressTrackerService.setRequestId(requestId);
            ProgressTracker progressTracker = ProgressTracker.builder()

                    .progressPercentage(0)
                    .trackingState("Data Persistance")
                    .monthYear(monthName)
                    .lastUpdatedAt(current)
                    .requestId(requestId)
                    .build();
            progressTrackerRepository.create(progressTracker);
            ProgressTrackerService.setPercentageCompleted(0);
            ProgressTrackerService.setCheckValue(0);
            File outputDir = new File("input");
            if (!outputDir.exists()) {
                outputDir.mkdirs();
            }

            TransferData(null, requestId);
            updateSeries(getInvSeries());

            updatePercentage(5);

            // SimpleDateFormat folderFormate = new SimpleDateFormat("MMMM_yyyy");

            moveFilesAndDeleteFolder.moveFiles();
            updatePercentage(5);

        } catch (Exception e) {
            log.error("An error occurred during postCompletion: {}", e.getMessage(), e);
            throw e;
        }
    }

    @Transactional
    public void preErrorpostCompletion(List<String> listIdes, String reason, String requestId) throws Exception {
        try {
            // System.out.println("cccccccccccccccccccccc"+date);
            // log.info("=====>date: "+date);
            // log.info("=====>listIdes: "+listIdes);
            // DateTimeFormatter inputFormat = DateTimeFormatter.ofPattern(DF);
            // DateTimeFormatter outputFormat = DateTimeFormatter.ofPattern("dd_MM_yyyy");

            // LocalDate transactionDate = LocalDate.parse(date, inputFormat);

            // String formattedDate = transactionDate.format(outputFormat);
            File outputDir = new File("input");
            if (!outputDir.exists()) {
                outputDir.mkdirs();
            }

            TransferData(listIdes, null);
            updateSeries(getInvSeries());

            moveFilesAndDeleteFolder.moveFiles();
            fileStatusRepository.trackFile(reason, requestId, "COMPLETED");
            log.info("Batch completed" + GlobalVariables.requestType);
            GlobalVariables.setRequestType("NONE");
            log.info(GlobalVariables.requestType);

        } catch (Exception e) {
            fileStatusRepository.trackFile("File processing failed. Kindly revisit, download, and correct the errors.",
                    requestId, "FAILED");

            log.error("An error occurred during pre-error-postCompletion: {}", e.getMessage(), e);
            throw e;
        }
    }

    @Transactional
    @Retry(maxRetries = 3, delay = 5000, retryOn = {
            SQLTimeoutException.class, // SQL timeout exception (transient)
            SQLTransientConnectionException.class, // Transient database connection issues
            SQLTransientException.class, // General transient SQL errors
            SQLRecoverableException.class, // Recoverable SQL issues during runtime
            SocketTimeoutException.class // Transient network timeout issues
    })

    public void TransferData(List<String> listIdes, String requestId) throws Exception {

        try (Statement smt = dbConnecton.getDuckDbConnection().createStatement()) {

            log.info("Start view creation");
            smt.execute(inv_SkyExtract_Ac_CS_view);
            smt.execute(audit_invoice_DWH_CS_view);
            smt.execute(errorInvoiceDetails_CS_view);
            smt.execute(errorPNRRecords_CS_view);
            smt.execute(invoice_DWH_CS_view);
            log.info("End view creation");

            updatePercentage(2);

            log.info("Start CSV creation");
            smt.execute(
                    "COPY Inv_SkyExtract_Ac_CS_view TO 'input/InvSkyExtractAc.csv' (FORMAT CSV, HEADER true, DELIMITER ',',QUOTE '\"')");
            smt.execute(
                    "COPY audit_invoice_DWH_CS_view TO 'input/AuditInvoiceDWH.csv' (FORMAT CSV, HEADER true, DELIMITER ',',QUOTE '\"')");
            smt.execute(
                    "COPY errorInvoiceDetails_CS_view TO 'input/ErrorInvoiceDetails.csv' (FORMAT CSV, HEADER true, DELIMITER ',',QUOTE '\"')");
            smt.execute(
                    "COPY errorPNRRecords_CS_view TO 'input/ErrorPNRRecord.csv' (FORMAT CSV, HEADER true, DELIMITER ',',QUOTE '\"')");
            smt.execute(
                    "COPY invoice_DWH_CS_view TO 'input/InvoiceDWH.csv' (FORMAT CSV, HEADER true, DELIMITER ',',QUOTE '\"')");
            log.info("End CSV creation");

            updatePercentage(3);

            invSkyExtractAc(requestId);
            auditInvoiceDWH(requestId);
            // errorInvoiceDetails();

            if (Constants.PRE_ERROR.equalsIgnoreCase(GlobalVariables.requestType)) {

                preErrorUpdate(listIdes);
            } else {
                errorPNRRecord(requestId);
            }

            invoiceDWH(requestId);
            log.info("Completed successfully");

        } catch (Exception e) {
            log.error("An error occurred during TransferData: {}", e.getMessage(), e);
            throw e;
        }
    }

    @Transactional
    @Retry(maxRetries = 3, delay = 5000, retryOn = {
            SQLTimeoutException.class, // SQL timeout exception (transient)
            SQLTransientConnectionException.class, // Transient database connection issues
            SQLTransientException.class, // General transient SQL errors
            SQLRecoverableException.class, // Recoverable SQL issues during runtime
            SocketTimeoutException.class // Transient network timeout issues
    })
    public List<InvSeries> getInvSeries() throws Exception {
        String query = "SELECT * FROM Inv_Series_CS"; // Adjust the query based on your database schema
        List<InvSeries> invSeriesList = new ArrayList<>();

        try (PreparedStatement stmt = dbConnecton.getDuckDbConnection().prepareStatement(query);
                ResultSet rs = stmt.executeQuery()) {

            log.info("Fetching Inv Series");

            while (rs.next()) {
                InvSeries invSeries = new InvSeries();
                invSeries.setId(rs.getInt("ID"));
                invSeries.setMonth(rs.getString("Month"));
                invSeries.setStateCode(rs.getString(Constants.STATE_CODE));
                invSeries.setCurrentValue(rs.getInt("CurrentValue"));
                invSeries.setMaxValue(rs.getInt("MaxValue"));
                invSeries.setActive(rs.getInt("Active"));
                invSeries.setFinancialYear(rs.getInt("FinancialYear"));
                invSeries.setInvoiceType(rs.getString("InvoiceType"));
                invSeries.setIsNew(rs.getBoolean("isNew"));
                invSeriesList.add(invSeries);
            }

        } catch (Exception e) {
            log.error("An error occurred while fetching Inv Series: {}", e.getMessage(), e);
            throw e; // Re-throw the exception as-is, without converting its type
        }

        return invSeriesList;
    }

    @Transactional
    @Retry(maxRetries = 3, delay = 5000, retryOn = {
            SQLTimeoutException.class, // SQL timeout exception (transient)
            SQLTransientConnectionException.class, // Transient database connection issues
            SQLTransientException.class, // General transient SQL errors
            SQLRecoverableException.class, // Recoverable SQL issues during runtime
            SocketTimeoutException.class // Transient network timeout issues
    })

    public void invSkyExtractAc(String requestId) throws Exception {
        log.info("Starting invSkyExtractAc");

        // Try-With-Resources ensures proper closing of resources
        try {

            splitCsvFile("input/InvSkyExtractAc.csv", "output/InvSkyExtractAc", Constants.OUTPUT, BATCH_SIZE);

            File folder = new File("output/InvSkyExtractAc");
            File[] files = folder.listFiles((dir, name) -> name.endsWith(".csv"));
            int totalFiles = files.length;
            if (totalFiles == 0) {
                updatePercentage(30);

            } else {
                for (File file : files) {

                    try (SQLServerBulkCSVFileRecord fileRecord = new SQLServerBulkCSVFileRecord(
                            file.getPath(),
                            null, ",", true);
                            SQLServerBulkCopy bulkCopy = new SQLServerBulkCopy(dbConnecton.getMssqlConnection());) {
                        fileRecord.setEscapeColumnDelimitersCSV(true);
                        // Adding column metadata
                        fileRecord.addColumnMetadata(1, Constants.TRANSACTION_DATE, java.sql.Types.TIMESTAMP, 0, 0);
                        fileRecord.addColumnMetadata(2, Constants.FILE_DATE, java.sql.Types.TIMESTAMP, 0, 0);
                        fileRecord.addColumnMetadata(3, Constants.DISPLAY_DATE, java.sql.Types.TIMESTAMP, 0, 0);
                        fileRecord.addColumnMetadata(4, Constants.FLIGHT_NUMBER, java.sql.Types.INTEGER, 10, 0);
                        fileRecord.addColumnMetadata(5, Constants.GOODS_SERVICES_TYPE, java.sql.Types.NVARCHAR,
                                Integer.MAX_VALUE, 0);
                        fileRecord.addColumnMetadata(6, "SAC", java.sql.Types.INTEGER, 10, 0);
                        fileRecord.addColumnMetadata(7, "PNR", java.sql.Types.NVARCHAR, 50, 0);
                        fileRecord.addColumnMetadata(8, "Dep", java.sql.Types.NVARCHAR, 50, 0);
                        fileRecord.addColumnMetadata(9, "Arr", java.sql.Types.NVARCHAR, 50, 0);
                        fileRecord.addColumnMetadata(10, Constants.PLACE_OF_EMBARKATION, java.sql.Types.NVARCHAR, 100,
                                0);
                        fileRecord.addColumnMetadata(11, Constants.STATE_CODE, java.sql.Types.VARCHAR, 10, 0);
                        fileRecord.addColumnMetadata(12, Constants.CUSTOMER_GSTIN, java.sql.Types.NVARCHAR, 50, 0);
                        fileRecord.addColumnMetadata(13, Constants.CUSTOMER_NAME, java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(14, Constants.EMAIL_ADDRESS, java.sql.Types.NVARCHAR, 100, 0);
                        fileRecord.addColumnMetadata(15, Constants.CUSTOMER_GST_REGISTRATION_STATE,
                                java.sql.Types.NVARCHAR,
                                50, 0);
                        fileRecord.addColumnMetadata(16, Constants.PASSENGER_NAME, java.sql.Types.NVARCHAR, 100, 0);
                        fileRecord.addColumnMetadata(17, Constants.PASSENGER_EMAIL, java.sql.Types.NVARCHAR, 100, 0);
                        fileRecord.addColumnMetadata(18, Constants.E6_GSTIN, java.sql.Types.NVARCHAR, 50, 0);
                        fileRecord.addColumnMetadata(19, Constants.E6_REGISTERED_ADDRESS, java.sql.Types.NVARCHAR, 250,
                                0);
                        fileRecord.addColumnMetadata(20, Constants.NON_TAXABLE_FARE_COMPONENT, java.sql.Types.FLOAT, 15,
                                0);
                        fileRecord.addColumnMetadata(21, Constants.TAXABLE_COMPONENT, java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(22, Constants.CGST_AMOUNT, java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(23, Constants.IGST_AMOUNT, java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(24, Constants.SGST_AMOUNT, java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(25, Constants.UGST_AMOUNT, java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(26, Constants.AIRPORT_CHARGES, java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(27, Constants.ORIGIN_COUNTRY, java.sql.Types.NVARCHAR, 50, 0);
                        fileRecord.addColumnMetadata(28, Constants.IS_EXEMPTED, java.sql.Types.BIT, 1, 0);
                        fileRecord.addColumnMetadata(29, Constants.CESS_AMOUNT, java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(30, Constants.LOCAL_CESS_AMOUNT, java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(31, Constants.IS_AUTO_CORRECTED, java.sql.Types.VARCHAR, 10, 0);
                        fileRecord.addColumnMetadata(32, "Id", java.sql.Types.VARCHAR, 64, 0);
                        fileRecord.addColumnMetadata(33, Constants.SP_EXEMPTEDFLIGHT, java.sql.Types.INTEGER, 10, 0);
                        fileRecord.addColumnMetadata(34, "spInternational", java.sql.Types.INTEGER, 10, 0);
                        fileRecord.addColumnMetadata(35, Constants.AUTO_CORRECTION_ID, java.sql.Types.VARCHAR, 1000, 0);
                        fileRecord.addColumnMetadata(36, Constants.AGENT_CODE, java.sql.Types.VARCHAR, 16, 0);

                        // Bulk copy initialization

                        SQLServerBulkCopyOptions copyOptions = new SQLServerBulkCopyOptions();
                        // copyOptions.setBatchSize(50000);
                        copyOptions.setBulkCopyTimeout(0);
                        // copyOptions.setTableLock(true);

                        bulkCopy.setBulkCopyOptions(copyOptions);
                        bulkCopy.setDestinationTableName("Inv_SkyExtract_Ac_CS");

                        bulkCopy.writeToServer(fileRecord);

                    }
                    log.info("Bulk copy operation completed successfully: {}", file.getName());

                    updatePercentage((double) 30 / (double) totalFiles);
                }
            }

        } catch (SQLException sqlEx) {
            log.error("SQL error occurred during invSkyExtractAc operation: {}", sqlEx.getMessage(), sqlEx);
            throw sqlEx; // Re-throwing SQL exception for handling upstream
        } catch (Exception e) {
            log.error("An error occurred during invSkyExtractAc operation: {}", e.getMessage(), e);
            throw e; // Re-throwing any unexpected exception
        } finally {
            log.info("invSkyExtractAc process finished.");
        }
    }

    @Transactional
    @Retry(maxRetries = 3, delay = 5000, retryOn = {
            SQLTimeoutException.class, // SQL timeout exception (transient)
            SQLTransientConnectionException.class, // Transient database connection issues
            SQLTransientException.class, // General transient SQL errors
            SQLRecoverableException.class, // Recoverable SQL issues during runtime
            SocketTimeoutException.class // Transient network timeout issues
    })
    public void auditInvoiceDWH(String requestId) throws Exception {
        log.info("Starting auditInvoiceDWH");

        try {
            splitCsvFile("input/AuditInvoiceDWH.csv", "output/AuditInvoiceDWH", Constants.OUTPUT, BATCH_SIZE);

            File folder = new File("output/AuditInvoiceDWH");
            File[] files = folder.listFiles((dir, name) -> name.endsWith(".csv"));
            int totalFiles = files.length;
            if (totalFiles == 0) {
                updatePercentage(10);

            } else {
                for (File file : files) {
                    try (SQLServerBulkCopy bulkCopy = new SQLServerBulkCopy(dbConnecton.getMssqlConnection());
                            SQLServerBulkCSVFileRecord fileRecord = new SQLServerBulkCSVFileRecord(
                                    file.getPath(),
                                    null, ",", true);) {
                        // Initialize the CSV file record
                        fileRecord.setEscapeColumnDelimitersCSV(true);

                        // Adding column metadata
                        fileRecord.addColumnMetadata(1, "AuditID", java.sql.Types.INTEGER, 4, 0);
                        fileRecord.addColumnMetadata(2, Constants.TRANSACTION_DATE, java.sql.Types.TIMESTAMP, 0, 0);
                        fileRecord.addColumnMetadata(3, Constants.FILE_DATE, java.sql.Types.TIMESTAMP, 0, 0);
                        fileRecord.addColumnMetadata(4, Constants.DISPLAY_DATE, java.sql.Types.TIMESTAMP, 0, 0);
                        fileRecord.addColumnMetadata(5, Constants.FLIGHT_NUMBER, java.sql.Types.INTEGER, 10, 0);
                        fileRecord.addColumnMetadata(6, Constants.GOODS_SERVICES_TYPE, java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(7, "SAC", java.sql.Types.INTEGER, 10, 0);
                        fileRecord.addColumnMetadata(8, "InvoiceNumber", java.sql.Types.NVARCHAR, 50, 0);
                        fileRecord.addColumnMetadata(9, "SequenceNo", java.sql.Types.INTEGER, 10, 0);
                        fileRecord.addColumnMetadata(10, "PNR", java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(11, "Dep", java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(12, "Arr", java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(13, Constants.PLACE_OF_EMBARKATION, java.sql.Types.NVARCHAR, 255,
                                0);
                        fileRecord.addColumnMetadata(14, Constants.STATE_CODE, java.sql.Types.VARCHAR, 2, 0);
                        fileRecord.addColumnMetadata(15, Constants.CUSTOMER_GSTIN, java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(16, Constants.CUSTOMER_NAME, java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(17, Constants.EMAIL_ADDRESS, java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(18, Constants.CUSTOMER_GST_REGISTRATION_STATE,
                                java.sql.Types.NVARCHAR,
                                255, 0);
                        fileRecord.addColumnMetadata(19, Constants.PASSENGER_NAME, java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(20, Constants.PASSENGER_EMAIL, java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(21, Constants.E6_GSTIN, java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(22, Constants.E6_REGISTERED_ADDRESS, java.sql.Types.NVARCHAR, 255,
                                0);
                        fileRecord.addColumnMetadata(23, Constants.NON_TAXABLE_FARE_COMPONENT, java.sql.Types.FLOAT, 15,
                                0);
                        fileRecord.addColumnMetadata(24, Constants.TAXABLE_COMPONENT, java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(25, Constants.CGST_AMOUNT, java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(26, Constants.IGST_AMOUNT, java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(27, Constants.SGST_AMOUNT, java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(28, Constants.UGST_AMOUNT, java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(29, "CGSTRate", java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(30, "IGSTRate", java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(31, "SGSTUGSTRate", java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(32, "IsProcessed", java.sql.Types.NVARCHAR, 50, 0);
                        fileRecord.addColumnMetadata(33, "InvOrder", java.sql.Types.SMALLINT, 10, 0);
                        fileRecord.addColumnMetadata(34, "IsCredit", java.sql.Types.SMALLINT, 10, 0);
                        fileRecord.addColumnMetadata(35, "ServiceNo", java.sql.Types.SMALLINT, 10, 0);
                        fileRecord.addColumnMetadata(36, Constants.CREATED_BY, java.sql.Types.NVARCHAR, 250, 0);
                        fileRecord.addColumnMetadata(37, "CreatedDate", java.sql.Types.TIMESTAMP, 0, 0);
                        fileRecord.addColumnMetadata(38, Constants.NUMBER_TYPE, java.sql.Types.BIT, 1, 0);
                        fileRecord.addColumnMetadata(39, Constants.REASON_ID, java.sql.Types.INTEGER, 10, 0);
                        fileRecord.addColumnMetadata(40, "Mailsend", java.sql.Types.INTEGER, 10, 0);
                        fileRecord.addColumnMetadata(41, Constants.AIRPORT_CHARGES, java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(42, Constants.ORIGIN_COUNTRY, java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(43, Constants.IS_EXEMPTED, java.sql.Types.BIT, 1, 0);
                        fileRecord.addColumnMetadata(44, "IsError", java.sql.Types.INTEGER, 10, 0);
                        fileRecord.addColumnMetadata(45, Constants.IS_CORRECT, java.sql.Types.INTEGER, 10, 0);
                        fileRecord.addColumnMetadata(46, "CreatedOn", java.sql.Types.TIMESTAMP, 0, 0);
                        fileRecord.addColumnMetadata(47, Constants.CESS_AMOUNT, java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(48, Constants.LOCAL_CESS_AMOUNT, java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(49, "errorIds", java.sql.Types.VARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(50, "ErrorDescription", java.sql.Types.VARCHAR, 1000, 0);
                        fileRecord.addColumnMetadata(51, "ReasonIDs", java.sql.Types.VARCHAR, 1000, 0);
                        fileRecord.addColumnMetadata(52, Constants.AUTO_CORRECTION_ID, java.sql.Types.VARCHAR, 1000, 0);
                        fileRecord.addColumnMetadata(53, Constants.IS_AUTO_CORRECTED, java.sql.Types.VARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(54, Constants.SP_EXEMPTEDFLIGHT, java.sql.Types.INTEGER, 10, 0);
                        fileRecord.addColumnMetadata(55, "spInternatoinal", java.sql.Types.INTEGER, 10, 0);
                        fileRecord.addColumnMetadata(56, "spSez", java.sql.Types.INTEGER, 10, 0);
                        fileRecord.addColumnMetadata(57, "Id", java.sql.Types.VARCHAR, 64, 0);
                        fileRecord.addColumnMetadata(58, Constants.AGENT_CODE, java.sql.Types.VARCHAR, 16, 0);

                        // Bulk copy process

                        SQLServerBulkCopyOptions copyOptions = new SQLServerBulkCopyOptions();
                        // copyOptions.setBatchSize(50000);
                        copyOptions.setBulkCopyTimeout(0);
                        // copyOptions.setTableLock(true);
                        bulkCopy.setBulkCopyOptions(copyOptions);
                        bulkCopy.setDestinationTableName("Audit_invoice_DWH_CS");
                        bulkCopy.writeToServer(fileRecord);

                    }

                    log.info("Bulk copy operation completed successfully: {}", file.getName());

                    updatePercentage((double) 10 / (double) totalFiles);
                }
            }
        } catch (SQLException sqlEx) {
            log.error("SQL error occurred during auditInvoiceDWH: {}", sqlEx.getMessage(), sqlEx);
            throw sqlEx; // Re-throw SQL exceptions
        } catch (Exception ex) {
            log.error("Unexpected error during auditInvoiceDWH: {}", ex.getMessage(), ex);
            throw ex; // Re-throw unexpected exceptions
        } finally {
            log.info("auditInvoiceDWH process finished.");
        }
    }

    @Transactional
    @Retry(maxRetries = 3, delay = 5000, retryOn = {
            SQLTimeoutException.class, // SQL timeout exception (transient)
            SQLTransientConnectionException.class, // Transient database connection issues
            SQLTransientException.class, // General transient SQL errors
            SQLRecoverableException.class, // Recoverable SQL issues during runtime
            SocketTimeoutException.class // Transient network timeout issues
    })
    public void errorInvoiceDetails() throws Exception {
        log.info("Starting errorInvoiceDetails");

        try {
            splitCsvFile("input/ErrorInvoiceDetails.csv", "output/ErrorInvoiceDetails", Constants.OUTPUT, BATCH_SIZE);

            File folder = new File("output/ErrorInvoiceDetails");
            File[] files = folder.listFiles((dir, name) -> name.endsWith(".csv"));
            for (File file : files) {

                try (SQLServerBulkCopy bulkCopy = new SQLServerBulkCopy(dbConnecton.getMssqlConnection());
                        SQLServerBulkCSVFileRecord fileRecord = new SQLServerBulkCSVFileRecord(
                                file.getPath(),
                                null, ",", true);) {
                    // Initialize the CSV file record
                    fileRecord.setEscapeColumnDelimitersCSV(true);

                    // Add column metadata
                    fileRecord.addColumnMetadata(1, "Pnr", java.sql.Types.VARCHAR, 10, 0);
                    fileRecord.addColumnMetadata(2, "Invoicenumber", java.sql.Types.VARCHAR, 16, 0);
                    fileRecord.addColumnMetadata(3, Constants.GOODS_SERVICES_TYPE, java.sql.Types.VARCHAR, 50, 0);
                    fileRecord.addColumnMetadata(4, "ErrorID", java.sql.Types.INTEGER, 10, 0);
                    fileRecord.addColumnMetadata(5, "Local Currency", java.sql.Types.VARCHAR, 6, 0);
                    fileRecord.addColumnMetadata(6, Constants.TRANSACTION_DATE, java.sql.Types.DATE, 0, 0);
                    fileRecord.addColumnMetadata(7, Constants.IS_CORRECT, java.sql.Types.INTEGER, 10, 0);
                    fileRecord.addColumnMetadata(8, "reasonIds", java.sql.Types.VARCHAR, 1000, 0);
                    fileRecord.addColumnMetadata(9, "errorDescription", java.sql.Types.VARCHAR, 1000, 0);
                    fileRecord.addColumnMetadata(10, "tranType", java.sql.Types.VARCHAR, 255, 0);
                    fileRecord.addColumnMetadata(11, "Id", java.sql.Types.VARCHAR, 64, 0);

                    // Perform bulk copy
                    SQLServerBulkCopyOptions copyOptions = new SQLServerBulkCopyOptions();
                    // copyOptions.setBatchSize(50000);
                    copyOptions.setBulkCopyTimeout(0);
                    // copyOptions.setTableLock(true);
                    bulkCopy.setBulkCopyOptions(copyOptions);
                    bulkCopy.setDestinationTableName("ErrorInvoiceDetails_CS");
                    bulkCopy.writeToServer(fileRecord);
                    log.info("Bulk copy operation completed successfully for errorInvoiceDetails: {}", file.getName());
                }

            }

        } catch (SQLException sqlEx) {
            log.error("SQL error occurred during errorInvoiceDetails: {}", sqlEx.getMessage(), sqlEx);
            throw sqlEx; // Re-throw SQL exceptions
        } catch (Exception ex) {
            log.error("Unexpected error during errorInvoiceDetails: {}", ex.getMessage(), ex);
            throw ex; // Re-throw unexpected exceptions
        } finally {
            log.info("errorInvoiceDetails process finished.");
        }
    }

    @Transactional
    @Retry(maxRetries = 3, delay = 5000, retryOn = {
            SQLTimeoutException.class, // SQL timeout exception (transient)
            SQLTransientConnectionException.class, // Transient database connection issues
            SQLTransientException.class, // General transient SQL errors
            SQLRecoverableException.class, // Recoverable SQL issues during runtime
            SocketTimeoutException.class // Transient network timeout issues
    })
    public void preErrorUpdate(List<String> listIdes) throws Exception {

        log.info("Starting update errorPNRRecord" + listIdes.size());
        String updateQueryWhenFix = "DELETE ErrorPNRRecords_CS  WHERE ID = ?";
        String updateQueryWhenStillError = "UPDATE ErrorPNRRecords_CS SET  OriginCountry = ?, Sector = ?, [Full Itinerary Route] = ?, ReasonID = ? WHERE ID = ?";

        try (Connection con = dbConnecton.getMssqlConnection();
                PreparedStatement updateStmt = con.prepareStatement(updateQueryWhenStillError);
                PreparedStatement updateStmtCorrect = con.prepareStatement(updateQueryWhenFix);) {
            splitCsvFile("input/ErrorPNRRecord.csv", ERROR_PNR_OUT_FOLDER, Constants.OUTPUT, BATCH_SIZE);

            String query = "SELECT OriginCountry, Sector, \"Full Itinerary Route\" ,ReasonID FROM read_csv_auto('input/ErrorPNRRecord.csv') WHERE ID = '1?'";
            Connection conn = DriverManager.getConnection("jdbc:duckdb:");

            Statement stmt = conn.createStatement();

            for (String id : listIdes) {
                try {

                    String finalQuery = query.replace("1?", id);
                    System.out.println(finalQuery);

                    ResultSet resultSet = stmt.executeQuery(finalQuery);

                    if (resultSet.next()) {
                        updateStmt.setString(1, resultSet.getString("OriginCountry"));
                        updateStmt.setString(2, resultSet.getString("Sector"));
                        updateStmt.setString(3, resultSet.getString("Full Itinerary Route"));
                        updateStmt.setString(4, resultSet.getString("ReasonID"));
                        updateStmt.setString(5, id);
                        updateStmt.addBatch();
                    } else {
                        updateStmtCorrect.setString(1, id);
                        updateStmtCorrect.addBatch();

                    }
                } catch (SQLException e) {
                    String errorMessage = e.getMessage();
                    if (errorMessage.contains("Binder Error: Referenced column \"ID\" not found in FROM clause!")) {
                        log.info("Skipping specific SQL exception: " + errorMessage);
                        updateStmtCorrect.setString(1, id);
                        updateStmtCorrect.addBatch();
                        // Handle gracefully: log or take alternative action
                    } else {
                        throw e; // Re-throw other SQLExceptions
                    }
                }
            }
            int[] stillError = updateStmt.executeBatch();
            int[] corrected = updateStmtCorrect.executeBatch();
            log.info("Corrected-> {}, Not Corrected-> {}", corrected.length, stillError.length);

            stmt.close();
            conn.close();

        } catch (SQLException sqlEx) {

            log.error("SQL error occurred during errorPNRRecord update: {}", sqlEx.getMessage(), sqlEx);
            throw sqlEx; // Re-throw SQL exceptions

        } catch (Exception ex) {
            log.error("Unexpected error during errorPNRRecord update: {}", ex.getMessage(), ex);
            throw ex; // Re-throw unexpected exceptions
        } finally {
            log.info("errorPNRRecord update process finished.");
        }
        log.info("completed completed------------------");
    }

    @Transactional
    @Retry(maxRetries = 3, delay = 5000, retryOn = {
            SQLTimeoutException.class, // SQL timeout exception (transient)
            SQLTransientConnectionException.class, // Transient database connection issues
            SQLTransientException.class, // General transient SQL errors
            SQLRecoverableException.class, // Recoverable SQL issues during runtime
            SocketTimeoutException.class // Transient network timeout issues
    })
    public void errorPNRRecord(String requestId) throws Exception {
        log.info("Starting errorPNRRecord");

        try {
            splitCsvFile("input/ErrorPNRRecord.csv", ERROR_PNR_OUT_FOLDER, Constants.OUTPUT, BATCH_SIZE);

            File folder = new File(ERROR_PNR_OUT_FOLDER);
            File[] files = folder.listFiles((dir, name) -> name.endsWith(".csv"));
            int totalFiles = files.length;
            if (totalFiles == 0) {
                updatePercentage(10);
            } else {
                for (File file : files) {
                    // Initialize the CSV file record

                    try (SQLServerBulkCopy bulkCopy = new SQLServerBulkCopy(dbConnecton.getMssqlConnection());
                            SQLServerBulkCSVFileRecord fileRecord = new SQLServerBulkCSVFileRecord(
                                    file.getPath(),
                                    null, ",", true);) {
                        fileRecord.setEscapeColumnDelimitersCSV(true);
                        // Adding column metadata
                        fileRecord.addColumnMetadata(1, "Original Booking Date", java.sql.Types.NVARCHAR, 50, 0);
                        fileRecord.addColumnMetadata(2, "Transaction Date", java.sql.Types.NVARCHAR, 50, 0);
                        fileRecord.addColumnMetadata(3, "Flight Date", java.sql.Types.NVARCHAR, 50, 0);
                        fileRecord.addColumnMetadata(4, "Flight Number", java.sql.Types.INTEGER, 10, 0);
                        fileRecord.addColumnMetadata(5, "Description of Goods/Services", java.sql.Types.NVARCHAR, 255,
                                0);
                        fileRecord.addColumnMetadata(6, "SAC", java.sql.Types.INTEGER, 10, 0);
                        fileRecord.addColumnMetadata(7, "PNR", java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(8, "Full Itinerary Route", java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(9, "Sector", java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(10, "Place of Embarkation", java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(11, "Customer GSTIN", java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(12, "Customer Name", java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(13, "Email Address", java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(14, "Customer GST Registration State", java.sql.Types.NVARCHAR,
                                255,
                                0);
                        fileRecord.addColumnMetadata(15, "6E GSTIN", java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(16, "6E RegisteredAddress", java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(17, "Base Fare", java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(18, "Taxable Fare Component", java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(19, "Non-Taxable Fare Component", java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(20, "SSR Fee Code", java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(21, "SSR Component", java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(22, "Taxable Component", java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(23, "CGST Amount", java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(24, "IGST Amount", java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(25, "SGST Amount", java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(26, "UGST Amount", java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(27, "FileName", java.sql.Types.NVARCHAR, 100, 0);
                        fileRecord.addColumnMetadata(28, "Path", java.sql.Types.NVARCHAR, 500, 0);
                        fileRecord.addColumnMetadata(29, "GST Holder Name", java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(30, "GST Email Address", java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(31, "Local Currency", java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(32, "Local Base Fare", java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(33, "Local Taxable Fare Component", java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(34, "Local Non-Taxable Fare Component", java.sql.Types.FLOAT, 15,
                                0);
                        fileRecord.addColumnMetadata(35, "Local SSR Component", java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(36, "Local Taxable Component", java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(37, "Local CGST Amount", java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(38, "Local IGST Amount", java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(39, "Local SGST Amount", java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(40, "Local UGST Amount", java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(41, Constants.AIRPORT_CHARGES, java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(42, "LocalAirportCharges", java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(43, Constants.ORIGIN_COUNTRY, java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(44, Constants.IS_EXEMPTED, java.sql.Types.BIT, 1, 0);
                        fileRecord.addColumnMetadata(45, Constants.NUMBER_TYPE, java.sql.Types.VARCHAR, 3, 0);
                        fileRecord.addColumnMetadata(46, Constants.REASON_ID, java.sql.Types.VARCHAR, 100, 0);
                        fileRecord.addColumnMetadata(47, Constants.CREATED_BY, java.sql.Types.VARCHAR, 50, 0);
                        fileRecord.addColumnMetadata(48, "CreatedDate", java.sql.Types.TIMESTAMP, 0, 0);
                        fileRecord.addColumnMetadata(49, "NeedtoProcess", java.sql.Types.INTEGER, 10, 0);
                        fileRecord.addColumnMetadata(50, Constants.LOCAL_CESS_AMOUNT, java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(51, Constants.CESS_AMOUNT, java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(52, "Id", java.sql.Types.VARCHAR, 64, 0);
                        fileRecord.addColumnMetadata(53, Constants.AGENT_CODE, java.sql.Types.VARCHAR, 16, 0);

                        // Perform bulk copy
                        SQLServerBulkCopyOptions copyOptions = new SQLServerBulkCopyOptions();
                        // copyOptions.setBatchSize(50000);
                        copyOptions.setBulkCopyTimeout(0);
                        // copyOptions.setTableLock(true);
                        bulkCopy.setBulkCopyOptions(copyOptions);
                        bulkCopy.setDestinationTableName("ErrorPNRRecords_CS");
                        bulkCopy.writeToServer(fileRecord);
                        log.info("Bulk copy operation completed successfully for errorPNRRecord: {}", file.getName());

                        updatePercentage((double) 10 / (double) totalFiles);

                    }
                }
            }
        } catch (SQLException sqlEx) {
            log.error("SQL error occurred during errorPNRRecord: {}", sqlEx.getMessage(), sqlEx);
            throw sqlEx; // Re-throw SQL exceptions
        } catch (Exception ex) {
            log.error("Unexpected error during errorPNRRecord: {}", ex.getMessage(), ex);
            throw ex; // Re-throw unexpected exceptions
        } finally {
            log.info("errorPNRRecord process finished.");
        }
        log.info("completed completed------------------");
    }

    @Transactional
    @Retry(maxRetries = 3, delay = 5000, retryOn = {
            SQLTimeoutException.class, // SQL timeout exception (transient)
            SQLTransientConnectionException.class, // Transient database connection issues
            SQLTransientException.class, // General transient SQL errors
            SQLRecoverableException.class, // Recoverable SQL issues during runtime
            SocketTimeoutException.class // Transient network timeout issues
    })
    public void invoiceDWH(String requestId) throws Exception {
        log.info("Starting invoiceDWH");

        try {

            splitCsvFile("input/InvoiceDWH.csv", "output/InvoiceDWH", Constants.OUTPUT, BATCH_SIZE);

            File folder = new File("output/InvoiceDWH");
            File[] files = folder.listFiles((dir, name) -> name.endsWith(".csv"));
            int totalFiles = files.length;
            if (totalFiles == 0) {

                updatePercentage(35);

            } else {
                for (File file : files) {
                    // Initialize the CSV file record

                    try (SQLServerBulkCopy bulkCopy = new SQLServerBulkCopy(dbConnecton.getMssqlConnection());
                            SQLServerBulkCSVFileRecord fileRecord = new SQLServerBulkCSVFileRecord(
                                    file.getPath(),
                                    null, ",", true);) {
                        fileRecord.setEscapeColumnDelimitersCSV(true);
                        // Adding column metadata
                        fileRecord.addColumnMetadata(1, Constants.TRANSACTION_DATE, java.sql.Types.TIMESTAMP, 0, 0);
                        fileRecord.addColumnMetadata(2, Constants.FILE_DATE, java.sql.Types.TIMESTAMP, 0, 0);
                        fileRecord.addColumnMetadata(3, Constants.DISPLAY_DATE, java.sql.Types.TIMESTAMP, 0, 0);
                        fileRecord.addColumnMetadata(4, Constants.FLIGHT_NUMBER, java.sql.Types.INTEGER, 10, 0);
                        fileRecord.addColumnMetadata(5, Constants.GOODS_SERVICES_TYPE, java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(6, "SAC", java.sql.Types.INTEGER, 10, 0);
                        fileRecord.addColumnMetadata(7, "InvoiceNumber", java.sql.Types.NVARCHAR, 50, 0);
                        fileRecord.addColumnMetadata(8, "SequenceNo", java.sql.Types.INTEGER, 10, 0);
                        fileRecord.addColumnMetadata(9, "PNR", java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(10, "Dep", java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(11, "Arr", java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(12, Constants.PLACE_OF_EMBARKATION, java.sql.Types.NVARCHAR, 255,
                                0);
                        fileRecord.addColumnMetadata(13, Constants.STATE_CODE, java.sql.Types.VARCHAR, 2, 0);
                        fileRecord.addColumnMetadata(14, Constants.CUSTOMER_GSTIN, java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(15, Constants.CUSTOMER_NAME, java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(16, Constants.EMAIL_ADDRESS, java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(17, Constants.CUSTOMER_GST_REGISTRATION_STATE,
                                java.sql.Types.NVARCHAR,
                                255, 0);
                        fileRecord.addColumnMetadata(18, Constants.PASSENGER_NAME, java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(19, Constants.PASSENGER_EMAIL, java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(20, Constants.E6_GSTIN, java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(21, Constants.E6_REGISTERED_ADDRESS, java.sql.Types.NVARCHAR, 255,
                                0);
                        fileRecord.addColumnMetadata(22, Constants.NON_TAXABLE_FARE_COMPONENT, java.sql.Types.FLOAT, 15,
                                0);
                        fileRecord.addColumnMetadata(23, Constants.TAXABLE_COMPONENT, java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(24, Constants.CGST_AMOUNT, java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(25, Constants.IGST_AMOUNT, java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(26, Constants.SGST_AMOUNT, java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(27, Constants.UGST_AMOUNT, java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(28, "CGSTRate", java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(29, "IGSTRate", java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(30, "SGSTUGSTRate", java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(31, "IsProcessed", java.sql.Types.NVARCHAR, 50, 0);
                        fileRecord.addColumnMetadata(32, "InvOrder", java.sql.Types.SMALLINT, 10, 0);
                        fileRecord.addColumnMetadata(33, "IsCredit", java.sql.Types.SMALLINT, 10, 0);
                        fileRecord.addColumnMetadata(34, "ServiceNo", java.sql.Types.SMALLINT, 10, 0);
                        fileRecord.addColumnMetadata(35, "Mailsend", java.sql.Types.INTEGER, 10, 0);
                        fileRecord.addColumnMetadata(36, Constants.AIRPORT_CHARGES, java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(37, Constants.ORIGIN_COUNTRY, java.sql.Types.NVARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(38, Constants.IS_EXEMPTED, java.sql.Types.BIT, 1, 0);
                        fileRecord.addColumnMetadata(39, Constants.NUMBER_TYPE, java.sql.Types.BIT, 1, 0);
                        fileRecord.addColumnMetadata(40, Constants.REASON_ID, java.sql.Types.INTEGER, 10, 0);
                        fileRecord.addColumnMetadata(41, "IsError", java.sql.Types.INTEGER, 10, 0);
                        fileRecord.addColumnMetadata(42, Constants.IS_CORRECT, java.sql.Types.INTEGER, 10, 0);
                        fileRecord.addColumnMetadata(43, Constants.CREATED_BY, java.sql.Types.VARCHAR, 50, 0);
                        fileRecord.addColumnMetadata(44, "CreatedOn", java.sql.Types.TIMESTAMP, 0, 0);
                        fileRecord.addColumnMetadata(45, Constants.CESS_AMOUNT, java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(46, Constants.LOCAL_CESS_AMOUNT, java.sql.Types.FLOAT, 15, 0);
                        fileRecord.addColumnMetadata(47, "errorIds", java.sql.Types.VARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(48, "ErrorDescription", java.sql.Types.VARCHAR, 1000, 0);
                        fileRecord.addColumnMetadata(49, "ReasonIDs", java.sql.Types.VARCHAR, 1000, 0);
                        fileRecord.addColumnMetadata(50, Constants.AUTO_CORRECTION_ID, java.sql.Types.VARCHAR, 1000, 0);
                        fileRecord.addColumnMetadata(51, Constants.IS_AUTO_CORRECTED, java.sql.Types.VARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(52, Constants.SP_EXEMPTEDFLIGHT, java.sql.Types.INTEGER, 10, 0);
                        fileRecord.addColumnMetadata(53, "spInternational", java.sql.Types.INTEGER, 10, 0);
                        fileRecord.addColumnMetadata(54, "spSez", java.sql.Types.INTEGER, 10, 0);
                        fileRecord.addColumnMetadata(55, "Id", java.sql.Types.VARCHAR, 64, 0);
                        fileRecord.addColumnMetadata(56, "isSapBiError", java.sql.Types.VARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(57, "sapBiErrorIds", java.sql.Types.VARCHAR, 255, 0);
                        fileRecord.addColumnMetadata(58, "sapBiDescription", java.sql.Types.VARCHAR, 1000, 0);
                        fileRecord.addColumnMetadata(59, Constants.AGENT_CODE, java.sql.Types.VARCHAR, 16, 0);

                        // Perform bulk copy
                        bulkCopy.setDestinationTableName("Invoice_DWH_CS");
                        SQLServerBulkCopyOptions copyOptions = new SQLServerBulkCopyOptions();
                        // copyOptions.setBatchSize(50000);
                        copyOptions.setBulkCopyTimeout(0);
                        // copyOptions.setTableLock(true);
                        bulkCopy.setBulkCopyOptions(copyOptions);
                        bulkCopy.writeToServer(fileRecord);
                        log.info("Bulk copy operation completed successfully for invoiceDWH: {}", file.getName());
                        updatePercentage((double) 35 / (double) totalFiles);

                    }
                }
            }
        } catch (SQLException sqlEx) {
            log.error("SQL error occurred during invoiceDWH: {}", sqlEx.getMessage(), sqlEx);
            throw sqlEx; // Re-throw SQL exceptions
        } catch (Exception ex) {
            log.error("Unexpected error during invoiceDWH: {}", ex.getMessage(), ex);
            throw ex; // Re-throw unexpected exceptions
        } finally {
            log.info("invoiceDWH process finished.");
        }
    }

    @Transactional
    @Retry(maxRetries = 3, delay = 5000, retryOn = {
            SQLTimeoutException.class, // SQL timeout exception (transient)
            SQLTransientConnectionException.class, // Transient database connection issues
            SQLTransientException.class, // General transient SQL errors
            SQLRecoverableException.class, // Recoverable SQL issues during runtime
            SocketTimeoutException.class // Transient network timeout issues
    })
    public void updateSeries(List<InvSeries> list) throws Exception {

        if (list.isEmpty()) {
            log.info("Invoices not created for the record");
            return;
        }
        log.info("Starting bulk update or insert operation for Inv_Series_CS");

        String updateQuery = "UPDATE Inv_Series_CS SET month = ?, stateCode = ?, currentValue = ?, "
                + "maxValue = ?, active = ?, financialYear = ?, invoiceType = ? WHERE id = ?";
        String insertQuery = "INSERT INTO Inv_Series_CS (month, stateCode, currentValue, maxValue, "
                + "active, financialYear, invoiceType) VALUES (?, ?, ?, ?, ?, ?, ?)";
        // String checkQuery = "SELECT id FROM Inv_Series_CS WHERE id = ?";

        try (Connection con = dbConnecton.getMssqlConnection();
                PreparedStatement updateStmt = con.prepareStatement(updateQuery);
                PreparedStatement insertStmt = con.prepareStatement(insertQuery);
        // PreparedStatement checkStmt = con.prepareStatement(checkQuery)
        ) {

            for (InvSeries invSeries : list) {
                if (!invSeries.getIsNew()) {
                    // Check if the record exists
                    // checkStmt.setLong(1, invSeries.getId());
                    // try (ResultSet rs = checkStmt.executeQuery()) {
                    // if (rs.next()) {
                    // Prepare update batch
                    updateStmt.setString(1, invSeries.getMonth());
                    updateStmt.setString(2, invSeries.getStateCode());
                    updateStmt.setInt(3, invSeries.getCurrentValue());
                    updateStmt.setInt(4, invSeries.getMaxValue());
                    updateStmt.setInt(5, invSeries.getActive());
                    updateStmt.setInt(6, invSeries.getFinancialYear());
                    updateStmt.setString(7, invSeries.getInvoiceType());
                    updateStmt.setLong(8, invSeries.getId());
                    updateStmt.addBatch();
                } else {
                    // Prepare insert batch
                    insertStmt.setString(1, invSeries.getMonth());
                    insertStmt.setString(2, invSeries.getStateCode());
                    insertStmt.setInt(3, invSeries.getCurrentValue());
                    insertStmt.setInt(4, invSeries.getMaxValue());
                    insertStmt.setInt(5, invSeries.getActive());
                    insertStmt.setInt(6, invSeries.getFinancialYear());
                    insertStmt.setString(7, invSeries.getInvoiceType());
                    insertStmt.addBatch();
                }
                // }
            }

            // Execute batches
            int[] updateCounts = updateStmt.executeBatch();
            int[] insertCounts = insertStmt.executeBatch();

            if (updateCounts.length == 0 && insertCounts.length == 0) {
                throw new RuntimeException("Inv seriese not update");
            }

            log.info("Bulk update completed. Rows updated: {}", updateCounts.length);
            log.info("Bulk insert completed. Rows inserted: {}", insertCounts.length);

        } catch (

        SQLException sqlEx) {
            log.error("SQL error occurred during bulk update and insert: {}", sqlEx.getMessage(), sqlEx);
            throw sqlEx; // Rethrow SQL exceptions
        } catch (Exception ex) {
            log.error("Unexpected error during bulk update and insert: {}", ex.getMessage(), ex);
            throw ex; // Rethrow unexpected exceptions
        } finally {
            log.info("updateSeries process finished.");
        }
    }

    public void splitCsvFile(String inputFilePath, String outputDirectory, String fileName, int batchSize)
            throws IOException {
        // Ensure the output directory exists
        File outputDir = new File(outputDirectory);
        if (!outputDir.exists()) {
            outputDir.mkdirs(); // Create the output directory if it doesn't exist
        }
        FileWriter writer = null;
        try (BufferedReader reader = new BufferedReader(new FileReader(inputFilePath));) {
            String header = reader.readLine(); // Read the header from the input CSV file
            if (header == null) {
                throw new IOException("Input file is empty!");
            }

            String line;
            int fileCount = 0;
            int recordCount = 0;

            while ((line = reader.readLine()) != null) {
                if (recordCount % batchSize == 0) {
                    // Close the previous file writer (if any) and start a new file
                    if (writer != null) {
                        writer.close();
                    }
                    fileCount++;
                    writer = new FileWriter(new File(outputDirectory, fileName + fileCount + ".csv"));
                    writer.write(header + "\n"); // Write the header to the new file
                }
                writer.write(line + "\n");
                recordCount++;
            }

            // Close the last writer if it exists

        } catch (IOException e) {
            throw new IOException("Error while processing the CSV file: " + e.getMessage(), e);
        } finally {
            if (writer != null) {
                writer.close();
            }
        }
    }

    private void updatePercentage(double d) {
        if (!Constants.PRE_ERROR.equalsIgnoreCase(GlobalVariables.requestType)) {
            ProgressTrackerService.setPercentageCompleted(ProgressTrackerService.getPercentageCompleted()
                    + d);
        }
    }

}
