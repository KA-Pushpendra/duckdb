package in.indigo.utility;

import java.io.File;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.hibernate.ScrollMode;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.query.Query;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import in.indigo.configuration.Constants;
import in.indigo.configuration.GlobalVariables;
import in.indigo.duckRepository.AuditInvoiceDwhRepository;
import in.indigo.duckRepository.ErrorInvoiceDetailsRepository;
import in.indigo.duckRepository.ErrorPNRRecordRepository;
import in.indigo.duckRepository.InvDuckDBSeriesRepository;
import in.indigo.duckRepository.InvSkyExtractAcRepository;
import in.indigo.duckRepository.InvSkyExtractDuckDBRepository;
import in.indigo.duckRepository.InvoiceDwhRepository;
import in.indigo.mssqlEntity.InvSeries;
import in.indigo.mssqlEntity.InvSkyExtract;
import in.indigo.mssqlEntity.ProgressTracker;
import in.indigo.mssqlRepository.InvSeriesRepository;
import in.indigo.mssqlRepository.InvSkyExtractRepository;
import in.indigo.mssqlRepository.ProgressTrackerRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.context.control.ActivateRequestContext;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@ApplicationScoped
@RequiredArgsConstructor
@Slf4j
public class MssqlToDuckDBTransfer implements Processor {

    private final InvSkyExtractAcRepository invSkyExtractAcRepository;
    private final AuditInvoiceDwhRepository auditInvoiceDwhRepository;
    private final ErrorInvoiceDetailsRepository errorInvoiceDetailsRepository;
    private final ErrorPNRRecordRepository errorPNRRecordRepository;

    private final InvoiceDwhRepository invoiceDwhRepository;

    private final InvSkyExtractRepository invSkyExtractRepository;

    private final InvSkyExtractDuckDBRepository invSkyExtractDuckDBRepository;

    private final InvSeriesRepository invSeriesRepository;

    private final InvDuckDBSeriesRepository invduckdbSeriesRepository;

    private final ProgressTrackerRepository progressTrackerRepository;

    private static final int BATCH_SIZE = 10000;

    ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());

    @Override
    public void process(Exchange exchange) throws Exception {
        GlobalVariables.setAppState("ACTIVE");

        List<String> dates = Arrays.asList(exchange.getIn().getBody(String[].class));
        try {

            clearTable();
            deleteFilesOnly(new File("input"));
            deleteFilesOnly(new File("output"));

            if (!Constants.PRE_ERROR.equalsIgnoreCase(GlobalVariables.requestType)) {
                SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

                Date date = sdf.parse(dates.get(0));

                SimpleDateFormat sdfm = new SimpleDateFormat("MMMM yyyy");
                String monthName = sdfm.format(date);

                Date current = new Date(System.currentTimeMillis());
                Instant timestamp = Instant.now();
                long epochMillis = timestamp.toEpochMilli();
                String requestId = epochMillis + "_Data Prepration";
                ProgressTracker progressTracker = ProgressTracker.builder()

                        .progressPercentage(0)
                        .trackingState("Data Preparation")
                        .monthYear(monthName)
                        .lastUpdatedAt(current)
                        .requestId(requestId)
                        .build();
                progressTrackerRepository.create(progressTracker);
                processLargeData(dates, requestId);
            }
            fetchInvSeries(dates);
        } catch (Exception e) {
            log.error("Error occurred while processing the data: {}", e.getMessage(), e);
            throw new RuntimeException(Constants.PROCESSING_FAILED, e);
        }
    }

    @Transactional
    public void clearTable() {
        try {
            log.info("Clearing Duck DB");
            invSkyExtractDuckDBRepository.deleteAll();
            invduckdbSeriesRepository.deleteAll();

            auditInvoiceDwhRepository.deleteAll();
            errorInvoiceDetailsRepository.deleteAll();
            errorPNRRecordRepository.deleteAll();
            invoiceDwhRepository.deleteAll();
            invSkyExtractAcRepository.deleteAll();
        } catch (Exception e) {
            log.error("Error occurred while clearing the tables: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to clear tables", e);
        }
    }

    @ActivateRequestContext
    public void processLargeData(List<String> dates, String requestId) {

        log.info("Copping Inv_skyExtract To Duck DB" + dates);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");

        // Convert String to LocalDate
        LocalDate startDate = LocalDate.parse(dates.get(0), formatter);

        LocalDate endDate = LocalDate.parse(dates.get(1), formatter);

        Session session = invSkyExtractRepository.getEntityManager().unwrap(Session.class);
        Query<Long> countQuery = session.createQuery(
                "SELECT COUNT(*) FROM InvSkyExtract WHERE CAST(transactionDate AS DATE) BETWEEN :date1 and :date2",
                Long.class);
        countQuery.setParameter("date1", startDate);
        countQuery.setParameter("date2", endDate);
        Long count = countQuery.getSingleResult();
        int recordsProsessed = 0;
        double percentageCompleted = 0;
        Query<InvSkyExtract> query = session.createQuery(
                "FROM InvSkyExtract WHERE CAST(transactionDate AS DATE) BETWEEN :date1 and :date2",
                InvSkyExtract.class);
        query.setParameter("date1", startDate);
        query.setParameter("date2", endDate);

        query.setFetchSize(BATCH_SIZE); // Adjust the fetch size as needed
        ScrollableResults<InvSkyExtract> scrollableResults = query.scroll(ScrollMode.FORWARD_ONLY);
        List<InvSkyExtract> batch = new ArrayList<>();

        try {
            while (scrollableResults.next()) {
                if (!"ACTIVE".equals(GlobalVariables.appState)) {
                    break;
                }
                batch.add(scrollableResults.get());
                if (batch.size() >= BATCH_SIZE) {

                    List<in.indigo.duckdbEntity.InvSkyExtract> invSkyExtractDuck = objectMapper.convertValue(batch,
                            new TypeReference<List<in.indigo.duckdbEntity.InvSkyExtract>>() {
                            });
                    processInvSkyExtractAsync(invSkyExtractDuck);
                    recordsProsessed = recordsProsessed + batch.size();
                    System.out.println("records Prosessed: " + recordsProsessed);
                    batch.clear();
                    session.clear();
                    percentageCompleted = ((recordsProsessed) / (double) count) * 100;
                    progressTrackerRepository.updateTracker(requestId, percentageCompleted);
                    System.out.println("============================>percentageCompleted: " + percentageCompleted);
                }

            }
            if (!batch.isEmpty()) {
                List<in.indigo.duckdbEntity.InvSkyExtract> invSkyExtractDuck = objectMapper.convertValue(batch,
                        new TypeReference<List<in.indigo.duckdbEntity.InvSkyExtract>>() {
                        });
                recordsProsessed = recordsProsessed + batch.size();
                processInvSkyExtractAsync(invSkyExtractDuck);
                percentageCompleted = ((recordsProsessed) / (double) count) * 100;
                progressTrackerRepository.updateTracker(requestId, percentageCompleted);
                System.out.println("records Prosessed: " + recordsProsessed);
                System.out.println("============================>percentageCompleted: " + percentageCompleted);
            }
        } catch (Exception e) {
            System.err.println(e.getMessage());
            throw new RuntimeException("unable to fetch data from db");
        } finally {
            scrollableResults.close();
        }
    }

    @Transactional
    public void processInvSkyExtractAsync(List<in.indigo.duckdbEntity.InvSkyExtract> invSkyExtracts) {
        ExecutorService executor = Executors.newFixedThreadPool(10); // Adjust the thread pool size as needed

        try {
            // log.info("Starting asynchronous processing of invSkyExtracts");

            CompletableFuture<Void> future = CompletableFuture
                    .runAsync(() -> processInvSkyExtract(invSkyExtracts), executor)
                    .exceptionally(e -> {
                        log.error("Error occurred during asynchronous processing of invSkyExtract: {}", e.getMessage());
                        throw new RuntimeException(Constants.PROCESSING_FAILED, e);
                    });

            // Block and wait for the completion of all tasks
            future.join();

        } catch (Exception e) {
            log.error("Halting further calls due to error: {}", e.getMessage());
            executor.shutdown();
            throw new RuntimeException(Constants.PROCESSING_FAILED, e);
        } finally {
            executor.shutdown();
        }
    }

    @Transactional
    public void processInvSkyExtract(List<in.indigo.duckdbEntity.InvSkyExtract> invSkyExtractDuck) {

        try {
            invSkyExtractDuckDBRepository.persist(invSkyExtractDuck);
        } catch (Exception e) {
            System.err.println(e.getMessage());
            throw new RuntimeException("unable to fetch data from db");

        }
    }

    // @Transactional
    @ActivateRequestContext
    public void fetchInvSeries(List<String> dates) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        List<Integer> financialYears = new ArrayList<>();
        for (String dateStr : dates) {
            LocalDate date = LocalDate.parse(dateStr, formatter);

            int month = date.getMonthValue();

            int currentYear = date.getYear();
            int previousYear = currentYear - 1;
            int nextYear = currentYear + 1;

            String financialYear;
            if (month > 3) {
                financialYear = String.format("%02d%02d", currentYear % 100, nextYear % 100);
            } else {
                financialYear = String.format("%02d%02d", previousYear % 100, currentYear % 100);
            }
            financialYears.add(Integer.valueOf(financialYear));
        }
        log.info("Copping Inv_Series To Duck DB");
        Session session = invSeriesRepository.getEntityManager().unwrap(Session.class);

        Query<InvSeries> query = session.createQuery(
                "FROM InvSeries WHERE financialYear IN :FY", InvSeries.class)
                .setParameter("FY", financialYears);

        query.setFetchSize(BATCH_SIZE); // Adjust the fetch size as needed
        ScrollableResults<InvSeries> scrollableResults = query.scroll(ScrollMode.FORWARD_ONLY);
        List<InvSeries> batch = new ArrayList<>();

        try {
            while (scrollableResults.next()) {
                if (!"ACTIVE".equals(GlobalVariables.appState)) {
                    break;
                }
                batch.add(scrollableResults.get());
                if (batch.size() >= BATCH_SIZE) {
                    System.out.println("Processing batch of size: " + batch.size());

                    List<in.indigo.duckdbEntity.InvSeries> invSeries = objectMapper.convertValue(batch,
                            new TypeReference<List<in.indigo.duckdbEntity.InvSeries>>() {
                            });
                    processInvSeriesAsync(invSeries);
                    batch.clear();
                    session.clear();
                }

            }
            if (!batch.isEmpty()) {
                List<in.indigo.duckdbEntity.InvSeries> invSeries = objectMapper.convertValue(batch,
                        new TypeReference<List<in.indigo.duckdbEntity.InvSeries>>() {
                        });
                processInvSeriesAsync(invSeries);
            }
        } catch (Exception e) {
            System.err.println(e.getMessage());
            throw new RuntimeException("unable to fetch data from db");
        } finally {
            scrollableResults.close();
        }
    }

    @Transactional
    public void processInvSeriesAsync(List<in.indigo.duckdbEntity.InvSeries> invSeriess) {
        ExecutorService executor = Executors.newFixedThreadPool(10); // Adjust the thread pool size as needed

        try {
            // log.info("Starting asynchronous processing of InvSeries");

            // Asynchronously process the batches
            CompletableFuture<Void> future = CompletableFuture.runAsync(() -> proceesInvSeriese(invSeriess), executor)
                    .exceptionally(e -> {
                        log.error("Error occurred during asynchronous processing of InvSeries: {}", e.getMessage());
                        throw new RuntimeException(Constants.PROCESSING_FAILED, e);
                    });

            // Block and wait for the completion of all tasks
            future.join();

            // log.info("Completed asynchronous processing of InvSeries");
        } catch (Exception e) {
            log.error("Halting further calls due to error: {}", e.getMessage());
            executor.shutdown();
            throw new RuntimeException(Constants.PROCESSING_FAILED, e);
        } finally {
            executor.shutdown();
        }
    }

    @Transactional
    public void proceesInvSeriese(List<in.indigo.duckdbEntity.InvSeries> invSeriess) {

        try {
            invduckdbSeriesRepository.persist(invSeriess);
        } catch (Exception e) {
            System.err.println(e.getMessage());
            throw new RuntimeException("unable to fetch data from db");
        }
    }

    public static void deleteFilesOnly(File directory) {
        // Validate if the given path is a directory
        if (directory.exists() && directory.isDirectory()) {
            File[] files = directory.listFiles(); // List all files and subdirectories
            if (files != null) {
                for (File file : files) {
                    if (file.isFile()) {
                        file.delete();
                    } else if (file.isDirectory()) {
                        // Recursively delete files inside the subdirectory
                        deleteFilesOnly(file);
                    }
                }
            }
        } else {
            System.out.println("Invalid directory: " + directory.getAbsolutePath());
        }
    }

    // @Override
    // public void process(Exchange exchange) throws Exception {
    // // TODO Auto-generated method stub
    // throw new UnsupportedOperationException("Unimplemented method 'process'");
    // }

}
