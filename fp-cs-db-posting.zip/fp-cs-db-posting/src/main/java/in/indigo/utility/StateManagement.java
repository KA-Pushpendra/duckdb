package in.indigo.utility;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.transaction.Transactional;
import lombok.Data;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;

import in.indigo.mssqlRepository.AuditInvoiceDwhRepository;
import in.indigo.mssqlRepository.ErrorInvoiceDetailsRepository;
import in.indigo.mssqlRepository.ErrorPNRRecordRepository;
import in.indigo.mssqlRepository.InvSkyExtractAcRepository;
import in.indigo.mssqlRepository.InvoiceDwhmssqlRepository;
import in.indigo.mssqlRepository.InvoiceProcessLogRepository;
import in.indigo.mssqlRepository.MstInvoiceTransactionDetailsRepository;
import in.indigo.mssqlRepository.ProgressTrackerRepository;
import in.indigo.configuration.Constants;
import in.indigo.configuration.GlobalVariables;
import in.indigo.mssqlEntity.InvoiceProcessLog;
import in.indigo.mssqlEntity.MstInvoiceTransactionDetails;
import in.indigo.mssqlEntity.ProgressTracker;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

@Data
@RequiredArgsConstructor
@Slf4j
@ApplicationScoped
@Getter
@Setter
public class StateManagement {

    private final MstInvoiceTransactionDetailsRepository mstInvoiceTransactionDetailsRepository;

    private final InvSkyExtractAcRepository invSkyExtractAcRepository;
    private final AuditInvoiceDwhRepository auditInvoiceDwhRepository;
    private final ErrorInvoiceDetailsRepository errorInvoiceDetailsRepository;
    private final ErrorPNRRecordRepository errorPNRRecordRepository;
    private final ProgressTrackerRepository progressTrackerRepository;
    private final InvoiceDwhmssqlRepository invoiceDwhRepository;

    private final InvoiceProcessLogRepository invoiceProcessLogRepository;

    private LocalDate transactionDateStart;
    private LocalDate transactionDateEnd;
    private String user;

    public void resetState() {
        transactionDateStart = null;
        transactionDateEnd = null;
        user = null;
    }

    @Transactional
    public synchronized void initiateProcess(Exchange exchange) throws ParseException {

        List<String> dates = Arrays.asList(exchange.getIn().getHeader("dateList", String[].class));
        user = exchange.getIn().getHeader("user", String.class);

        Function<String, Date> getSqlDate = (d) -> {

            try {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yyyy");

                LocalDate localDate = LocalDate.parse(d, formatter);

                return Date.valueOf(localDate);
            } catch (Exception e) {
                log.error("error while parsing date--------->", e);

                return null;
            }

        };

        Function<String, LocalDate> getLocalDate = (d) -> {
            try {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yyyy");

                return LocalDate.parse(d, formatter);

            } catch (Exception e) {
                log.error("error while parsing date--------->", e);

                return null;
            }
        };

        // Date sqlStartDate = getSqlDate.apply(dates.get(0));
        // Date sqlEndDate = getSqlDate.apply(dates.get(1));

        transactionDateStart = getLocalDate.apply(dates.get(0));
        transactionDateEnd = getLocalDate.apply(dates.get(1));
        YearMonth yearMonth = YearMonth.from(transactionDateStart);

        // Predicate<LocalDate> isErrorInMstInvoiceTransactionDetails = date1 ->
        // mstInvoiceTransactionDetailsRepository
        // .findByTransactionDate(date1)
        // .stream()
        // .anyMatch(d -> d.getIsError() == 1);

        // if (isErrorInMstInvoiceTransactionDetails.test(getLocalDate.apply(date))) {
        // exchange.getIn()
        // .setBody("Please contact to administrator, transaction date= " + date + "
        // having the Error");
        // GlobalVariables.setRequestType("NONE");
        // return;
        // }

        Predicate<YearMonth> isErrorInMstInvoiceTransactionDetails = ym -> mstInvoiceTransactionDetailsRepository
                .findByDateRange(transactionDateStart, transactionDateEnd)
                .stream()
                .anyMatch(d -> d.getIsError() == 1);

        Predicate<YearMonth> isInvoiceAlreadyInitiated = ym -> !invoiceProcessLogRepository
                .getInvoiceStatusByDateRange(Date.valueOf(transactionDateStart), Date.valueOf(transactionDateEnd),
                        "Invoice Processing")
                .isEmpty();

        if (isErrorInMstInvoiceTransactionDetails.test(yearMonth)) {
            // ApiResponse<?> res = new ApiResponse<>(null, false, );
            exchange.getIn()
                    .setBody("Please contact the administrator, transaction month= " + yearMonth + " having the Error");
            GlobalVariables.setRequestType("NONE");
            return;
        }

        boolean approvalPending = mstInvoiceTransactionDetailsRepository
                .findByDateRange(transactionDateStart, transactionDateEnd)
                .stream()
                .filter(d -> d.getInvoiceStatus().equalsIgnoreCase("approval pending"))
                .findAny().isEmpty();

        if (approvalPending) {

            exchange.getIn().setBody("There is no data which has approval pending status");
            GlobalVariables.setRequestType("NONE");
            return;
        }

        if (isInvoiceAlreadyInitiated.test(yearMonth)) {
            // ApiResponse<?> res = new ApiResponse<>(null, false, "SP: UDP_InvoiceCreation
            // is already processed for transaction month = " + yearMonth);
            exchange.getIn()
                    .setBody("SP: UDP_InvoiceCreation is already processed for transaction month = " + yearMonth);
            GlobalVariables.setRequestType("NONE");
            return;
        }

        Date start = new Date(System.currentTimeMillis());

        InvoiceProcessLog obj = new InvoiceProcessLog();

        obj.setProcessStatus("Initiated");
        obj.setCreatedBy(user);
        obj.setStartDate(start);

        InvoiceProcessLog.persist(obj);

        MstInvoiceTransactionDetails.update(
                "invoiceStatus = ?1, isApproved = ?2 where transactionDate between ?3 and ?4", "Invoice Processing", 1,
                transactionDateStart, transactionDateEnd);
    }

    @Transactional
    public synchronized void markCompleteInInvoiceTransaction() {

        LocalDate localDate = LocalDate.now(ZoneId.of(Constants.TIME_ZONE));
        LocalDateTime endDate = localDate.atStartOfDay(); // Convert to LocalDateTime

        InvoiceProcessLog.update(
                "processStatus = 'Complete', endDate = ?1, createdBy = ?2 where processStatus = 'Initiated'",
                endDate, user);

        MstInvoiceTransactionDetails.update(
                "isInvCreation = 1, invoiceStatus = ?1, modifiedBy = ?2, modifiedDate = ?3 where transactionDate between ?4 and ?5",
                "Invoicing Complete", user, endDate, transactionDateStart, transactionDateEnd);

        // InvoiceProcessLog.update(
        // "processStatus = 'Complete', endDate = ?1, createdBy = ?2 where
        // transactionDate = ?3 AND processStatus = 'Initiated'",
        // Date.valueOf(endDate), user, transactionDate);

        // MstInvoiceTransactionDetails.update(
        // "isInvCreation = 1, invoiceStatus = ?1, modifiedBy = ?2, modifiedDate = ?3
        // where transactionDate = ?4",
        // "Invoicing Complete", user, Date.valueOf(endDate), transactionDate);

        resetState();

    }

    @Transactional
    public synchronized void markErrorInInvoiceTransaction() {
        if (transactionDateStart != null && transactionDateEnd != null) {
            LocalDate localDate = LocalDate.now(); // Example LocalDate
            LocalDateTime modifiedDate = localDate.atStartOfDay();

            InvoiceProcessLog.update("processStatus = 'Error', endDate = ?1 where processStatus = 'Initiated'",
                    modifiedDate);

            MstInvoiceTransactionDetails.update(
                    "isError = 1, invoiceStatus = 'Error while Processing', modifiedBy = ?1, modifiedDate = ?2 where transactionDate between ?3 and ?4",
                    user, modifiedDate, transactionDateStart, transactionDateEnd);
            deleteRecordFromMsql();
            resetState();
        } else {
            log.error("Can Not update state: Transaction dates is null");
        }
    }

    @Transactional
    public void deleteRecordFromMsql() {
        log.info("Clearing mssql on error while while processing DB");
        String query = "CAST(transactionDate AS DATE)  BETWEEN ?1 AND ?2";

        LocalDateTime start = transactionDateStart.atStartOfDay();
        LocalDateTime end = transactionDateEnd.atStartOfDay();

        auditInvoiceDwhRepository.delete(query,
                transactionDateStart, transactionDateEnd);

        errorInvoiceDetailsRepository.delete(query,
                transactionDateStart, transactionDateEnd);

        errorPNRRecordRepository.delete(query,
                transactionDateStart, transactionDateEnd);

        invoiceDwhRepository.delete(query,
                transactionDateStart, transactionDateEnd);

        invSkyExtractAcRepository.delete(query,
                transactionDateStart, transactionDateEnd);

        java.util.Date date = Date.from(transactionDateStart.atStartOfDay(ZoneId.systemDefault()).toInstant());

        // Format to "MMMM yyyy"
        SimpleDateFormat sdfm = new SimpleDateFormat("MMMM yyyy");
        String formattedDate = sdfm.format(date);
        progressTrackerRepository.delete("monthYear = ?1", formattedDate);
        //

    }

    @Transactional
    public void updateInvoiceStatusOnStartup(Exchange exchange) {

        LocalDate modifiedDate = LocalDate.now(ZoneId.of(Constants.TIME_ZONE));

        MstInvoiceTransactionDetails.update(
                "isError = 1, invoiceStatus = 'Error while Processing', modifiedBy = 'System', modifiedDate = ?1 where invoiceStatus = ?2",
                Date.valueOf(modifiedDate), "Invoice Processing");
        ProgressTracker progressTracker = progressTrackerRepository.find("progressPercentage < ?1", 100).firstResult();

        if (progressTracker != null) {
            progressTrackerRepository.delete("monthYear = ?1", progressTracker.getMonthYear());
        }
    }

}