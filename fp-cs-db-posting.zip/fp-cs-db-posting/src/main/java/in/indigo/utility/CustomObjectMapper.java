package in.indigo.utility;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.io.IOException;

import com.fasterxml.jackson.databind.JsonDeserializer;

public class CustomObjectMapper {
    public static ObjectMapper createObjectMapper() {
        ObjectMapper mapper = new ObjectMapper().registerModule(new JavaTimeModule());
        SimpleModule module = new SimpleModule();
        module.addDeserializer(String.class, new JsonDeserializer<>() {
            @Override
            public String deserialize(com.fasterxml.jackson.core.JsonParser parser,
                    com.fasterxml.jackson.databind.DeserializationContext context)
                    throws IOException {
                String value = parser.getText();
                return (value == null || value.trim().isEmpty()) ? null : value;
            }
        });
        mapper.registerModule(module);
        return mapper;
    }
}
