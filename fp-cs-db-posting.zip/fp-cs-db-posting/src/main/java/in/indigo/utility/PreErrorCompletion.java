// package in.indigo.utility;

// import java.io.BufferedReader;
// import java.io.File;
// import java.io.FileReader;
// import java.io.FileWriter;
// import java.io.IOException;
// import java.net.SocketTimeoutException;
// import java.sql.Connection;
// import java.sql.PreparedStatement;
// import java.sql.ResultSet;
// import java.sql.SQLException;
// import java.sql.SQLRecoverableException;
// import java.sql.SQLTimeoutException;
// import java.sql.SQLTransientConnectionException;
// import java.sql.SQLTransientException;
// import java.sql.Statement;
// import java.util.ArrayList;
// import java.util.List;

// import org.eclipse.microprofile.config.inject.ConfigProperty;
// import org.eclipse.microprofile.faulttolerance.Retry;

// import com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord;
// import com.microsoft.sqlserver.jdbc.SQLServerBulkCopy;
// import com.microsoft.sqlserver.jdbc.SQLServerBulkCopyOptions;

// import in.indigo.configuration.Constants;
// import in.indigo.configuration.DbConnecton;
// import in.indigo.duckdbEntity.InvSeries;
// import jakarta.enterprise.context.ApplicationScoped;
// import jakarta.transaction.Transactional;
// import lombok.RequiredArgsConstructor;
// import lombok.extern.slf4j.Slf4j;

// @ApplicationScoped
// @Slf4j

// @RequiredArgsConstructor
// public class PreErrorCompletion {

//     private final DbConnecton dbConnecton;

//     private final in.indigo.mssqlRepository.ErrorPNRRecordRepository errorPNRRecordRepositorymssql;

//     @ConfigProperty(name = "Inv_SkyExtract_Ac_CS_view")
//     private String inv_SkyExtract_Ac_CS_view;

//     @ConfigProperty(name = "Audit_invoice_DWH_CS_view")
//     private String audit_invoice_DWH_CS_view;

//     @ConfigProperty(name = "ErrorInvoiceDetails_CS_view")
//     private String errorInvoiceDetails_CS_view;

//     @ConfigProperty(name = "ErrorPNRRecords_CS_view")
//     private String errorPNRRecords_CS_view;

//     @ConfigProperty(name = "Invoice_DWH_CS_view")
//     private String invoice_DWH_CS_view;

//     private static final int BATCH_SIZE = 20000;

//     @Transactional
//     public void preErrorpostCompletion(List<String> listIdes) throws Exception {
//         try {
//             File outputDir = new File("input");
//             if (!outputDir.exists()) {
//                 outputDir.mkdirs();
//             }
//             TransferData(listIdes);
//             updateSeries(getInvSeries());
//         } catch (Exception e) {

//             log.error("An error occurred during pre-error-postCompletion: {}", e.getMessage(), e);
//             throw e;
//         }
//     }
// //
//     @Transactional
//     @Retry(maxRetries = 3, delay = 5000, retryOn = {
//             SQLTimeoutException.class, // SQL timeout exception (transient)
//             SQLTransientConnectionException.class, // Transient database connection issues
//             SQLTransientException.class, // General transient SQL errors
//             SQLRecoverableException.class, // Recoverable SQL issues during runtime
//             SocketTimeoutException.class // Transient network timeout issues
//     })

//     public void TransferData(List<String> listIdes) throws Exception {

//         try (Statement smt = dbConnecton.getDuckDbConnection().createStatement()) {

//             log.info("Start view creation");
//             smt.execute(inv_SkyExtract_Ac_CS_view);
//             smt.execute(audit_invoice_DWH_CS_view);
//             smt.execute(errorInvoiceDetails_CS_view);
//             smt.execute(errorPNRRecords_CS_view);
//             smt.execute(invoice_DWH_CS_view);
//             log.info("End view creation");

//             log.info("Start CSV creation");
//             smt.execute(
//                     "COPY Inv_SkyExtract_Ac_CS_view TO 'input/InvSkyExtractAc.csv' (FORMAT CSV, HEADER true, DELIMITER ',',QUOTE '\"')");
//             smt.execute(
//                     "COPY audit_invoice_DWH_CS_view TO 'input/AuditInvoiceDWH.csv' (FORMAT CSV, HEADER true, DELIMITER ',',QUOTE '\"')");
//             smt.execute(
//                     "COPY errorInvoiceDetails_CS_view TO 'input/ErrorInvoiceDetails.csv' (FORMAT CSV, HEADER true, DELIMITER ',',QUOTE '\"')");
//             smt.execute(
//                     "COPY errorPNRRecords_CS_view TO 'input/ErrorPNRRecord.csv' (FORMAT CSV, HEADER true, DELIMITER ',',QUOTE '\"')");
//             smt.execute(
//                     "COPY invoice_DWH_CS_view TO 'input/InvoiceDWH.csv' (FORMAT CSV, HEADER true, DELIMITER ',',QUOTE '\"')");
//             log.info("End CSV creation");

//             invSkyExtractAc();
//             auditInvoiceDWH();
//             errorInvoiceDetails();

//             // if ("PRE_ERROR".equalsIgnoreCase(GlobalVariables.requestType)) {
//             // errorPNRRecordRepositorymssql.deleteError(listIdes);
//             // }
//             errorPNRRecord(listIdes);

//             invoiceDWH();
//             log.info("Completed successfully");

//         } catch (Exception e) {
//             log.error("An error occurred during TransferData: {}", e.getMessage(), e);
//             throw e;
//         }
//     }

//     @Transactional
//     @Retry(maxRetries = 3, delay = 5000, retryOn = {
//             SQLTimeoutException.class, // SQL timeout exception (transient)
//             SQLTransientConnectionException.class, // Transient database connection issues
//             SQLTransientException.class, // General transient SQL errors
//             SQLRecoverableException.class, // Recoverable SQL issues during runtime
//             SocketTimeoutException.class // Transient network timeout issues
//     })
//     public List<InvSeries> getInvSeries() throws Exception {
//         String query = "SELECT * FROM Inv_Series_CS"; // Adjust the query based on your database schema
//         List<InvSeries> invSeriesList = new ArrayList<>();

//         try (PreparedStatement stmt = dbConnecton.getDuckDbConnection().prepareStatement(query);
//                 ResultSet rs = stmt.executeQuery()) {

//             log.info("Fetching Inv Series");

//             while (rs.next()) {
//                 InvSeries invSeries = new InvSeries();
//                 invSeries.setId(rs.getInt("ID"));
//                 invSeries.setSeries(rs.getString("Series"));
//                 invSeries.setStateCode(rs.getString(Constants.STATE_CODE));
//                 invSeries.setCurrentValue(rs.getInt("CurrentValue"));
//                 invSeries.setMaxValue(rs.getInt("MaxValue"));
//                 invSeries.setActive(rs.getInt("Active"));
//                 invSeries.setFinancialYear(rs.getInt("FinancialYear"));
//                 invSeries.setInvoiceType(rs.getString("InvoiceType"));
//                 invSeries.setIsNew(rs.getBoolean("isNew"));
//                 invSeriesList.add(invSeries);
//             }

//         } catch (Exception e) {
//             log.error("An error occurred while fetching Inv Series: {}", e.getMessage(), e);
//             throw e; // Re-throw the exception as-is, without converting its type
//         }

//         return invSeriesList;
//     }

//     @Transactional
//     @Retry(maxRetries = 3, delay = 5000, retryOn = {
//             SQLTimeoutException.class, // SQL timeout exception (transient)
//             SQLTransientConnectionException.class, // Transient database connection issues
//             SQLTransientException.class, // General transient SQL errors
//             SQLRecoverableException.class, // Recoverable SQL issues during runtime
//             SocketTimeoutException.class // Transient network timeout issues
//     })

//     public void invSkyExtractAc() throws Exception {
//         log.info("Starting invSkyExtractAc");

//         // Try-With-Resources ensures proper closing of resources
//         try {

//             splitCsvFile("input/InvSkyExtractAc.csv", "output/InvSkyExtractAc", Constants.OUTPUT, BATCH_SIZE);

//             File folder = new File("output/InvSkyExtractAc");
//             File[] files = folder.listFiles((dir, name) -> name.endsWith(".csv"));
//             for (File file : files) {

//                 try (SQLServerBulkCSVFileRecord fileRecord = new SQLServerBulkCSVFileRecord(
//                         file.getPath(),
//                         null, ",", true);
//                         SQLServerBulkCopy bulkCopy = new SQLServerBulkCopy(dbConnecton.getMssqlConnection());) {
//                     fileRecord.setEscapeColumnDelimitersCSV(true);
//                     // Adding column metadata
//                     fileRecord.addColumnMetadata(1, Constants.TRANSACTION_DATE, java.sql.Types.TIMESTAMP, 0, 0);
//                     fileRecord.addColumnMetadata(2, Constants.FILE_DATE, java.sql.Types.TIMESTAMP, 0, 0);
//                     fileRecord.addColumnMetadata(3, Constants.DISPLAY_DATE, java.sql.Types.TIMESTAMP, 0, 0);
//                     fileRecord.addColumnMetadata(4, Constants.FLIGHT_NUMBER, java.sql.Types.INTEGER, 10, 0);
//                     fileRecord.addColumnMetadata(5, Constants.GOODS_SERVICES_TYPE, java.sql.Types.NVARCHAR,
//                             Integer.MAX_VALUE, 0);
//                     fileRecord.addColumnMetadata(6, "SAC", java.sql.Types.INTEGER, 10, 0);
//                     fileRecord.addColumnMetadata(7, "PNR", java.sql.Types.NVARCHAR, 50, 0);
//                     fileRecord.addColumnMetadata(8, "Dep", java.sql.Types.NVARCHAR, 50, 0);
//                     fileRecord.addColumnMetadata(9, "Arr", java.sql.Types.NVARCHAR, 50, 0);
//                     fileRecord.addColumnMetadata(10, Constants.PLACE_OF_EMBARKATION, java.sql.Types.NVARCHAR, 100, 0);
//                     fileRecord.addColumnMetadata(11, Constants.STATE_CODE, java.sql.Types.VARCHAR, 10, 0);
//                     fileRecord.addColumnMetadata(12, Constants.CUSTOMER_GSTIN, java.sql.Types.NVARCHAR, 50, 0);
//                     fileRecord.addColumnMetadata(13, Constants.CUSTOMER_NAME, java.sql.Types.NVARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(14, Constants.EMAIL_ADDRESS, java.sql.Types.NVARCHAR, 100, 0);
//                     fileRecord.addColumnMetadata(15, Constants.CUSTOMER_GST_REGISTRATION_STATE, java.sql.Types.NVARCHAR,
//                             50, 0);
//                     fileRecord.addColumnMetadata(16, Constants.PASSENGER_NAME, java.sql.Types.NVARCHAR, 100, 0);
//                     fileRecord.addColumnMetadata(17, Constants.PASSENGER_EMAIL, java.sql.Types.NVARCHAR, 100, 0);
//                     fileRecord.addColumnMetadata(18, Constants.E6_GSTIN, java.sql.Types.NVARCHAR, 50, 0);
//                     fileRecord.addColumnMetadata(19, Constants.E6_REGISTERED_ADDRESS, java.sql.Types.NVARCHAR, 250, 0);
//                     fileRecord.addColumnMetadata(20, Constants.NON_TAXABLE_FARE_COMPONENT, java.sql.Types.FLOAT, 15, 0);
//                     fileRecord.addColumnMetadata(21, Constants.TAXABLE_COMPONENT, java.sql.Types.FLOAT, 15, 0);
//                     fileRecord.addColumnMetadata(22, Constants.CGST_AMOUNT, java.sql.Types.FLOAT, 15, 0);
//                     fileRecord.addColumnMetadata(23, Constants.IGST_AMOUNT, java.sql.Types.FLOAT, 15, 0);
//                     fileRecord.addColumnMetadata(24, Constants.SGST_AMOUNT, java.sql.Types.FLOAT, 15, 0);
//                     fileRecord.addColumnMetadata(25, Constants.UGST_AMOUNT, java.sql.Types.FLOAT, 15, 0);
//                     fileRecord.addColumnMetadata(26, Constants.AIRPORT_CHARGES, java.sql.Types.FLOAT, 15, 0);
//                     fileRecord.addColumnMetadata(27, Constants.ORIGIN_COUNTRY, java.sql.Types.NVARCHAR, 50, 0);
//                     fileRecord.addColumnMetadata(28, Constants.IS_EXEMPTED, java.sql.Types.BIT, 1, 0);
//                     fileRecord.addColumnMetadata(29, "Cess Amount", java.sql.Types.FLOAT, 15, 0);
//                     fileRecord.addColumnMetadata(30, "Local Cess Amount", java.sql.Types.FLOAT, 15, 0);
//                     fileRecord.addColumnMetadata(31, Constants.IS_AUTO_CORRECTED, java.sql.Types.VARCHAR, 10, 0);
//                     fileRecord.addColumnMetadata(32, "Id", java.sql.Types.VARCHAR, 64, 0);
//                     fileRecord.addColumnMetadata(33, "spExemptedFlight", java.sql.Types.INTEGER, 10, 0);
//                     fileRecord.addColumnMetadata(34, "spInternational", java.sql.Types.INTEGER, 10, 0);
//                     fileRecord.addColumnMetadata(35, Constants.AUTO_CORRECTION_ID, java.sql.Types.VARCHAR, 1000, 0);
//                     fileRecord.addColumnMetadata(36, Constants.AGENT_CODE, java.sql.Types.VARCHAR, 4, 0);

//                     // Bulk copy initialization

//                     SQLServerBulkCopyOptions copyOptions = new SQLServerBulkCopyOptions();
//                     // copyOptions.setBatchSize(50000);
//                     copyOptions.setBulkCopyTimeout(0);
//                     // copyOptions.setTableLock(true);

//                     bulkCopy.setBulkCopyOptions(copyOptions);
//                     bulkCopy.setDestinationTableName("Inv_SkyExtract_Ac_CS");

//                     bulkCopy.writeToServer(fileRecord);

//                 }
//                 log.info("Bulk copy operation completed successfully: {}", file.getName());
//             }

//         } catch (SQLException sqlEx) {
//             log.error("SQL error occurred during invSkyExtractAc operation: {}", sqlEx.getMessage(), sqlEx);
//             throw sqlEx; // Re-throwing SQL exception for handling upstream
//         } catch (Exception e) {
//             log.error("An error occurred during invSkyExtractAc operation: {}", e.getMessage(), e);
//             throw e; // Re-throwing any unexpected exception
//         } finally {
//             log.info("invSkyExtractAc process finished.");
//         }
//     }

//     @Transactional
//     @Retry(maxRetries = 3, delay = 5000, retryOn = {
//             SQLTimeoutException.class, // SQL timeout exception (transient)
//             SQLTransientConnectionException.class, // Transient database connection issues
//             SQLTransientException.class, // General transient SQL errors
//             SQLRecoverableException.class, // Recoverable SQL issues during runtime
//             SocketTimeoutException.class // Transient network timeout issues
//     })
//     public void auditInvoiceDWH() throws Exception {
//         log.info("Starting auditInvoiceDWH");

//         try {
//             splitCsvFile("input/AuditInvoiceDWH.csv", "output/AuditInvoiceDWH", Constants.OUTPUT, BATCH_SIZE);

//             File folder = new File("output/AuditInvoiceDWH");
//             File[] files = folder.listFiles((dir, name) -> name.endsWith(".csv"));
//             for (File file : files) {
//                 try (SQLServerBulkCopy bulkCopy = new SQLServerBulkCopy(dbConnecton.getMssqlConnection());
//                         SQLServerBulkCSVFileRecord fileRecord = new SQLServerBulkCSVFileRecord(
//                                 file.getPath(),
//                                 null, ",", true);) {
//                     // Initialize the CSV file record
//                     fileRecord.setEscapeColumnDelimitersCSV(true);

//                     // Adding column metadata
//                     fileRecord.addColumnMetadata(1, "AuditID", java.sql.Types.INTEGER, 4, 0);
//                     fileRecord.addColumnMetadata(2, Constants.TRANSACTION_DATE, java.sql.Types.TIMESTAMP, 0, 0);
//                     fileRecord.addColumnMetadata(3, Constants.FILE_DATE, java.sql.Types.TIMESTAMP, 0, 0);
//                     fileRecord.addColumnMetadata(4, Constants.DISPLAY_DATE, java.sql.Types.TIMESTAMP, 0, 0);
//                     fileRecord.addColumnMetadata(5, Constants.FLIGHT_NUMBER, java.sql.Types.INTEGER, 10, 0);
//                     fileRecord.addColumnMetadata(6, Constants.GOODS_SERVICES_TYPE, java.sql.Types.NVARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(7, "SAC", java.sql.Types.INTEGER, 10, 0);
//                     fileRecord.addColumnMetadata(8, "InvoiceNumber", java.sql.Types.NVARCHAR, 50, 0);
//                     fileRecord.addColumnMetadata(9, "SequenceNo", java.sql.Types.INTEGER, 10, 0);
//                     fileRecord.addColumnMetadata(10, "PNR", java.sql.Types.NVARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(11, "Dep", java.sql.Types.NVARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(12, "Arr", java.sql.Types.NVARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(13, Constants.PLACE_OF_EMBARKATION, java.sql.Types.NVARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(14, Constants.STATE_CODE, java.sql.Types.VARCHAR, 2, 0);
//                     fileRecord.addColumnMetadata(15, Constants.CUSTOMER_GSTIN, java.sql.Types.NVARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(16, Constants.CUSTOMER_NAME, java.sql.Types.NVARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(17, Constants.EMAIL_ADDRESS, java.sql.Types.NVARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(18, Constants.CUSTOMER_GST_REGISTRATION_STATE, java.sql.Types.NVARCHAR,
//                             255, 0);
//                     fileRecord.addColumnMetadata(19, Constants.PASSENGER_NAME, java.sql.Types.NVARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(20, Constants.PASSENGER_EMAIL, java.sql.Types.NVARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(21, Constants.E6_GSTIN, java.sql.Types.NVARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(22, Constants.E6_REGISTERED_ADDRESS, java.sql.Types.NVARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(23, Constants.NON_TAXABLE_FARE_COMPONENT, java.sql.Types.FLOAT, 15, 0);
//                     fileRecord.addColumnMetadata(24, Constants.TAXABLE_COMPONENT, java.sql.Types.FLOAT, 15, 0);
//                     fileRecord.addColumnMetadata(25, Constants.CGST_AMOUNT, java.sql.Types.FLOAT, 15, 0);
//                     fileRecord.addColumnMetadata(26, Constants.IGST_AMOUNT, java.sql.Types.FLOAT, 15, 0);
//                     fileRecord.addColumnMetadata(27, Constants.SGST_AMOUNT, java.sql.Types.FLOAT, 15, 0);
//                     fileRecord.addColumnMetadata(28, Constants.UGST_AMOUNT, java.sql.Types.FLOAT, 15, 0);
//                     fileRecord.addColumnMetadata(29, "CGSTRate", java.sql.Types.FLOAT, 15, 0);
//                     fileRecord.addColumnMetadata(30, "IGSTRate", java.sql.Types.FLOAT, 15, 0);
//                     fileRecord.addColumnMetadata(31, "SGSTUGSTRate", java.sql.Types.FLOAT, 15, 0);
//                     fileRecord.addColumnMetadata(32, "IsProcessed", java.sql.Types.NVARCHAR, 50, 0);
//                     fileRecord.addColumnMetadata(33, "InvOrder", java.sql.Types.SMALLINT, 10, 0);
//                     fileRecord.addColumnMetadata(34, "IsCredit", java.sql.Types.SMALLINT, 10, 0);
//                     fileRecord.addColumnMetadata(35, "ServiceNo", java.sql.Types.SMALLINT, 10, 0);
//                     fileRecord.addColumnMetadata(36, "CreatedBy", java.sql.Types.NVARCHAR, 250, 0);
//                     fileRecord.addColumnMetadata(37, "CreatedDate", java.sql.Types.TIMESTAMP, 0, 0);
//                     fileRecord.addColumnMetadata(38, Constants.NUMBER_TYPE, java.sql.Types.BIT, 1, 0);
//                     fileRecord.addColumnMetadata(39, Constants.REASON_ID, java.sql.Types.INTEGER, 10, 0);
//                     fileRecord.addColumnMetadata(40, "Mailsend", java.sql.Types.INTEGER, 10, 0);
//                     fileRecord.addColumnMetadata(41, Constants.AIRPORT_CHARGES, java.sql.Types.FLOAT, 15, 0);
//                     fileRecord.addColumnMetadata(42, Constants.ORIGIN_COUNTRY, java.sql.Types.NVARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(43, Constants.IS_EXEMPTED, java.sql.Types.BIT, 1, 0);
//                     fileRecord.addColumnMetadata(44, "IsError", java.sql.Types.INTEGER, 10, 0);
//                     fileRecord.addColumnMetadata(45, Constants.IS_CORRECT, java.sql.Types.INTEGER, 10, 0);
//                     fileRecord.addColumnMetadata(46, "CreatedOn", java.sql.Types.TIMESTAMP, 0, 0);
//                     fileRecord.addColumnMetadata(47, "Cess Amount", java.sql.Types.FLOAT, 15, 0);
//                     fileRecord.addColumnMetadata(48, "Local Cess Amount", java.sql.Types.FLOAT, 15, 0);
//                     fileRecord.addColumnMetadata(49, "errorIds", java.sql.Types.VARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(50, "ErrorDescription", java.sql.Types.VARCHAR, 1000, 0);
//                     fileRecord.addColumnMetadata(51, "ReasonIDs", java.sql.Types.VARCHAR, 1000, 0);
//                     fileRecord.addColumnMetadata(52, Constants.AUTO_CORRECTION_ID, java.sql.Types.VARCHAR, 1000, 0);
//                     fileRecord.addColumnMetadata(53, Constants.IS_AUTO_CORRECTED, java.sql.Types.VARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(54, "spExemptedFlight", java.sql.Types.INTEGER, 10, 0);
//                     fileRecord.addColumnMetadata(55, "spInternatoinal", java.sql.Types.INTEGER, 10, 0);
//                     fileRecord.addColumnMetadata(56, "spSez", java.sql.Types.INTEGER, 10, 0);
//                     fileRecord.addColumnMetadata(57, "Id", java.sql.Types.VARCHAR, 64, 0);
//                     fileRecord.addColumnMetadata(58, Constants.AGENT_CODE, java.sql.Types.VARCHAR, 4, 0);

//                     // Bulk copy process

//                     SQLServerBulkCopyOptions copyOptions = new SQLServerBulkCopyOptions();
//                     // copyOptions.setBatchSize(50000);
//                     copyOptions.setBulkCopyTimeout(0);
//                     // copyOptions.setTableLock(true);
//                     bulkCopy.setBulkCopyOptions(copyOptions);
//                     bulkCopy.setDestinationTableName("Audit_invoice_DWH_CS");
//                     bulkCopy.writeToServer(fileRecord);

//                 }
//                 log.info("Bulk copy operation completed successfully: {}", file.getName());
//             }
//         } catch (SQLException sqlEx) {
//             log.error("SQL error occurred during auditInvoiceDWH: {}", sqlEx.getMessage(), sqlEx);
//             throw sqlEx; // Re-throw SQL exceptions
//         } catch (Exception ex) {
//             log.error("Unexpected error during auditInvoiceDWH: {}", ex.getMessage(), ex);
//             throw ex; // Re-throw unexpected exceptions
//         } finally {
//             log.info("auditInvoiceDWH process finished.");
//         }
//     }

//     @Transactional
//     @Retry(maxRetries = 3, delay = 5000, retryOn = {
//             SQLTimeoutException.class, // SQL timeout exception (transient)
//             SQLTransientConnectionException.class, // Transient database connection issues
//             SQLTransientException.class, // General transient SQL errors
//             SQLRecoverableException.class, // Recoverable SQL issues during runtime
//             SocketTimeoutException.class // Transient network timeout issues
//     })
//     public void errorInvoiceDetails() throws Exception {
//         log.info("Starting errorInvoiceDetails");

//         try {
//             splitCsvFile("input/ErrorInvoiceDetails.csv", "output/ErrorInvoiceDetails", Constants.OUTPUT, BATCH_SIZE);

//             File folder = new File("output/ErrorInvoiceDetails");
//             File[] files = folder.listFiles((dir, name) -> name.endsWith(".csv"));
//             for (File file : files) {

//                 try (SQLServerBulkCopy bulkCopy = new SQLServerBulkCopy(dbConnecton.getMssqlConnection());
//                         SQLServerBulkCSVFileRecord fileRecord = new SQLServerBulkCSVFileRecord(
//                                 file.getPath(),
//                                 null, ",", true);) {
//                     // Initialize the CSV file record
//                     fileRecord.setEscapeColumnDelimitersCSV(true);

//                     // Add column metadata
//                     fileRecord.addColumnMetadata(1, "Pnr", java.sql.Types.VARCHAR, 10, 0);
//                     fileRecord.addColumnMetadata(2, "Invoicenumber", java.sql.Types.VARCHAR, 16, 0);
//                     fileRecord.addColumnMetadata(3, Constants.GOODS_SERVICES_TYPE, java.sql.Types.VARCHAR, 50, 0);
//                     fileRecord.addColumnMetadata(4, "ErrorID", java.sql.Types.INTEGER, 10, 0);
//                     fileRecord.addColumnMetadata(5, "Local Currency", java.sql.Types.VARCHAR, 6, 0);
//                     fileRecord.addColumnMetadata(6, Constants.TRANSACTION_DATE, java.sql.Types.DATE, 0, 0);
//                     fileRecord.addColumnMetadata(7, Constants.IS_CORRECT, java.sql.Types.INTEGER, 10, 0);
//                     fileRecord.addColumnMetadata(8, "reasonIds", java.sql.Types.VARCHAR, 1000, 0);
//                     fileRecord.addColumnMetadata(9, "errorDescription", java.sql.Types.VARCHAR, 1000, 0);
//                     fileRecord.addColumnMetadata(10, "tranType", java.sql.Types.VARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(11, "Id", java.sql.Types.VARCHAR, 64, 0);

//                     // Perform bulk copy
//                     SQLServerBulkCopyOptions copyOptions = new SQLServerBulkCopyOptions();
//                     // copyOptions.setBatchSize(50000);
//                     copyOptions.setBulkCopyTimeout(0);
//                     // copyOptions.setTableLock(true);
//                     bulkCopy.setBulkCopyOptions(copyOptions);
//                     bulkCopy.setDestinationTableName("ErrorInvoiceDetails_CS");
//                     bulkCopy.writeToServer(fileRecord);
//                     log.info("Bulk copy operation completed successfully for errorInvoiceDetails: {}", file.getName());
//                 }

//             }

//         } catch (SQLException sqlEx) {
//             log.error("SQL error occurred during errorInvoiceDetails: {}", sqlEx.getMessage(), sqlEx);
//             throw sqlEx; // Re-throw SQL exceptions
//         } catch (Exception ex) {
//             log.error("Unexpected error during errorInvoiceDetails: {}", ex.getMessage(), ex);
//             throw ex; // Re-throw unexpected exceptions
//         } finally {
//             log.info("errorInvoiceDetails process finished.");
//         }
//     }

//     @Transactional
//     @Retry(maxRetries = 3, delay = 5000, retryOn = {
//             SQLTimeoutException.class, // SQL timeout exception (transient)
//             SQLTransientConnectionException.class, // Transient database connection issues
//             SQLTransientException.class, // General transient SQL errors
//             SQLRecoverableException.class, // Recoverable SQL issues during runtime
//             SocketTimeoutException.class // Transient network timeout issues
//     })
//     public void errorPNRRecord(List<String> idList) throws Exception {
//         log.info("Starting errorInvoiceDetails");

//         try {
//             errorPNRRecordRepositorymssql.deleteError(idList);
//             splitCsvFile("input/ErrorInvoiceDetails.csv", "output/ErrorInvoiceDetails", Constants.OUTPUT, BATCH_SIZE);

//             File folder = new File("output/ErrorInvoiceDetails");
//             File[] files = folder.listFiles((dir, name) -> name.endsWith(".csv"));
//             for (File file : files) {

//                 try (SQLServerBulkCopy bulkCopy = new SQLServerBulkCopy(dbConnecton.getMssqlConnection());
//                         SQLServerBulkCSVFileRecord fileRecord = new SQLServerBulkCSVFileRecord(
//                                 file.getPath(),
//                                 null, ",", true);) {
//                     // Initialize the CSV file record
//                     fileRecord.setEscapeColumnDelimitersCSV(true);

//                     // Add column metadata
//                     fileRecord.addColumnMetadata(1, "Pnr", java.sql.Types.VARCHAR, 10, 0);
//                     fileRecord.addColumnMetadata(2, "Invoicenumber", java.sql.Types.VARCHAR, 16, 0);
//                     fileRecord.addColumnMetadata(3, Constants.GOODS_SERVICES_TYPE, java.sql.Types.VARCHAR, 50, 0);
//                     fileRecord.addColumnMetadata(4, "ErrorID", java.sql.Types.INTEGER, 10, 0);
//                     fileRecord.addColumnMetadata(5, "Local Currency", java.sql.Types.VARCHAR, 6, 0);
//                     fileRecord.addColumnMetadata(6, Constants.TRANSACTION_DATE, java.sql.Types.DATE, 0, 0);
//                     fileRecord.addColumnMetadata(7, Constants.IS_CORRECT, java.sql.Types.INTEGER, 10, 0);
//                     fileRecord.addColumnMetadata(8, "reasonIds", java.sql.Types.VARCHAR, 1000, 0);
//                     fileRecord.addColumnMetadata(9, "errorDescription", java.sql.Types.VARCHAR, 1000, 0);
//                     fileRecord.addColumnMetadata(10, "tranType", java.sql.Types.VARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(11, "Id", java.sql.Types.VARCHAR, 64, 0);

//                     // Perform bulk copy
//                     SQLServerBulkCopyOptions copyOptions = new SQLServerBulkCopyOptions();
//                     // copyOptions.setBatchSize(50000);
//                     copyOptions.setBulkCopyTimeout(0);
//                     // copyOptions.setTableLock(true);
//                     bulkCopy.setBulkCopyOptions(copyOptions);
//                     bulkCopy.setDestinationTableName("ErrorInvoiceDetails_CS");
//                     bulkCopy.writeToServer(fileRecord);
//                     log.info("Bulk copy operation completed successfully for errorInvoiceDetails: {}", file.getName());
//                 }

//             }

//         } catch (SQLException sqlEx) {
//             log.error("SQL error occurred during errorInvoiceDetails: {}", sqlEx.getMessage(), sqlEx);
//             throw sqlEx; // Re-throw SQL exceptions
//         } catch (Exception ex) {
//             log.error("Unexpected error during errorInvoiceDetails: {}", ex.getMessage(), ex);
//             throw ex; // Re-throw unexpected exceptions
//         } finally {
//             log.info("errorInvoiceDetails process finished.");
//         }
//     }

//     @Transactional
//     @Retry(maxRetries = 3, delay = 5000, retryOn = {
//             SQLTimeoutException.class, // SQL timeout exception (transient)
//             SQLTransientConnectionException.class, // Transient database connection issues
//             SQLTransientException.class, // General transient SQL errors
//             SQLRecoverableException.class, // Recoverable SQL issues during runtime
//             SocketTimeoutException.class // Transient network timeout issues
//     })
//     public void invoiceDWH() throws Exception {
//         log.info("Starting invoiceDWH");

//         try {

//             splitCsvFile("input/InvoiceDWH.csv", "output/InvoiceDWH", Constants.OUTPUT, BATCH_SIZE);

//             File folder = new File("output/InvoiceDWH");
//             File[] files = folder.listFiles((dir, name) -> name.endsWith(".csv"));
//             for (File file : files) {
//                 // Initialize the CSV file record

//                 try (SQLServerBulkCopy bulkCopy = new SQLServerBulkCopy(dbConnecton.getMssqlConnection());
//                         SQLServerBulkCSVFileRecord fileRecord = new SQLServerBulkCSVFileRecord(
//                                 file.getPath(),
//                                 null, ",", true);) {
//                     fileRecord.setEscapeColumnDelimitersCSV(true);
//                     // Adding column metadata
//                     fileRecord.addColumnMetadata(1, Constants.TRANSACTION_DATE, java.sql.Types.TIMESTAMP, 0, 0);
//                     fileRecord.addColumnMetadata(2, Constants.FILE_DATE, java.sql.Types.TIMESTAMP, 0, 0);
//                     fileRecord.addColumnMetadata(3, Constants.DISPLAY_DATE, java.sql.Types.TIMESTAMP, 0, 0);
//                     fileRecord.addColumnMetadata(4, Constants.FLIGHT_NUMBER, java.sql.Types.INTEGER, 10, 0);
//                     fileRecord.addColumnMetadata(5, Constants.GOODS_SERVICES_TYPE, java.sql.Types.NVARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(6, "SAC", java.sql.Types.INTEGER, 10, 0);
//                     fileRecord.addColumnMetadata(7, "InvoiceNumber", java.sql.Types.NVARCHAR, 50, 0);
//                     fileRecord.addColumnMetadata(8, "SequenceNo", java.sql.Types.INTEGER, 10, 0);
//                     fileRecord.addColumnMetadata(9, "PNR", java.sql.Types.NVARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(10, "Dep", java.sql.Types.NVARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(11, "Arr", java.sql.Types.NVARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(12, Constants.PLACE_OF_EMBARKATION, java.sql.Types.NVARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(13, Constants.STATE_CODE, java.sql.Types.VARCHAR, 2, 0);
//                     fileRecord.addColumnMetadata(14, Constants.CUSTOMER_GSTIN, java.sql.Types.NVARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(15, Constants.CUSTOMER_NAME, java.sql.Types.NVARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(16, Constants.EMAIL_ADDRESS, java.sql.Types.NVARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(17, Constants.CUSTOMER_GST_REGISTRATION_STATE, java.sql.Types.NVARCHAR,
//                             255, 0);
//                     fileRecord.addColumnMetadata(18, Constants.PASSENGER_NAME, java.sql.Types.NVARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(19, Constants.PASSENGER_EMAIL, java.sql.Types.NVARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(20, Constants.E6_GSTIN, java.sql.Types.NVARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(21, Constants.E6_REGISTERED_ADDRESS, java.sql.Types.NVARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(22, Constants.NON_TAXABLE_FARE_COMPONENT, java.sql.Types.FLOAT, 15, 0);
//                     fileRecord.addColumnMetadata(23, Constants.TAXABLE_COMPONENT, java.sql.Types.FLOAT, 15, 0);
//                     fileRecord.addColumnMetadata(24, Constants.CGST_AMOUNT, java.sql.Types.FLOAT, 15, 0);
//                     fileRecord.addColumnMetadata(25, Constants.IGST_AMOUNT, java.sql.Types.FLOAT, 15, 0);
//                     fileRecord.addColumnMetadata(26, Constants.SGST_AMOUNT, java.sql.Types.FLOAT, 15, 0);
//                     fileRecord.addColumnMetadata(27, Constants.UGST_AMOUNT, java.sql.Types.FLOAT, 15, 0);
//                     fileRecord.addColumnMetadata(28, "CGSTRate", java.sql.Types.FLOAT, 15, 0);
//                     fileRecord.addColumnMetadata(29, "IGSTRate", java.sql.Types.FLOAT, 15, 0);
//                     fileRecord.addColumnMetadata(30, "SGSTUGSTRate", java.sql.Types.FLOAT, 15, 0);
//                     fileRecord.addColumnMetadata(31, "IsProcessed", java.sql.Types.NVARCHAR, 50, 0);
//                     fileRecord.addColumnMetadata(32, "InvOrder", java.sql.Types.SMALLINT, 10, 0);
//                     fileRecord.addColumnMetadata(33, "IsCredit", java.sql.Types.SMALLINT, 10, 0);
//                     fileRecord.addColumnMetadata(34, "ServiceNo", java.sql.Types.SMALLINT, 10, 0);
//                     fileRecord.addColumnMetadata(35, "Mailsend", java.sql.Types.INTEGER, 10, 0);
//                     fileRecord.addColumnMetadata(36, Constants.AIRPORT_CHARGES, java.sql.Types.FLOAT, 15, 0);
//                     fileRecord.addColumnMetadata(37, Constants.ORIGIN_COUNTRY, java.sql.Types.NVARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(38, Constants.IS_EXEMPTED, java.sql.Types.BIT, 1, 0);
//                     fileRecord.addColumnMetadata(39, Constants.NUMBER_TYPE, java.sql.Types.BIT, 1, 0);
//                     fileRecord.addColumnMetadata(40, Constants.REASON_ID, java.sql.Types.INTEGER, 10, 0);
//                     fileRecord.addColumnMetadata(41, "IsError", java.sql.Types.INTEGER, 10, 0);
//                     fileRecord.addColumnMetadata(42, Constants.IS_CORRECT, java.sql.Types.INTEGER, 10, 0);
//                     fileRecord.addColumnMetadata(43, "CreatedBy", java.sql.Types.VARCHAR, 50, 0);
//                     fileRecord.addColumnMetadata(44, "CreatedOn", java.sql.Types.TIMESTAMP, 0, 0);
//                     fileRecord.addColumnMetadata(45, "Cess Amount", java.sql.Types.FLOAT, 15, 0);
//                     fileRecord.addColumnMetadata(46, "Local Cess Amount", java.sql.Types.FLOAT, 15, 0);
//                     fileRecord.addColumnMetadata(47, "errorIds", java.sql.Types.VARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(48, "ErrorDescription", java.sql.Types.VARCHAR, 1000, 0);
//                     fileRecord.addColumnMetadata(49, "ReasonIDs", java.sql.Types.VARCHAR, 1000, 0);
//                     fileRecord.addColumnMetadata(50, Constants.AUTO_CORRECTION_ID, java.sql.Types.VARCHAR, 1000, 0);
//                     fileRecord.addColumnMetadata(51, Constants.IS_AUTO_CORRECTED, java.sql.Types.VARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(52, "spExemptedFlight", java.sql.Types.INTEGER, 10, 0);
//                     fileRecord.addColumnMetadata(53, "spInternational", java.sql.Types.INTEGER, 10, 0);
//                     fileRecord.addColumnMetadata(54, "spSez", java.sql.Types.INTEGER, 10, 0);
//                     fileRecord.addColumnMetadata(55, "Id", java.sql.Types.VARCHAR, 64, 0);
//                     fileRecord.addColumnMetadata(56, "isSapBiError", java.sql.Types.VARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(57, "sapBiErrorIds", java.sql.Types.VARCHAR, 255, 0);
//                     fileRecord.addColumnMetadata(58, "sapBiDescription", java.sql.Types.VARCHAR, 1000, 0);
//                     fileRecord.addColumnMetadata(59, Constants.AGENT_CODE, java.sql.Types.VARCHAR, 4, 0);

//                     // Perform bulk copy
//                     bulkCopy.setDestinationTableName("Invoice_DWH_CS");
//                     SQLServerBulkCopyOptions copyOptions = new SQLServerBulkCopyOptions();
//                     // copyOptions.setBatchSize(50000);
//                     copyOptions.setBulkCopyTimeout(0);
//                     // copyOptions.setTableLock(true);
//                     bulkCopy.setBulkCopyOptions(copyOptions);
//                     bulkCopy.writeToServer(fileRecord);
//                     log.info("Bulk copy operation completed successfully for invoiceDWH: {}", file.getName());
//                 }
//             }
//         } catch (SQLException sqlEx) {
//             log.error("SQL error occurred during invoiceDWH: {}", sqlEx.getMessage(), sqlEx);
//             throw sqlEx; // Re-throw SQL exceptions
//         } catch (Exception ex) {
//             log.error("Unexpected error during invoiceDWH: {}", ex.getMessage(), ex);
//             throw ex; // Re-throw unexpected exceptions
//         } finally {
//             log.info("invoiceDWH process finished.");
//         }
//     }

//     @Transactional
//     @Retry(maxRetries = 3, delay = 5000, retryOn = {
//             SQLTimeoutException.class, // SQL timeout exception (transient)
//             SQLTransientConnectionException.class, // Transient database connection issues
//             SQLTransientException.class, // General transient SQL errors
//             SQLRecoverableException.class, // Recoverable SQL issues during runtime
//             SocketTimeoutException.class // Transient network timeout issues
//     })
//     public void updateSeries(List<InvSeries> list) throws Exception {
//         log.info("Starting bulk update or insert operation for Inv_Series_CS");

//         String updateQuery = "UPDATE Inv_Series_CS SET series = ?, stateCode = ?, currentValue = ?, "
//                 + "maxValue = ?, active = ?, financialYear = ?, invoiceType = ? WHERE id = ?";
//         String insertQuery = "INSERT INTO Inv_Series_CS (series, stateCode, currentValue, maxValue, "
//                 + "active, financialYear, invoiceType) VALUES (?, ?, ?, ?, ?, ?, ?)";
//         // String checkQuery = "SELECT id FROM Inv_Series_CS WHERE id = ?";

//         try (Connection con = dbConnecton.getMssqlConnection();
//                 PreparedStatement updateStmt = con.prepareStatement(updateQuery);
//                 PreparedStatement insertStmt = con.prepareStatement(insertQuery);

//         ) {

//             for (InvSeries invSeries : list) {
//                 if (!invSeries.getIsNew()) {

//                     updateStmt.setString(1, invSeries.getSeries());
//                     updateStmt.setString(2, invSeries.getStateCode());
//                     updateStmt.setInt(3, invSeries.getCurrentValue());
//                     updateStmt.setInt(4, invSeries.getMaxValue());
//                     updateStmt.setInt(5, invSeries.getActive());
//                     updateStmt.setInt(6, invSeries.getFinancialYear());
//                     updateStmt.setString(7, invSeries.getInvoiceType());
//                     updateStmt.setLong(8, invSeries.getId());
//                     updateStmt.addBatch();
//                 } else {
//                     // Prepare insert batch
//                     insertStmt.setString(1, invSeries.getSeries());
//                     insertStmt.setString(2, invSeries.getStateCode());
//                     insertStmt.setInt(3, invSeries.getCurrentValue());
//                     insertStmt.setInt(4, invSeries.getMaxValue());
//                     insertStmt.setInt(5, invSeries.getActive());
//                     insertStmt.setInt(6, invSeries.getFinancialYear());
//                     insertStmt.setString(7, invSeries.getInvoiceType());
//                     insertStmt.addBatch();
//                 }

//             }

//             int[] updateCounts = updateStmt.executeBatch();
//             int[] insertCounts = insertStmt.executeBatch();

//             if (updateCounts.length == 0 && insertCounts.length == 0) {
//                 throw new RuntimeException("Inv seriese not update");
//             }

//             log.info("Bulk update completed. Rows updated: {}", updateCounts.length);
//             log.info("Bulk insert completed. Rows inserted: {}", insertCounts.length);

//         } catch (

//         SQLException sqlEx) {
//             log.error("SQL error occurred during bulk update and insert: {}", sqlEx.getMessage(), sqlEx);
//             throw sqlEx; // Rethrow SQL exceptions
//         } catch (Exception ex) {
//             log.error("Unexpected error during bulk update and insert: {}", ex.getMessage(), ex);
//             throw ex; // Rethrow unexpected exceptions
//         } finally {
//             log.info("updateSeries process finished.");
//         }
//     }

//     public void splitCsvFile(String inputFilePath, String outputDirectory, String fileName, int batchSize)
//             throws IOException {
//         // Ensure the output directory exists
//         File outputDir = new File(outputDirectory);
//         if (!outputDir.exists()) {
//             outputDir.mkdirs(); // Create the output directory if it doesn't exist
//         }
//         FileWriter writer = null;
//         try (BufferedReader reader = new BufferedReader(new FileReader(inputFilePath));) {
//             String header = reader.readLine(); // Read the header from the input CSV file
//             if (header == null) {
//                 throw new IOException("Input file is empty!");
//             }

//             String line;
//             int fileCount = 0;
//             int recordCount = 0;

//             while ((line = reader.readLine()) != null) {
//                 if (recordCount % batchSize == 0) {
//                     // Close the previous file writer (if any) and start a new file
//                     if (writer != null) {
//                         writer.close();
//                     }
//                     fileCount++;
//                     writer = new FileWriter(new File(outputDirectory, fileName + fileCount + ".csv"));
//                     writer.write(header + "\n"); // Write the header to the new file
//                 }
//                 writer.write(line + "\n");
//                 recordCount++;
//             }

//             // Close the last writer if it exists

//         } catch (IOException e) {
//             throw new IOException("Error while processing the CSV file: " + e.getMessage(), e);
//         } finally {
//             if (writer != null) {
//                 writer.close();
//             }
//         }
//     }

// }
