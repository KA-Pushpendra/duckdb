package in.indigo.utility;

import in.indigo.duckRepository.AuditInvoiceDwhRepository;
import in.indigo.duckRepository.ErrorInvoiceDetailsRepository;
import in.indigo.duckRepository.ErrorPNRRecordRepository;
import in.indigo.duckRepository.InvSkyExtractAcRepository;
import in.indigo.duckRepository.InvoiceDwhRepository;
import in.indigo.duckdbEntity.AuditInvoiceDWH;
import in.indigo.duckdbEntity.ErrorInvoiceDetails;
import in.indigo.duckdbEntity.ErrorPNRRecord;
import in.indigo.duckdbEntity.InvSkyExtractAc;
import in.indigo.duckdbEntity.InvoiceDWH;
import in.indigo.pojo.Request;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.*;

import org.eclipse.microprofile.faulttolerance.Retry;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Slf4j
@ApplicationScoped
@RequiredArgsConstructor

public class DumpToDb {

    private final InvSkyExtractAcRepository invSkyExtractAcRepository;
    private final AuditInvoiceDwhRepository auditInvoiceDwhRepository;
    private final ErrorInvoiceDetailsRepository errorInvoiceDetailsRepository;
    private final ErrorPNRRecordRepository errorPNRRecordRepository;

    private final InvoiceDwhRepository invoiceDwhRepository;

    ObjectMapper objectMapper = CustomObjectMapper.createObjectMapper();

    @Transactional
    public synchronized void process(String body, String className) throws JsonProcessingException {
        // String str = objectMapper.writeValueAsString(object.getBody());
        // log.info("=======> "+object.getEntityName()+"===> "+str);
        switch (className) {
            case "InvSkyExtractAc":
                List<InvSkyExtractAc> dataList = Arrays.asList(objectMapper.readValue(body, InvSkyExtractAc[].class));
                retryPersist(() -> invSkyExtractAcRepository.persist(dataList));
                break;
            case "AuditInvoiceDWH":
                List<AuditInvoiceDWH> auditInvoiceDWHs = Arrays
                        .asList(objectMapper.readValue(body, AuditInvoiceDWH[].class));

                // for (AuditInvoiceDWH auditInvoiceDWH : auditInvoiceDWHs) {
                // auditInvoiceDWH.setAuditID((int) ((auditInvoiceDwhRepository.count()) + 1));
                retryPersist(() -> auditInvoiceDwhRepository.persist(auditInvoiceDWHs));
                // }

                break;
            case "ErrorInvoiceDetails":
                List<ErrorInvoiceDetails> errorInvoiceDetails = Arrays
                        .asList(objectMapper.readValue(body, ErrorInvoiceDetails[].class));
                errorInvoiceDetails.forEach(d -> {
                    retryPersist(() -> {
                        try {
                            errorInvoiceDetailsRepository.persist(d);
                        } catch (Exception ex) {
                            // log.error("Error in errorInvoiceDetails -----> {}", ex.getMessage());
                            throw new RuntimeException(ex);
                        }
                    });
                });
                break;
            case "ErrorPNRRecord":
                List<ErrorPNRRecord> errorPNRRecordList = Arrays
                        .asList(objectMapper.readValue(body, ErrorPNRRecord[].class));

                retryPersist(() -> errorPNRRecordRepository.persist(errorPNRRecordList));
                break;
            // case "InvoiceData":
            // List<InvoiceData> invoiceData = Arrays
            // .asList(objectMapper.readValue(body, InvoiceData[].class));
            // retryPersist(() -> invoiceDataRepository.persist(invoiceData));
            // break;
            case "InvoiceDWH":
                List<InvoiceDWH> invoiceDWHList = Arrays
                        .asList(objectMapper.readValue(body, InvoiceDWH[].class));

                retryPersist(() -> invoiceDwhRepository.persist(invoiceDWHList));
                break;

            default:
                throw new RuntimeException("Invalid data type");
        }
    }

    @Retry(maxRetries = 3, delay = 10000)
    public void retryPersist(Runnable runnable) {
        runnable.run();
    }
}