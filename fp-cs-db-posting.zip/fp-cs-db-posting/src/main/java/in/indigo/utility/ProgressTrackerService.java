package in.indigo.utility;

import org.apache.camel.builder.RouteBuilder;

import in.indigo.mssqlRepository.ProgressTrackerRepository;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ApplicationScoped
@RequiredArgsConstructor
@Setter
@Getter
public class ProgressTrackerService extends RouteBuilder {

    private final ProgressTrackerRepository progressTrackerRepository;

    public static double percentageCompleted = 0;
    public static double checkValue = 0;
    public static String requestId = "";

    public static double getPercentageCompleted() {
        return percentageCompleted;
    }

    public static double getCheckValue() {
        return checkValue;
    }

    public static String getRequestId() {
        return requestId;
    }

    // Setter methods
    public static void setPercentageCompleted(double percentage) {
        percentageCompleted = percentage;
    }

    public static void setCheckValue(double value) {
        checkValue = value;
    }

    public static void setRequestId(String id) {
        requestId = id;
    }

    @Override
    public void configure() throws Exception {
        from("timer://foo?period=5000")
                .routeId("foo-fixed-interval-route")
                .process(exchange -> {
                    if (percentageCompleted != checkValue) {
                        setCheckValue(percentageCompleted);
                        progressTrackerRepository.updateTracker(requestId, percentageCompleted);
                    }

                });
    }

}
