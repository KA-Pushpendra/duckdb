package in.indigo.utility;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.util.stream.Stream;

import org.eclipse.microprofile.config.inject.ConfigProperty;

import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class MoveFilesAndDeleteFolder {
    @ConfigProperty(name = "MAIL_SEND_FOLDER")
    private String MAIL_SEND_FOLDER;

    @ConfigProperty(name = "MAIL_REQUEST_FOLDER")
    private String sourceDir;

    public void moveFiles() {
        File outputDir = new File(MAIL_SEND_FOLDER);
        if (!outputDir.exists()) {
            outputDir.mkdirs();
        }

        File soDir = new File(sourceDir);
        if (!soDir.exists()) {
            soDir.mkdirs();
        }
        Path targetDir = Paths.get(MAIL_SEND_FOLDER); // Target folder

        try (Stream<Path> files = Files.list(Paths.get((sourceDir)))) {
            files.forEach(sourceFile -> {
                Path targetFile = targetDir.resolve(sourceDir + "~" + sourceFile.getFileName());
                try {
                    Files.move(sourceFile, targetFile, StandardCopyOption.REPLACE_EXISTING);
                    System.out.println("Moved: " + sourceFile);
                } catch (IOException e) {
                    e.printStackTrace();
                    throw new RuntimeException("ubable to move files", e);
                }
            });

            // Check if folder is now empty and delete
            // if (Files.list(sourceDir).findAny().isEmpty()) {
            // FileUtils.deleteDirectory(new File(sourceDir));
            // System.out.println("Source folder deleted as it was empty!");
            // } else {
            // System.out.println("Source folder still contains files, not deleting.");
            // }
            System.out.println("-------------------");
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("ubable to move files", e);
        }
    }
}
