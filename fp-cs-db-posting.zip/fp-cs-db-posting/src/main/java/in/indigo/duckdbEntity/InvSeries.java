package in.indigo.duckdbEntity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@ToString
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name = "Inv_Series_CS")
public class InvSeries extends PanacheEntityBase {

    @Id
    @Column(name = "ID", nullable = false)
    private Integer id;

   @Column(name = "Month")
    private String month;

    @Column(name = "StateCode", length = 5)
    private String stateCode;

    @Column(name = "CurrentValue")
    private Integer currentValue;

    @Column(name = "MaxValue")
    private Integer maxValue;

    @Column(name = "Active")
    private Integer active;

    @Column(name = "FinancialYear")
    private Integer financialYear;

    @Column(name = "InvoiceType", length = 10)
    private String invoiceType;

    @Column(name = "isNew")
    private Boolean isNew = false;

    @PrePersist
    private void prePersist() {
        if (isNew == null) {
            isNew = false; // Ensure the default value is set during persistence
        }
    }

}
