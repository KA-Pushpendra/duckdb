package in.indigo.duckdbEntity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name = "Invoice_DWH_CS")
@ToString
public class InvoiceDWH extends PanacheEntityBase implements Serializable {

    @Id
    @Column(name = "Id")

    private String id;

    @Column(name = "TransactionDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/d/yyyy", timezone = "Asia/Kolkata")
    private Date transactionDate;

    @Column(name = "FileDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/d/yyyy", timezone = "Asia/Kolkata")
    private Date fileDate;

    @Column(name = "DisplayDate")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/d/yyyy", timezone = "Asia/Kolkata")
    private Date displayDate;

    @Column(name = "FlightNumber")
    private int flightNumber;

    @Column(name = "GoodsServicesType")
    private String goodsServicesType;

    @Column(name = "SAC")
    private int sac;

    @Column(name = "InvoiceNumber")
    private String invoiceNumber;

    @Column(name = "SequenceNo")
    private int sequenceNo;

    @Column(name = "PNR")
    private String pnr;

    @Column(name = "Dep")
    private String dep;

    @Column(name = "Arr")
    private String arr;

    @Column(name = "PlaceOfEmbarkation")
    private String placeOfEmbarkation;

    @Column(name = "StateCode")
    private String stateCode;

    @Column(name = "CustomerGSTIN")
    private String customerGSTIN;

    @Column(name = "CustomerName")
    private String customerName;

    @Column(name = "EmailAddress")
    private String emailAddress;

    @Column(name = "CustomerGSTRegistrationState")
    private String customerGSTRegistrationState;

    @Column(name = "PassengerName")
    private String passengerName;

    @Column(name = "PassengerEmail")
    private String passengerEmail;

    @Column(name = "6EGSTIN")
    private String e6gstin;

    @Column(name = "6ERegisteredAddress")
    private String e6RegisteredAddress;

    @Column(name = "NonTaxableFareComponent")
    private double nonTaxableFareComponent;

    @Column(name = "TaxableComponent")
    private double taxableComponent;

    @Column(name = "NumberType")
    private Boolean numberType;

    @Column(name = "CGSTAmount")
    private double cgstAmount;

    @Column(name = "IGSTAmount")
    private double igstAmount;

    @Column(name = "SGSTAmount")
    private double sgstAmount;

    @Column(name = "UGSTAmount")
    private double ugstAmount;

    @Column(name = "CGSTRate")
    private double cgstRate;

    @Column(name = "IGSTRate")
    private double igstRate;

    @Column(name = "SGSTUGSTRate")
    private double sgstugstRate;

    @Column(name = "IsProcessed")
    private String isProcessed;

    @Column(name = "InvOrder")
    private short invOrder;

    @Column(name = "IsCredit")
    private short isCredit;

    @Column(name = "ServiceNo")
    private short serviceNo;

    @Column(name = "Mailsend")
    private int mailSend;

    @Column(name = "AirportCharges")
    private double airportCharges;

    @Column(name = "OriginCountry")
    private String originCountry;

    @Column(name = "IsExempted")
    private boolean isExempted;

    @Column(name = "Cess Amount")
    private double cessAmount;

    @Column(name = "Local Cess Amount")
    private double localCessAmount;

    // @Transient
    @Column(name = "AutoCorrectionId")
    private String autoCorrectionIds;

    // @Transient
    @Column(name = "IsAutoCorrected")
    private String isAutoCorrected;

    // @Transient
    @Column(name = "ReasonIDs")
    private String reasonIds;

    @Column(name = "ReasonID")
    private String reasonId;

    @Column(name = "sapBiDescription")
    private String sapBiDescription;

    @Column(name = "IsError")
    private int isError;

    @Column(name = "IsCorrect")
    private int IsCorrect;

    @Column(name = "errorIds")
    private String errorIds;
    @Column(name = "Agent Code")
    private String agentCode;

    @Transient
    private Set<String> correctedErrorIds;

    @Transient
    private Set<String> errorIdSet;

    @Column(name = "isSapBiError")
    private String isSapBiError;

    @Column(name = "sapBiErrorIds")
    private String sapBiErrorIds;

    // @Transient
    @Column(name = "ErrorDescription")
    private String errorDescription;

    @Column(name = "spExemptedFlight")
    private int spExemptedFlight;

    @Column(name = "spInternational")
    private int spInternational;

    @Column(name = "spSez")
    private int spSez;

    @Column(name = "CreatedBy")
    public String createdBy;

    @Column(name = "CreatedOn")
    public LocalDateTime createdOn;

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    @Transient
    private String itineraryOrigin;

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    @Transient
    private String currentSeries;

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    @Transient
    private String series;

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    @Transient
    private String runningSeries;

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    @Transient
    private int maxSeries;

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    @Transient
    private int rowNumber;

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    @Transient
    private char startSeries;

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    @Transient
    private char endSeries;

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    @Transient
    private int groupID;

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    @Transient
    private String gstHolderName;

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    @Transient
    private String localCurrency;

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    @Transient
    private double taxes;

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    @Transient
    private double inrTolerance;

}