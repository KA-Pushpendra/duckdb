package in.indigo.duckdbEntity;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "Inv_SkyExtract_CS")
@JsonIgnoreProperties(ignoreUnknown = true)
public class InvSkyExtract extends PanacheEntityBase implements Serializable {

    @Id
    @Column(name = "Id")
    public String id;

    @Column(name = "Original Booking Date")
    private String originalBookingDate;

    @Column(name = "Transaction Date")
    private String transactionDate;

    @Column(name = "Reference Date")
    public String referenceDate;

    @Column(name = "Flight Date")
    private String flightDate;

    @Column(name = "Flight Number")
    private int flightNumber;

    @Column(name = "Description of Goods/Services")
    private String descriptionOfGoodsServices;

    @Column(name = "SAC")
    private double sac;

    @Column(name = "PNR")
    private String pnr;

    @Column(name = "Full Itinerary Route")
    private String itineraryOrigin;

    @Column(name = "Sector")
    private String sector;

    @Column(name = "Place of Embarkation")
    private String placeOfEmbarkation;

    @Column(name = "Customer GSTIN")
    private String customerGSTIN;

    @Column(name = "Customer Name")
    private String customerName;

    @Column(name = "Email Address")
    private String passengerEmail;

    @Column(name = "GST Holder Name")
    private String gstHolderName;

    @Column(name = "GST Email Address")
    private String gstEmailAddress;

    @Column(name = "Customer GST Registration State")
    private String customerGSTRegistrationState;

    @Column(name = "6E GSTIN")
    private String e6gstin;

    @Column(name = "6E RegisteredAddress")
    private String e6RegisteredAddress;

    @Column(name = "Base Fare")
    private double baseFare;

    @Column(name = "Taxable Fare Component")
    private double taxableFareComponent;

    @Column(name = "Non-Taxable Fare Component")
    private double nonTaxableFareComponent;

    @Column(name = "SSR Fee Code")
    private String ssrFeeCode;

    @Column(name = "SSR Component")
    private double ssrComponent;

    @Column(name = "Taxable Component")
    private double taxableComponent;

    @Column(name = "CGST Amount")
    private double cgstAmount;

    @Column(name = "IGST Amount")
    private double igstAmount;

    @Column(name = "SGST Amount")
    private double sgstAmount;

    @Column(name = "UGST Amount")
    private double ugstAmount;

    @Column(name = "GST Amount")
    private double gstAmount;

    @Column(name = "Cess Amount")
    private double cessAmount;

    @Column(name = "Local Currency")
    private String localCurrency;

    @Column(name = "Local Base Fare")
    private double localBaseFare;

    @Column(name = "Local Taxable Fare Component")
    private double localTaxableFareComponent;

    @Column(name = "Local Non-Taxable Fare Component")
    private double localNonTaxableFareComponent;

    @Column(name = "Local SSR Component")
    private double localSSRComponent;

    @Column(name = "Local Taxable Component")
    private double localTaxableComponent;

    @Column(name = "Local CGST Amount")
    private double localCGSTAmount;

    @Column(name = "Local IGST Amount")
    private double localIGSTAmount;

    @Column(name = "Local SGST Amount")
    private double localSGSTAmount;

    @Column(name = "Local UGST Amount")
    private double localUGSTAmount;

    @Column(name = "Local GST Amount")
    private double localGSTAmount;

    @Column(name = "Local Cess Amount")
    private double localCessAmount;

    @Column(name = "AirportCharges")
    private double airportCharges;

    @Column(name = "LocalAirportCharges")
    private double localAirportCharges;

    @Column(name = "OriginCountry")
    private String originCountry;

    @Column(name = "IsExempted")
    private boolean isExempted;

    @Column(name = "Agent Code")
    private String agentCode;

    @Transient
    private String reasonIds;// change to string

    @Column(name = "NumberType")
    public String numberType;

    @Column(name = "Status")
    public String status;

    @Column(name = "CreatedBy")
    public String createdBy = "System";

    @Column(name = "CreatedDate")
    public LocalDateTime createdDate = LocalDateTime.now();

    @Column(name = "FileName")
    public String fileName;

    @Column(name = "Path")
    public String path;

    @Transient
    public Integer index;

    @Transient
    public String stateCode;

    @Transient
    private String fileDate;

    @Transient
    private String displayDate;

    @Transient
    private String dep;

    @Transient
    private String arr;

    @Transient
    private String passengerName;

    @Transient
    private String emailAddress;
    @Transient
    private String autoCorrectionIds;

    @Transient
    private String isAutoCorrected;

}
